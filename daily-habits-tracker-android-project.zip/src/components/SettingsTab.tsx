const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Moon, Sun, Download, Upload, RotateCcw, Trash2, Bell, BellRing, Info, ShieldCheck, Smartphone, Check, AlertTriangle, AlertCircle, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { exportAllData, importAllData, getTodayDateString } from "/src/services/storageService.ts";
import { checkNotificationStatus, requestNotificationPermission, sendTestNotification } from "/src/services/notificationService.ts";
import { AndroidApkModal } from "/src/components/AndroidApkModal.tsx";
import { getApkBuildInfo, downloadAndroidProjectZip } from "/src/services/androidExportService.ts";
var _jsxFileName = "/app/applet/src/components/SettingsTab.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const SettingsTab = ({ settings, onUpdateSettings, habits, onRequestResetData, onRequestRestoreDefaults, onDataImported }) => {
	const [notifStatus, setNotifStatus] = useState(checkNotificationStatus());
	const [importMessage, setImportMessage] = useState(null);
	const [testNotifSuccess, setTestNotifSuccess] = useState(null);
	const [isApkModalOpen, setIsApkModalOpen] = useState(false);
	const [isDownloadingZip, setIsDownloadingZip] = useState(false);
	const apkInfo = getApkBuildInfo();
	const fileInputRef = useRef(null);
	useEffect(() => {
		setNotifStatus(checkNotificationStatus());
	}, []);
	const handleDownloadZip = async () => {
		try {
			setIsDownloadingZip(true);
			await downloadAndroidProjectZip();
		} catch (e) {
			console.error("ZIP download error:", e);
		} finally {
			setIsDownloadingZip(false);
		}
	};
	// Theme toggle
	const toggleTheme = (theme) => {
		onUpdateSettings({
			...settings,
			theme
		});
	};
	// Export JSON file download
	const handleExportData = () => {
		try {
			const dataStr = exportAllData();
			const blob = new Blob([dataStr], { type: "application/json" });
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			const dateStr = getTodayDateString();
			link.href = url;
			link.download = `daily-habits-backup-${dateStr}.json`;
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			URL.revokeObjectURL(url);
		} catch (e) {
			console.error("Export failed", e);
		}
	};
	// Import JSON file
	const handleFileChange = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const content = event.target?.result;
			if (!content) return;
			const result = importAllData(content);
			if (result.success) {
				setImportMessage({
					text: result.message,
					isError: false
				});
				onDataImported();
			} else {
				setImportMessage({
					text: result.message,
					isError: true
				});
			}
		};
		reader.readAsText(file);
		// Reset file input value so same file can be selected again
		e.target.value = "";
	};
	// Request Notification permission
	const handleEnableNotifications = async () => {
		const perm = await requestNotificationPermission();
		setNotifStatus(checkNotificationStatus());
		if (perm === "granted") {
			onUpdateSettings({
				...settings,
				notificationsEnabled: true
			});
		}
	};
	// Send Test Notification
	const handleTestNotification = () => {
		const success = sendTestNotification();
		setTestNotifSuccess(success);
		setTimeout(() => setTestNotifSuccess(null), 4e3);
	};
	// Count habits with reminders
	const habitsWithReminders = habits.filter((h) => !h.isPaused && Boolean(h.reminderTime));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "pb-24 pt-4 px-4 max-w-md mx-auto space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-black text-stone-900 dark:text-stone-100",
				children: "सेटिंग्स और डेटा सुरक्षा"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-stone-500 dark:text-stone-400",
				children: "ऐप की प्राथमिकताएं, बैकअप और गोपनीयता सेटिंग्स"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 148,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-bold text-stone-900 dark:text-stone-100 text-sm flex items-center gap-2",
					children: [settings.theme === "dark" ? /* @__PURE__ */ _jsxDEV(Moon, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 40
					}, this) : /* @__PURE__ */ _jsxDEV(Sun, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 61
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "थीम (रंग रूप)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => toggleTheme("light"),
						className: `p-3 rounded-2xl border flex items-center justify-center gap-2 font-semibold text-xs transition cursor-pointer ${settings.theme === "light" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/40" : "border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/50 text-stone-700 dark:text-stone-300"}`,
						children: [
							/* @__PURE__ */ _jsxDEV(Sun, {
								size: 16,
								className: "text-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "लाइट मोड" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 13
							}, this),
							settings.theme === "light" && /* @__PURE__ */ _jsxDEV(Check, {
								size: 14,
								className: "text-emerald-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 44
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => toggleTheme("dark"),
						className: `p-3 rounded-2xl border flex items-center justify-center gap-2 font-semibold text-xs transition cursor-pointer ${settings.theme === "dark" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 ring-2 ring-emerald-500/40" : "border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/50 text-stone-700 dark:text-stone-300"}`,
						children: [
							/* @__PURE__ */ _jsxDEV(Moon, {
								size: 16,
								className: "text-indigo-400"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "डार्क मोड" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 13
							}, this),
							settings.theme === "dark" && /* @__PURE__ */ _jsxDEV(Check, {
								size: 14,
								className: "text-emerald-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 43
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-stone-900 dark:text-stone-100 text-sm flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Bell, {
								size: 16,
								className: "text-emerald-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "रिमाइंडर और नोटिफिकेशन" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[11px] font-bold px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300",
							children: [habitsWithReminders.length, " सक्रिय रिमाइंडर"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 rounded-2xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200/60 dark:border-stone-700 space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-xs font-semibold",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-stone-600 dark:text-stone-300",
								children: "अनुमति स्थिति:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: `px-2 py-0.5 rounded-md text-[11px] font-bold ${notifStatus.permission === "granted" ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" : notifStatus.permission === "denied" ? "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300" : "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300"}`,
								children: notifStatus.permission === "granted" ? "सक्रिय (अनुमति प्राप्त)" : notifStatus.permission === "denied" ? "अस्वीकृत" : "अनुमति नहीं दी गई"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-stone-500 dark:text-stone-400 leading-relaxed",
							children: notifStatus.explanationHindi
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row gap-2 pt-1",
						children: [notifStatus.permission !== "granted" && notifStatus.isSupported && /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleEnableNotifications,
							className: "py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(BellRing, { size: 15 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "नोटिफिकेशन की अनुमति दें" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 233,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 228,
							columnNumber: 13
						}, this), notifStatus.permission === "granted" && /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleTestNotification,
							className: "py-2.5 px-3 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
								size: 15,
								className: "text-amber-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 242,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "परीक्षण (Test) नोटिफिकेशन भेजें" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 243,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 9
					}, this),
					testNotifSuccess !== null && /* @__PURE__ */ _jsxDEV("div", {
						className: `p-2.5 rounded-xl text-xs font-semibold ${testNotifSuccess ? "bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-300 border border-emerald-200" : "bg-red-50 dark:bg-red-950/50 text-red-800 dark:text-red-300 border border-red-200"}`,
						children: testNotifSuccess ? "सफलता! परीक्षण नोटिफिकेशन भेज दिया गया है।" : "परीक्षण नोटिफिकेशन भेजने में विफल। कृपया जांचें कि ब्राउज़र सूचनाएं ब्लॉक तो नहीं हैं।"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 249,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/60 flex items-start gap-2.5 text-[11px] text-amber-900 dark:text-amber-300",
						children: [/* @__PURE__ */ _jsxDEV(Info, {
							size: 16,
							className: "shrink-0 mt-0.5 text-amber-600 dark:text-amber-400"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 262,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "leading-relaxed",
							children: [/* @__PURE__ */ _jsxDEV("strong", { children: "ईमानदार तकनीकी जानकारी:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 13
							}, this), " वेब ब्राउज़र वातावरण में, रिमाइंडर केवल तभी बजते हैं जब आपका ब्राउज़र या ऐप सक्रिय हो। यह स्टैंडअलोन वेब प्रोटोटाइप है, इसलिए फोन लॉक होने या ब्राउज़र पूरी तरह बंद होने पर स्वचालित वेक-अप नोटिफिकेशन सीमित हो सकते हैं।"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 190,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-stone-900 dark:text-stone-100 text-sm flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
							size: 16,
							className: "text-emerald-600"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "डेटा बैकअप एवं रीस्टोर (JSON)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 271,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-stone-500 dark:text-stone-400",
						children: "आपका पूरा डेटा आपके डिवाइस के लोकल स्टोरेज में सुरक्षित रहता है। आप कभी भी बैकअप फ़ाइल डाउनलोड कर सकते हैं।"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 9
					}, this),
					importMessage && /* @__PURE__ */ _jsxDEV("div", {
						className: `p-3 rounded-xl text-xs font-semibold ${importMessage.isError ? "bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200" : "bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200"}`,
						children: importMessage.text
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 280,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-3 pt-1",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleExportData,
								className: "p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-950 text-emerald-800 dark:text-emerald-300 border border-emerald-200/80 dark:border-emerald-800/60 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV(Download, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "डेटा निर्यात (Export)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => fileInputRef.current?.click(),
								className: "p-3 rounded-2xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 border border-stone-200 dark:border-stone-700 font-bold text-xs flex flex-col items-center justify-center gap-1.5 transition active:scale-95 cursor-pointer shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV(Upload, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "डेटा आयात (Import)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 300,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								type: "file",
								ref: fileInputRef,
								onChange: handleFileChange,
								accept: ".json,application/json",
								className: "hidden"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 308,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 289,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 270,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3.5",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-stone-900 dark:text-stone-100 text-sm flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Smartphone, {
								size: 16,
								className: "text-emerald-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Android ऐप डाउनलोड करें" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800/60",
							children: "Android (APK)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-stone-500 dark:text-stone-400 leading-relaxed",
						children: "इस ऐप को अपने एंड्रॉइड फोन में सीधे ऐप (APK) के रूप में इंस्टॉल करने और उपयोग करने की सम्पूर्ण जानकारी।"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 330,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-800/60 space-y-2 text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-amber-900 dark:text-amber-300 font-bold text-xs",
							children: [/* @__PURE__ */ _jsxDEV(Info, {
								size: 15,
								className: "text-amber-600 dark:text-amber-400 shrink-0"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "तकनीकी जानकारी एवं APK स्थिति:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 338,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 336,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed",
							children: apkInfo.limitationExplanationHindi
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 340,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2 pt-1",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsApkModalOpen(true),
								className: "w-full py-3 px-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-98 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-xs",
								children: [/* @__PURE__ */ _jsxDEV(Smartphone, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 352,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "APK बनाने और डाउनलोड करने का तरीका" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 353,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 11
							}, this),
							apkInfo.isAvailable && apkInfo.downloadUrl ? /* @__PURE__ */ _jsxDEV("a", {
								href: apkInfo.downloadUrl,
								download: apkInfo.fileName || "app-debug.apk",
								className: "w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Download, { size: 15 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 363,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"APK डाउनलोड करें (",
									apkInfo.fileName,
									" • ",
									apkInfo.fileSize,
									")"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 358,
								columnNumber: 13
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between p-2.5 rounded-xl bg-stone-100 dark:bg-stone-800/60 border border-stone-200/60 dark:border-stone-700/60 text-stone-500 dark:text-stone-400 text-[11px]",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
										size: 14,
										className: "text-stone-400"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 369,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "सीधा सर्वर APK: उपलब्ध नहीं (पारदर्शी नीति)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 370,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 368,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-semibold text-stone-400 text-[10px]",
									children: "Android Studio आवश्यक"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 372,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDownloadZip,
								disabled: isDownloadingZip,
								className: "w-full py-2.5 px-3 rounded-xl border border-stone-200 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-300 font-semibold text-xs flex items-center justify-center gap-2 transition cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Download, {
									size: 14,
									className: "text-emerald-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 382,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDownloadingZip ? "ज़िप फ़ाइल तैयार हो रही है..." : "प्रोजेक्ट फाइल्स (ZIP) डाउनलोड करें" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 383,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 377,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 346,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 319,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-red-200/60 dark:border-red-950/60 shadow-xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-red-600 dark:text-red-400 text-sm flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 16 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 395,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "डेटा प्रबंधन एवं रीसेट" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 396,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 394,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-stone-500 dark:text-stone-400",
						children: "कृपया सावधानी से उपयोग करें। रीसेट करने से पहले पुष्टि पूछी जाएगी।"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 398,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2 pt-1",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: onRequestRestoreDefaults,
							className: "w-full py-2.5 px-3 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:bg-stone-50 dark:hover:bg-stone-800 text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 408,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "प्रारंभिक 5 डिफ़ॉल्ट आदतें पुनः लोड करें" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 409,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: onRequestResetData,
							className: "w-full py-2.5 px-3 rounded-xl bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-900/40 text-red-600 dark:text-red-400 border border-red-200 dark:border-red-900/60 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Trash2, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 417,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "सभी आदतें व इतिहास पूर्णतः रीसेट करें" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 418,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 413,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 402,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 393,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center text-[11px] text-stone-400 dark:text-stone-600 space-y-1",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "font-bold text-stone-500 dark:text-stone-400",
					children: "Daily Habits – मेरी अच्छी आदतें v1.0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 425,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "100% हिंदी में, सुरक्षित स्थानीय स्टोरेज के साथ निर्मित" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 428,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 424,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AndroidApkModal, {
				isOpen: isApkModalOpen,
				onClose: () => setIsApkModalOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 432,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 142,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBaUI7QUFDbkQsU0FDRSxNQUNBLEtBQ0EsVUFDQSxRQUNBLFdBQ0EsUUFDQSxNQUNBLFVBQ0EsTUFDQSxhQUNBLFlBQ0EsT0FDQSxlQUNBLGFBQ0EsZ0JBRUs7QUFFUCxTQUNFLGVBQ0EsZUFDQSwwQkFDSztBQUNQLFNBQ0UseUJBQ0EsK0JBQ0EsNEJBRUs7QUFDUCxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLGlCQUFpQixpQ0FBaUM7OztBQVczRCxPQUFPLE1BQU0sZUFBMkMsRUFDdEQsVUFDQSxrQkFDQSxRQUNBLG9CQUNBLDBCQUNBLHFCQUNJO0NBQ0osTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTZCLHdCQUF3QixDQUFDO0NBQzVGLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFvRCxJQUFJO0NBQ2xHLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQXlCLElBQUk7Q0FDN0UsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBUyxLQUFLO0NBQzFELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLFVBQVUsZ0JBQWdCO0NBQ2hDLE1BQU0sZUFBZSxPQUF5QixJQUFJO0NBRWxELGdCQUFnQjtFQUNkLGVBQWUsd0JBQXdCLENBQUM7Q0FDMUMsR0FBRyxDQUFDLENBQUM7Q0FFTCxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLElBQUk7R0FDRixvQkFBb0IsSUFBSTtHQUN4QixNQUFNLDBCQUEwQjtFQUNsQyxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sdUJBQXVCLENBQUM7RUFDeEMsVUFBVTtHQUNSLG9CQUFvQixLQUFLO0VBQzNCO0NBQ0Y7O0NBR0EsTUFBTSxlQUFlLFVBQTRCO0VBQy9DLGlCQUFpQjtHQUFFLEdBQUc7R0FBVTtFQUFNLENBQUM7Q0FDekM7O0NBR0EsTUFBTSx5QkFBeUI7RUFDN0IsSUFBSTtHQUNGLE1BQU0sVUFBVSxjQUFjO0dBQzlCLE1BQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0dBQzdELE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0dBQ3BDLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztHQUN2QyxNQUFNLFVBQVUsbUJBQW1CO0dBQ25DLEtBQUssT0FBTztHQUNaLEtBQUssV0FBVyx1QkFBdUIsUUFBUTtHQUMvQyxTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsSUFBSSxnQkFBZ0IsR0FBRztFQUN6QixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0saUJBQWlCLENBQUM7RUFDbEM7Q0FDRjs7Q0FHQSxNQUFNLG9CQUFvQixNQUEyQztFQUNuRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFFWCxNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sVUFBVSxVQUFVO0dBQ3pCLE1BQU0sVUFBVSxNQUFNLFFBQVE7R0FDOUIsSUFBSSxDQUFDLFNBQVM7R0FFZCxNQUFNLFNBQVMsY0FBYyxPQUFPO0dBQ3BDLElBQUksT0FBTyxTQUFTO0lBQ2xCLGlCQUFpQjtLQUFFLE1BQU0sT0FBTztLQUFTLFNBQVM7SUFBTSxDQUFDO0lBQ3pELGVBQWU7R0FDakIsT0FBTztJQUNMLGlCQUFpQjtLQUFFLE1BQU0sT0FBTztLQUFTLFNBQVM7SUFBSyxDQUFDO0dBQzFEO0VBQ0Y7RUFDQSxPQUFPLFdBQVcsSUFBSTs7RUFFdEIsRUFBRSxPQUFPLFFBQVE7Q0FDbkI7O0NBR0EsTUFBTSw0QkFBNEIsWUFBWTtFQUM1QyxNQUFNLE9BQU8sTUFBTSw4QkFBOEI7RUFDakQsZUFBZSx3QkFBd0IsQ0FBQztFQUN4QyxJQUFJLFNBQVMsV0FBVztHQUN0QixpQkFBaUI7SUFBRSxHQUFHO0lBQVUsc0JBQXNCO0dBQUssQ0FBQztFQUM5RDtDQUNGOztDQUdBLE1BQU0sK0JBQStCO0VBQ25DLE1BQU0sVUFBVSxxQkFBcUI7RUFDckMsb0JBQW9CLE9BQU87RUFDM0IsaUJBQWlCLG9CQUFvQixJQUFJLEdBQUcsR0FBSTtDQUNsRDs7Q0FHQSxNQUFNLHNCQUFzQixPQUFPLFFBQVEsTUFBTSxDQUFDLEVBQUUsWUFBWSxRQUFRLEVBQUUsWUFBWSxDQUFDO0NBRXZGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF3RDtHQUVsRTs7OzthQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTZDO0dBRXZEOzs7O1dBQ0E7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRyxTQUFTLFVBQVUsU0FBUyx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2dCQUFJLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7ZUFDbEUsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzthQUN2Qjs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsWUFBWSxPQUFPO01BQ2xDLFdBQVcsaUhBQ1QsU0FBUyxVQUFVLFVBQ2YsOEhBQ0E7Z0JBTFI7T0FRRSx3QkFBQyxLQUFEO1FBQUssTUFBTTtRQUFJLFdBQVU7T0FBa0I7Ozs7O09BQzNDLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7OztPQUNuQixTQUFTLFVBQVUsV0FBVyx3QkFBQyxPQUFEO1FBQU8sTUFBTTtRQUFJLFdBQVU7T0FBb0I7Ozs7O01BQ3hFOzs7OztlQUVSLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLFlBQVksTUFBTTtNQUNqQyxXQUFXLGlIQUNULFNBQVMsVUFBVSxTQUNmLDhIQUNBO2dCQUxSO09BUUUsd0JBQUMsTUFBRDtRQUFNLE1BQU07UUFBSSxXQUFVO09BQW1COzs7OztPQUM3Qyx3QkFBQyxRQUFELFlBQU0sWUFBZTs7Ozs7T0FDcEIsU0FBUyxVQUFVLFVBQVUsd0JBQUMsT0FBRDtRQUFPLE1BQU07UUFBSSxXQUFVO09BQW9COzs7OztNQUN2RTs7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxNQUFEO1FBQU0sTUFBTTtRQUFJLFdBQVU7T0FBb0I7Ozs7aUJBQzlDLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7ZUFDaEM7Ozs7O2dCQUNKLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUNHLG9CQUFvQixRQUFPLGtCQUN4Qjs7Ozs7Y0FDSDs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFxQztPQUFvQjs7OztpQkFDekUsd0JBQUMsUUFBRDtRQUFNLFdBQVcsZ0RBQ2YsWUFBWSxlQUFlLFlBQ3ZCLDhFQUNBLFlBQVksZUFBZSxXQUMzQiw4REFDQTtrQkFFSCxZQUFZLGVBQWUsWUFDeEIsNEJBQ0EsWUFBWSxlQUFlLFdBQzNCLGFBQ0E7T0FDQTs7OztlQUNIOzs7OztnQkFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFDVixZQUFZO01BQ1o7Ozs7Y0FDQTs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRyxZQUFZLGVBQWUsYUFBYSxZQUFZLGVBQ25ELHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7aUJBQ3JCLHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7ZUFDOUI7Ozs7O2dCQUdULFlBQVksZUFBZSxhQUMxQix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxVQUFEO1FBQVUsTUFBTTtRQUFJLFdBQVU7T0FBa0I7Ozs7aUJBQ2hELHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7ZUFDckM7Ozs7O2NBRVA7Ozs7OztLQUVKLHFCQUFxQixRQUNwQix3QkFBQyxPQUFEO01BQUssV0FBVywwQ0FDZCxtQkFDSSwwR0FDQTtnQkFFSCxtQkFDRywrQ0FDQTtLQUNEOzs7OztLQUlQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFNLE1BQU07T0FBSSxXQUFVO01BQXNEOzs7O2dCQUNoRix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBYixDQUNFLHdCQUFDLFVBQUQsWUFBUSwwQkFBK0I7Ozs7aUJBQUMsNE5BQ3ZDOzs7OztjQUNBOzs7Ozs7SUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQ0Usd0JBQUMsYUFBRDtPQUFhLE1BQU07T0FBSSxXQUFVO01BQW9COzs7O2dCQUNyRCx3QkFBQyxRQUFELFlBQU0sZ0NBQW1DOzs7O2NBQ3ZDOzs7Ozs7S0FDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNkM7S0FFdkQ7Ozs7O0tBRUYsaUJBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVcsd0NBQ2QsY0FBYyxVQUNWLHNGQUNBO2dCQUVILGNBQWM7S0FDWjs7Ozs7S0FHUCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUVFLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7a0JBQ3JCLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7Z0JBQzNCOzs7Ozs7T0FHUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFhLFNBQVMsTUFBTTtRQUMzQyxXQUFVO2tCQUZaLENBSUUsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztrQkFDbkIsd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztnQkFDeEI7Ozs7OztPQUVSLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsS0FBSztRQUNMLFVBQVU7UUFDVixRQUFPO1FBQ1AsV0FBVTtPQUNYOzs7OztNQUNFOzs7Ozs7SUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxZQUFEO1FBQVksTUFBTTtRQUFJLFdBQVU7T0FBb0I7Ozs7aUJBQ3BELHdCQUFDLFFBQUQsWUFBTSwwQkFBNkI7Ozs7ZUFDakM7Ozs7O2dCQUNKLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFxTDtNQUUvTDs7OztjQUNIOzs7Ozs7S0FFTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBNkQ7S0FFdkU7Ozs7O0tBR0gsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBTSxNQUFNO1FBQUksV0FBVTtPQUErQzs7OztpQkFDekUsd0JBQUMsUUFBRCxZQUFNLGlDQUFvQzs7OztlQUN2Qzs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsUUFBUTtNQUNSOzs7O2NBQ0E7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsVUFBRDtRQUNFLGVBQWUsa0JBQWtCLElBQUk7UUFDckMsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFlBQUQsRUFBWSxNQUFNLEdBQUs7Ozs7a0JBQ3ZCLHdCQUFDLFFBQUQsWUFBTSxxQ0FBd0M7Ozs7Z0JBQ3hDOzs7Ozs7T0FHUCxRQUFRLGVBQWUsUUFBUSxjQUM5Qix3QkFBQyxLQUFEO1FBQ0UsTUFBTSxRQUFRO1FBQ2QsVUFBVSxRQUFRLFlBQVk7UUFDOUIsV0FBVTtrQkFIWixDQUtFLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7a0JBQ3JCLHdCQUFDLFFBQUQ7U0FBTTtTQUFtQixRQUFRO1NBQVM7U0FBSSxRQUFRO1NBQVM7UUFBTzs7OztnQkFDckU7Ozs7O2tCQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsYUFBRDtVQUFhLE1BQU07VUFBSSxXQUFVO1NBQWtCOzs7O21CQUNuRCx3QkFBQyxRQUFELFlBQU0sOENBQWlEOzs7O2lCQUNuRDs7Ozs7a0JBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJDO1FBQTJCOzs7O2dCQUNuRjs7Ozs7O09BSVAsd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxVQUFVO1FBQ1YsV0FBVTtrQkFIWixDQUtFLHdCQUFDLFVBQUQ7U0FBVSxNQUFNO1NBQUksV0FBVTtRQUFvQjs7OztrQkFDbEQsd0JBQUMsUUFBRCxZQUNHLG1CQUNHLGtDQUNBLHNDQUNBOzs7O2dCQUNBOzs7Ozs7TUFDTDs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7Z0JBQzFCLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7Y0FDaEM7Ozs7OztLQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUE2QztLQUV2RDs7Ozs7S0FFSCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUVFLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7aUJBQ3RCLHdCQUFDLFFBQUQsWUFBTSwyQ0FBOEM7Ozs7ZUFDOUM7Ozs7O2dCQUdSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7aUJBQ25CLHdCQUFDLFFBQUQsWUFBTSx3Q0FBMkM7Ozs7ZUFDM0M7Ozs7O2NBQ0w7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBK0M7SUFFekQ7Ozs7Y0FDSCx3QkFBQyxLQUFELFlBQUcsMERBQTBEOzs7O1lBQzFEOzs7Ozs7R0FHTCx3QkFBQyxpQkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLGtCQUFrQixLQUFLO0dBQ3ZDOzs7OztFQUNFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZXR0aW5nc1RhYi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VSZWYsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBNb29uLCBcbiAgU3VuLCBcbiAgRG93bmxvYWQsIFxuICBVcGxvYWQsIFxuICBSb3RhdGVDY3csIFxuICBUcmFzaDIsIFxuICBCZWxsLCBcbiAgQmVsbFJpbmcsIFxuICBJbmZvLCBcbiAgU2hpZWxkQ2hlY2ssIFxuICBTbWFydHBob25lLCBcbiAgQ2hlY2ssIFxuICBBbGVydFRyaWFuZ2xlLFxuICBBbGVydENpcmNsZSxcbiAgU3BhcmtsZXMsXG4gIEZpbGVUZXh0XG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBBcHBTZXR0aW5ncywgSGFiaXQgfSBmcm9tICcuLi90eXBlcy9oYWJpdCc7XG5pbXBvcnQgeyBcbiAgZXhwb3J0QWxsRGF0YSwgXG4gIGltcG9ydEFsbERhdGEsIFxuICBnZXRUb2RheURhdGVTdHJpbmcgXG59IGZyb20gJy4uL3NlcnZpY2VzL3N0b3JhZ2VTZXJ2aWNlJztcbmltcG9ydCB7IFxuICBjaGVja05vdGlmaWNhdGlvblN0YXR1cywgXG4gIHJlcXVlc3ROb3RpZmljYXRpb25QZXJtaXNzaW9uLCBcbiAgc2VuZFRlc3ROb3RpZmljYXRpb24sIFxuICBOb3RpZmljYXRpb25TdGF0dXMgXG59IGZyb20gJy4uL3NlcnZpY2VzL25vdGlmaWNhdGlvblNlcnZpY2UnO1xuaW1wb3J0IHsgQW5kcm9pZEFwa01vZGFsIH0gZnJvbSAnLi9BbmRyb2lkQXBrTW9kYWwnO1xuaW1wb3J0IHsgZ2V0QXBrQnVpbGRJbmZvLCBkb3dubG9hZEFuZHJvaWRQcm9qZWN0WmlwIH0gZnJvbSAnLi4vc2VydmljZXMvYW5kcm9pZEV4cG9ydFNlcnZpY2UnO1xuXG5pbnRlcmZhY2UgU2V0dGluZ3NUYWJQcm9wcyB7XG4gIHNldHRpbmdzOiBBcHBTZXR0aW5ncztcbiAgb25VcGRhdGVTZXR0aW5nczogKG5ld1NldHRpbmdzOiBBcHBTZXR0aW5ncykgPT4gdm9pZDtcbiAgaGFiaXRzOiBIYWJpdFtdO1xuICBvblJlcXVlc3RSZXNldERhdGE6ICgpID0+IHZvaWQ7XG4gIG9uUmVxdWVzdFJlc3RvcmVEZWZhdWx0czogKCkgPT4gdm9pZDtcbiAgb25EYXRhSW1wb3J0ZWQ6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTZXR0aW5nc1RhYjogUmVhY3QuRkM8U2V0dGluZ3NUYWJQcm9wcz4gPSAoe1xuICBzZXR0aW5ncyxcbiAgb25VcGRhdGVTZXR0aW5ncyxcbiAgaGFiaXRzLFxuICBvblJlcXVlc3RSZXNldERhdGEsXG4gIG9uUmVxdWVzdFJlc3RvcmVEZWZhdWx0cyxcbiAgb25EYXRhSW1wb3J0ZWQsXG59KSA9PiB7XG4gIGNvbnN0IFtub3RpZlN0YXR1cywgc2V0Tm90aWZTdGF0dXNdID0gdXNlU3RhdGU8Tm90aWZpY2F0aW9uU3RhdHVzPihjaGVja05vdGlmaWNhdGlvblN0YXR1cygpKTtcbiAgY29uc3QgW2ltcG9ydE1lc3NhZ2UsIHNldEltcG9ydE1lc3NhZ2VdID0gdXNlU3RhdGU8eyB0ZXh0OiBzdHJpbmc7IGlzRXJyb3I6IGJvb2xlYW4gfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdGVzdE5vdGlmU3VjY2Vzcywgc2V0VGVzdE5vdGlmU3VjY2Vzc10gPSB1c2VTdGF0ZTxib29sZWFuIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc0Fwa01vZGFsT3Blbiwgc2V0SXNBcGtNb2RhbE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNEb3dubG9hZGluZ1ppcCwgc2V0SXNEb3dubG9hZGluZ1ppcF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IGFwa0luZm8gPSBnZXRBcGtCdWlsZEluZm8oKTtcbiAgY29uc3QgZmlsZUlucHV0UmVmID0gdXNlUmVmPEhUTUxJbnB1dEVsZW1lbnQ+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0Tm90aWZTdGF0dXMoY2hlY2tOb3RpZmljYXRpb25TdGF0dXMoKSk7XG4gIH0sIFtdKTtcblxuICBjb25zdCBoYW5kbGVEb3dubG9hZFppcCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgc2V0SXNEb3dubG9hZGluZ1ppcCh0cnVlKTtcbiAgICAgIGF3YWl0IGRvd25sb2FkQW5kcm9pZFByb2plY3RaaXAoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdaSVAgZG93bmxvYWQgZXJyb3I6JywgZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzRG93bmxvYWRpbmdaaXAoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICAvLyBUaGVtZSB0b2dnbGVcbiAgY29uc3QgdG9nZ2xlVGhlbWUgPSAodGhlbWU6ICdsaWdodCcgfCAnZGFyaycpID0+IHtcbiAgICBvblVwZGF0ZVNldHRpbmdzKHsgLi4uc2V0dGluZ3MsIHRoZW1lIH0pO1xuICB9O1xuXG4gIC8vIEV4cG9ydCBKU09OIGZpbGUgZG93bmxvYWRcbiAgY29uc3QgaGFuZGxlRXhwb3J0RGF0YSA9ICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVN0ciA9IGV4cG9ydEFsbERhdGEoKTtcbiAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbZGF0YVN0cl0sIHsgdHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nIH0pO1xuICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgICBjb25zdCBkYXRlU3RyID0gZ2V0VG9kYXlEYXRlU3RyaW5nKCk7XG4gICAgICBsaW5rLmhyZWYgPSB1cmw7XG4gICAgICBsaW5rLmRvd25sb2FkID0gYGRhaWx5LWhhYml0cy1iYWNrdXAtJHtkYXRlU3RyfS5qc29uYDtcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgICBsaW5rLmNsaWNrKCk7XG4gICAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGxpbmspO1xuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0V4cG9ydCBmYWlsZWQnLCBlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSW1wb3J0IEpTT04gZmlsZVxuICBjb25zdCBoYW5kbGVGaWxlQ2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBpZiAoIWNvbnRlbnQpIHJldHVybjtcblxuICAgICAgY29uc3QgcmVzdWx0ID0gaW1wb3J0QWxsRGF0YShjb250ZW50KTtcbiAgICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICBzZXRJbXBvcnRNZXNzYWdlKHsgdGV4dDogcmVzdWx0Lm1lc3NhZ2UsIGlzRXJyb3I6IGZhbHNlIH0pO1xuICAgICAgICBvbkRhdGFJbXBvcnRlZCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0SW1wb3J0TWVzc2FnZSh7IHRleHQ6IHJlc3VsdC5tZXNzYWdlLCBpc0Vycm9yOiB0cnVlIH0pO1xuICAgICAgfVxuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc1RleHQoZmlsZSk7XG4gICAgLy8gUmVzZXQgZmlsZSBpbnB1dCB2YWx1ZSBzbyBzYW1lIGZpbGUgY2FuIGJlIHNlbGVjdGVkIGFnYWluXG4gICAgZS50YXJnZXQudmFsdWUgPSAnJztcbiAgfTtcblxuICAvLyBSZXF1ZXN0IE5vdGlmaWNhdGlvbiBwZXJtaXNzaW9uXG4gIGNvbnN0IGhhbmRsZUVuYWJsZU5vdGlmaWNhdGlvbnMgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcGVybSA9IGF3YWl0IHJlcXVlc3ROb3RpZmljYXRpb25QZXJtaXNzaW9uKCk7XG4gICAgc2V0Tm90aWZTdGF0dXMoY2hlY2tOb3RpZmljYXRpb25TdGF0dXMoKSk7XG4gICAgaWYgKHBlcm0gPT09ICdncmFudGVkJykge1xuICAgICAgb25VcGRhdGVTZXR0aW5ncyh7IC4uLnNldHRpbmdzLCBub3RpZmljYXRpb25zRW5hYmxlZDogdHJ1ZSB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy8gU2VuZCBUZXN0IE5vdGlmaWNhdGlvblxuICBjb25zdCBoYW5kbGVUZXN0Tm90aWZpY2F0aW9uID0gKCkgPT4ge1xuICAgIGNvbnN0IHN1Y2Nlc3MgPSBzZW5kVGVzdE5vdGlmaWNhdGlvbigpO1xuICAgIHNldFRlc3ROb3RpZlN1Y2Nlc3Moc3VjY2Vzcyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRUZXN0Tm90aWZTdWNjZXNzKG51bGwpLCA0MDAwKTtcbiAgfTtcblxuICAvLyBDb3VudCBoYWJpdHMgd2l0aCByZW1pbmRlcnNcbiAgY29uc3QgaGFiaXRzV2l0aFJlbWluZGVycyA9IGhhYml0cy5maWx0ZXIoKGgpID0+ICFoLmlzUGF1c2VkICYmIEJvb2xlYW4oaC5yZW1pbmRlclRpbWUpKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicGItMjQgcHQtNCBweC00IG1heC13LW1kIG14LWF1dG8gc3BhY2UteS01XCI+XG4gICAgICB7LyogUGFnZSBUaXRsZSAqL31cbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgIOCkuOClh+Ckn+Ckv+CkguCkl+CljeCkuCDgpJTgpLAg4KSh4KWH4KSf4KS+IOCkuOClgeCksOCkleCljeCkt+CkvlxuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICDgpJDgpKog4KSV4KWAIOCkquCljeCksOCkvuCkpeCkruCkv+CkleCkpOCkvuCkj+Ckgiwg4KSs4KWI4KSV4KSF4KSqIOCklOCksCDgpJfgpYvgpKrgpKjgpYDgpK/gpKTgpL4g4KS44KWH4KSf4KS/4KSC4KSX4KWN4KS4XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVGhlbWUgU2VsZWN0aW9uIFNlY3Rpb24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTN4bCBiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC84MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgc2hhZG93LXhzIHNwYWNlLXktM1wiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgdGV4dC1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIHtzZXR0aW5ncy50aGVtZSA9PT0gJ2RhcmsnID8gPE1vb24gc2l6ZT17MTZ9IC8+IDogPFN1biBzaXplPXsxNn0gLz59XG4gICAgICAgICAgPHNwYW4+4KSl4KWA4KSuICjgpLDgpILgpJcg4KSw4KWC4KSqKTwvc3Bhbj5cbiAgICAgICAgPC9oMz5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVUaGVtZSgnbGlnaHQnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgc2V0dGluZ3MudGhlbWUgPT09ICdsaWdodCdcbiAgICAgICAgICAgICAgICA/ICdib3JkZXItZW1lcmFsZC02MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwIHRleHQtZW1lcmFsZC04MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIHJpbmctMiByaW5nLWVtZXJhbGQtNTAwLzQwJ1xuICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtNzAwIGJnLXN0b25lLTUwIGRhcms6Ymctc3RvbmUtODAwLzUwIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8U3VuIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7gpLLgpL7gpIfgpJ8g4KSu4KWL4KShPC9zcGFuPlxuICAgICAgICAgICAge3NldHRpbmdzLnRoZW1lID09PSAnbGlnaHQnICYmIDxDaGVjayBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMFwiIC8+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlVGhlbWUoJ2RhcmsnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgc2V0dGluZ3MudGhlbWUgPT09ICdkYXJrJ1xuICAgICAgICAgICAgICAgID8gJ2JvcmRlci1lbWVyYWxkLTYwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgdGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgcmluZy0yIHJpbmctZW1lcmFsZC01MDAvNDAnXG4gICAgICAgICAgICAgICAgOiAnYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgYmctc3RvbmUtNTAgZGFyazpiZy1zdG9uZS04MDAvNTAgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxNb29uIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWluZGlnby00MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+4KSh4KS+4KSw4KWN4KSVIOCkruCli+CkoTwvc3Bhbj5cbiAgICAgICAgICAgIHtzZXR0aW5ncy50aGVtZSA9PT0gJ2RhcmsnICYmIDxDaGVjayBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMFwiIC8+fVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUmVtaW5kZXJzICYgTm90aWZpY2F0aW9ucyBTZWN0aW9uIHdpdGggSG9uZXN0IExpbWl0YXRpb24gTm90aWNlICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0zeGwgYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAvODAgZGFyazpib3JkZXItc3RvbmUtODAwIHNoYWRvdy14cyBzcGFjZS15LTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgdGV4dC1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPEJlbGwgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+4KSw4KS/4KSu4KS+4KSH4KSC4KSh4KSwIOCklOCksCDgpKjgpYvgpJ/gpL/gpKvgpL/gpJXgpYfgpLbgpKg8L3NwYW4+XG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtMzAwXCI+XG4gICAgICAgICAgICB7aGFiaXRzV2l0aFJlbWluZGVycy5sZW5ndGh9IOCkuOCkleCljeCksOCkv+CkryDgpLDgpL/gpK7gpL7gpIfgpILgpKHgpLBcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDdXJyZW50IEJyb3dzZXIgU3RhdHVzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQtMnhsIGJnLXN0b25lLTUwIGRhcms6Ymctc3RvbmUtODAwLzYwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwLzYwIGRhcms6Ym9yZGVyLXN0b25lLTcwMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS0zMDBcIj7gpIXgpKjgpYHgpK7gpKTgpL8g4KS44KWN4KSl4KS/4KSk4KS/Ojwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMC41IHJvdW5kZWQtbWQgdGV4dC1bMTFweF0gZm9udC1ib2xkICR7XG4gICAgICAgICAgICAgIG5vdGlmU3RhdHVzLnBlcm1pc3Npb24gPT09ICdncmFudGVkJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtMTAwIHRleHQtZW1lcmFsZC04MDAgZGFyazpiZy1lbWVyYWxkLTk1MCBkYXJrOnRleHQtZW1lcmFsZC0zMDAnXG4gICAgICAgICAgICAgICAgOiBub3RpZlN0YXR1cy5wZXJtaXNzaW9uID09PSAnZGVuaWVkJ1xuICAgICAgICAgICAgICAgID8gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwIGRhcms6YmctcmVkLTk1MCBkYXJrOnRleHQtcmVkLTMwMCdcbiAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci0xMDAgdGV4dC1hbWJlci04MDAgZGFyazpiZy1hbWJlci05NTAgZGFyazp0ZXh0LWFtYmVyLTMwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAge25vdGlmU3RhdHVzLnBlcm1pc3Npb24gPT09ICdncmFudGVkJ1xuICAgICAgICAgICAgICAgID8gJ+CkuOCkleCljeCksOCkv+CkryAo4KSF4KSo4KWB4KSu4KSk4KS/IOCkquCljeCksOCkvuCkquCljeCkpCknXG4gICAgICAgICAgICAgICAgOiBub3RpZlN0YXR1cy5wZXJtaXNzaW9uID09PSAnZGVuaWVkJ1xuICAgICAgICAgICAgICAgID8gJ+CkheCkuOCljeCkteClgOCkleClg+CkpCdcbiAgICAgICAgICAgICAgICA6ICfgpIXgpKjgpYHgpK7gpKTgpL8g4KSo4KS54KWA4KSCIOCkpuClgCDgpJfgpIgnfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgIHtub3RpZlN0YXR1cy5leHBsYW5hdGlvbkhpbmRpfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zIGZvciBOb3RpZmljYXRpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBnYXAtMiBwdC0xXCI+XG4gICAgICAgICAge25vdGlmU3RhdHVzLnBlcm1pc3Npb24gIT09ICdncmFudGVkJyAmJiBub3RpZlN0YXR1cy5pc1N1cHBvcnRlZCAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUVuYWJsZU5vdGlmaWNhdGlvbnN9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHJvdW5kZWQteGwgYmctZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC04MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEJlbGxSaW5nIHNpemU9ezE1fSAvPlxuICAgICAgICAgICAgICA8c3Bhbj7gpKjgpYvgpJ/gpL/gpKvgpL/gpJXgpYfgpLbgpKgg4KSV4KWAIOCkheCkqOClgeCkruCkpOCkvyDgpKbgpYfgpII8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge25vdGlmU3RhdHVzLnBlcm1pc3Npb24gPT09ICdncmFudGVkJyAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVRlc3ROb3RpZmljYXRpb259XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHJvdW5kZWQteGwgYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwIGhvdmVyOmJnLXN0b25lLTIwMCBkYXJrOmhvdmVyOmJnLXN0b25lLTcwMCB0ZXh0LXN0b25lLTgwMCBkYXJrOnRleHQtc3RvbmUtMjAwIGZvbnQtYm9sZCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+4KSq4KSw4KWA4KSV4KWN4KS34KSjIChUZXN0KSDgpKjgpYvgpJ/gpL/gpKvgpL/gpJXgpYfgpLbgpKgg4KSt4KWH4KSc4KWH4KSCPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAge3Rlc3ROb3RpZlN1Y2Nlc3MgIT09IG51bGwgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgJHtcbiAgICAgICAgICAgIHRlc3ROb3RpZlN1Y2Nlc3NcbiAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzUwIHRleHQtZW1lcmFsZC04MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAnXG4gICAgICAgICAgICAgIDogJ2JnLXJlZC01MCBkYXJrOmJnLXJlZC05NTAvNTAgdGV4dC1yZWQtODAwIGRhcms6dGV4dC1yZWQtMzAwIGJvcmRlciBib3JkZXItcmVkLTIwMCdcbiAgICAgICAgICB9YH0+XG4gICAgICAgICAgICB7dGVzdE5vdGlmU3VjY2Vzc1xuICAgICAgICAgICAgICA/ICfgpLjgpKvgpLLgpKTgpL4hIOCkquCksOClgOCkleCljeCkt+CkoyDgpKjgpYvgpJ/gpL/gpKvgpL/gpJXgpYfgpLbgpKgg4KSt4KWH4KScIOCkpuCkv+Ckr+CkviDgpJfgpK/gpL4g4KS54KWI4KWkJ1xuICAgICAgICAgICAgICA6ICfgpKrgpLDgpYDgpJXgpY3gpLfgpKMg4KSo4KWL4KSf4KS/4KSr4KS/4KSV4KWH4KS24KSoIOCkreClh+CknOCkqOClhyDgpK7gpYfgpIIg4KS14KS/4KSr4KSy4KWkIOCkleClg+CkquCkr+CkviDgpJzgpL7gpILgpJrgpYfgpIIg4KSV4KS/IOCkrOCljeCksOCkvuCkieCknOCkvOCksCDgpLjgpYLgpJrgpKjgpL7gpI/gpIIg4KSs4KWN4KSy4KWJ4KSVIOCkpOCliyDgpKjgpLngpYDgpIIg4KS54KWI4KSC4KWkJ31cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogVHJhbnNwYXJlbnQgTGltaXRhdGlvbiBEaXNjbG9zdXJlICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLTJ4bCBiZy1hbWJlci01MC83MCBkYXJrOmJnLWFtYmVyLTk1MC8zMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMC82MCBkYXJrOmJvcmRlci1hbWJlci04MDAvNjAgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41IHRleHQtWzExcHhdIHRleHQtYW1iZXItOTAwIGRhcms6dGV4dC1hbWJlci0zMDBcIj5cbiAgICAgICAgICA8SW5mbyBzaXplPXsxNn0gY2xhc3NOYW1lPVwic2hyaW5rLTAgbXQtMC41IHRleHQtYW1iZXItNjAwIGRhcms6dGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgPHN0cm9uZz7gpIjgpK7gpL7gpKjgpKbgpL7gpLAg4KSk4KSV4KSo4KWA4KSV4KWAIOCknOCkvuCkqOCkleCkvuCksOClgDo8L3N0cm9uZz4g4KS14KWH4KSsIOCkrOCljeCksOCkvuCkieCknOCkvOCksCDgpLXgpL7gpKTgpL7gpLXgpLDgpKMg4KSu4KWH4KSCLCDgpLDgpL/gpK7gpL7gpIfgpILgpKHgpLAg4KSV4KWH4KS14KSyIOCkpOCkreClgCDgpKzgpJzgpKTgpYcg4KS54KWI4KSCIOCknOCkrCDgpIbgpKrgpJXgpL4g4KSs4KWN4KSw4KS+4KSJ4KSc4KS84KSwIOCkr+CkviDgpJDgpKog4KS44KSV4KWN4KSw4KS/4KSvIOCkueCli+ClpCDgpK/gpLkg4KS44KWN4KSf4KWI4KSC4KSh4KSF4KSy4KWL4KSoIOCkteClh+CkrCDgpKrgpY3gpLDgpYvgpJ/gpYvgpJ/gpL7gpIfgpKog4KS54KWILCDgpIfgpLjgpLLgpL/gpI8g4KSr4KWL4KSoIOCksuClieCklSDgpLngpYvgpKjgpYcg4KSv4KS+IOCkrOCljeCksOCkvuCkieCknOCkvOCksCDgpKrgpYLgpLDgpYAg4KSk4KSw4KS5IOCkrOCkguCkpiDgpLngpYvgpKjgpYcg4KSq4KSwIOCkuOCljeCkteCkmuCkvuCksuCkv+CkpCDgpLXgpYfgpJUt4KSF4KSqIOCkqOCli+Ckn+Ckv+Ckq+Ckv+CkleClh+CktuCkqCDgpLjgpYDgpK7gpL/gpKQg4KS54KWLIOCkuOCkleCkpOClhyDgpLngpYjgpILgpaRcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBEYXRhIEJhY2t1cCAmIFJlc3RvcmUgU2VjdGlvbiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtM3hsIGJnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwLzgwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBzaGFkb3cteHMgc3BhY2UteS0zXCI+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCB0ZXh0LXNtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPFNoaWVsZENoZWNrIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICA8c3Bhbj7gpKHgpYfgpJ/gpL4g4KSs4KWI4KSV4KSF4KSqIOCkj+CkteCkgiDgpLDgpYDgpLjgpY3gpJ/gpYvgpLAgKEpTT04pPC9zcGFuPlxuICAgICAgICA8L2gzPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICDgpIbgpKrgpJXgpL4g4KSq4KWC4KSw4KS+IOCkoeClh+Ckn+CkviDgpIbgpKrgpJXgpYcg4KSh4KS/4KS14KS+4KSH4KS4IOCkleClhyDgpLLgpYvgpJXgpLIg4KS44KWN4KSf4KWL4KSw4KWH4KScIOCkruClh+CkgiDgpLjgpYHgpLDgpJXgpY3gpLfgpL/gpKQg4KSw4KS54KSk4KS+IOCkueCliOClpCDgpIbgpKog4KSV4KSt4KWAIOCkreClgCDgpKzgpYjgpJXgpIXgpKog4KSr4KS84KS+4KSH4KSyIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpJXgpLAg4KS44KSV4KSk4KWHIOCkueCliOCkguClpFxuICAgICAgICA8L3A+XG5cbiAgICAgICAge2ltcG9ydE1lc3NhZ2UgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgdGV4dC14cyBmb250LXNlbWlib2xkICR7XG4gICAgICAgICAgICBpbXBvcnRNZXNzYWdlLmlzRXJyb3JcbiAgICAgICAgICAgICAgPyAnYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC80MCB0ZXh0LXJlZC03MDAgZGFyazp0ZXh0LXJlZC0zMDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwJ1xuICAgICAgICAgICAgICA6ICdiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCdcbiAgICAgICAgICB9YH0+XG4gICAgICAgICAgICB7aW1wb3J0TWVzc2FnZS50ZXh0fVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyBwdC0xXCI+XG4gICAgICAgICAgey8qIEV4cG9ydCBCdXR0b24gKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0RGF0YX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLTJ4bCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgaG92ZXI6YmctZW1lcmFsZC0xMDAgZGFyazpob3ZlcjpiZy1lbWVyYWxkLTk1MCB0ZXh0LWVtZXJhbGQtODAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwLzgwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwLzYwIGZvbnQtYm9sZCB0ZXh0LXhzIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbiBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RG93bmxvYWQgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgICA8c3Bhbj7gpKHgpYfgpJ/gpL4g4KSo4KS/4KSw4KWN4KSv4KS+4KSkIChFeHBvcnQpPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIEltcG9ydCBCdXR0b24gKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwIGhvdmVyOmJnLXN0b25lLTIwMCBkYXJrOmhvdmVyOmJnLXN0b25lLTcwMCB0ZXh0LXN0b25lLTgwMCBkYXJrOnRleHQtc3RvbmUtMjAwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTcwMCBmb250LWJvbGQgdGV4dC14cyBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24gYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFVwbG9hZCBzaXplPXsxOH0gLz5cbiAgICAgICAgICAgIDxzcGFuPuCkoeClh+Ckn+CkviDgpIbgpK/gpL7gpKQgKEltcG9ydCk8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgIHJlZj17ZmlsZUlucHV0UmVmfVxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUZpbGVDaGFuZ2V9XG4gICAgICAgICAgICBhY2NlcHQ9XCIuanNvbixhcHBsaWNhdGlvbi9qc29uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlblwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEFuZHJvaWQgQXBwIERvd25sb2FkICYgRXhwb3J0IFNlY3Rpb24gKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTN4bCBiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC84MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgc2hhZG93LXhzIHNwYWNlLXktMy41XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxTbWFydHBob25lIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkFuZHJvaWQg4KSQ4KSqIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpJXgpLDgpYfgpII8L3NwYW4+XG4gICAgICAgICAgPC9oMz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC83MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwLzcwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwLzYwXCI+XG4gICAgICAgICAgICBBbmRyb2lkIChBUEspXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAg4KSH4KS4IOCkkOCkqiDgpJXgpYsg4KSF4KSq4KSo4KWHIOCkj+CkguCkoeCljeCksOClieCkh+CkoSDgpKvgpYvgpKgg4KSu4KWH4KSCIOCkuOClgOCkp+ClhyDgpJDgpKogKEFQSykg4KSV4KWHIOCksOClguCkqiDgpK7gpYfgpIIg4KSH4KSC4KS44KWN4KSf4KWJ4KSyIOCkleCksOCkqOClhyDgpJTgpLAg4KSJ4KSq4KSv4KWL4KSXIOCkleCksOCkqOClhyDgpJXgpYAg4KS44KSu4KWN4KSq4KWC4KSw4KWN4KSjIOCknOCkvuCkqOCkleCkvuCksOClgOClpFxuICAgICAgICA8L3A+XG5cbiAgICAgICAgey8qIEhvbmVzdCBFbnZpcm9ubWVudCBMaW1pdGF0aW9uIE5vdGljZSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBiZy1hbWJlci01MC83MCBkYXJrOmJnLWFtYmVyLTk1MC8zMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMC83MCBkYXJrOmJvcmRlci1hbWJlci04MDAvNjAgc3BhY2UteS0yIHRleHQteHNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYW1iZXItOTAwIGRhcms6dGV4dC1hbWJlci0zMDAgZm9udC1ib2xkIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxJbmZvIHNpemU9ezE1fSBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTYwMCBkYXJrOnRleHQtYW1iZXItNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPuCkpOCkleCkqOClgOCkleClgCDgpJzgpL7gpKjgpJXgpL7gpLDgpYAg4KSP4KS14KSCIEFQSyDgpLjgpY3gpKXgpL/gpKTgpL86PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYW1iZXItODAwIGRhcms6dGV4dC1hbWJlci0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICB7YXBrSW5mby5saW1pdGF0aW9uRXhwbGFuYXRpb25IaW5kaX1cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgcHQtMVwiPlxuICAgICAgICAgIHsvKiBIb3cgdG8gYnVpbGQgYW5kIGRvd25sb2FkIGd1aWRlIGJ1dHRvbiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0Fwa01vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIHB4LTQgcm91bmRlZC0yeGwgYmctZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC04MDAgYWN0aXZlOnNjYWxlLTk4IHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciBzaGFkb3cteHNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxTbWFydHBob25lIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgPHNwYW4+QVBLIOCkrOCkqOCkvuCkqOClhyDgpJTgpLAg4KSh4KS+4KSJ4KSo4KSy4KWL4KShIOCkleCksOCkqOClhyDgpJXgpL4g4KSk4KSw4KWA4KSV4KS+PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIERvd25sb2FkIEFQSyBCdXR0b24gLSBPbmx5IGFjdGl2ZSB3aGVuIGEgcmVhbCwgc3VjY2Vzc2Z1bGx5IGNvbXBpbGVkIEFQSyBpcyBwcmVzZW50ICovfVxuICAgICAgICAgIHthcGtJbmZvLmlzQXZhaWxhYmxlICYmIGFwa0luZm8uZG93bmxvYWRVcmwgPyAoXG4gICAgICAgICAgICA8YVxuICAgICAgICAgICAgICBocmVmPXthcGtJbmZvLmRvd25sb2FkVXJsfVxuICAgICAgICAgICAgICBkb3dubG9hZD17YXBrSW5mby5maWxlTmFtZSB8fCAnYXBwLWRlYnVnLmFwayd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgcHgtNCByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgPHNwYW4+QVBLIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpJXgpLDgpYfgpIIgKHthcGtJbmZvLmZpbGVOYW1lfSDigKIge2Fwa0luZm8uZmlsZVNpemV9KTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yLjUgcm91bmRlZC14bCBiZy1zdG9uZS0xMDAgZGFyazpiZy1zdG9uZS04MDAvNjAgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAvNjAgZGFyazpib3JkZXItc3RvbmUtNzAwLzYwIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1zdG9uZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPuCkuOClgOCkp+CkviDgpLjgpLDgpY3gpLXgpLAgQVBLOiDgpIngpKrgpLLgpKzgpY3gpKcg4KSo4KS54KWA4KSCICjgpKrgpL7gpLDgpKbgpLDgpY3gpLbgpYAg4KSo4KWA4KSk4KS/KTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc3RvbmUtNDAwIHRleHQtWzEwcHhdXCI+QW5kcm9pZCBTdHVkaW8g4KSG4KS14KS24KWN4KSv4KSVPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBEb3dubG9hZCBQcm9qZWN0IFpJUCAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFppcH1cbiAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nWmlwfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBweC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtNzAwIGhvdmVyOmJnLXN0b25lLTUwIGRhcms6aG92ZXI6Ymctc3RvbmUtODAwIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDAgZm9udC1zZW1pYm9sZCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAge2lzRG93bmxvYWRpbmdaaXBcbiAgICAgICAgICAgICAgICA/ICfgpJzgpLzgpL/gpKog4KSr4KS84KS+4KSH4KSyIOCkpOCliOCkr+CkvuCksCDgpLngpYsg4KSw4KS54KWAIOCkueCliC4uLidcbiAgICAgICAgICAgICAgICA6ICfgpKrgpY3gpLDgpYvgpJzgpYfgpJXgpY3gpJ8g4KSr4KS+4KSH4KSy4KWN4KS4IChaSVApIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpJXgpLDgpYfgpIInfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRGVmYXVsdHMgJiBEYW5nZXIgWm9uZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC01IHJvdW5kZWQtM3hsIGJnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIGJvcmRlciBib3JkZXItcmVkLTIwMC82MCBkYXJrOmJvcmRlci1yZWQtOTUwLzYwIHNoYWRvdy14cyBzcGFjZS15LTNcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgdGV4dC1zbSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgIDxBbGVydFRyaWFuZ2xlIHNpemU9ezE2fSAvPlxuICAgICAgICAgIDxzcGFuPuCkoeClh+Ckn+CkviDgpKrgpY3gpLDgpKzgpILgpKfgpKgg4KSP4KS14KSCIOCksOClgOCkuOClh+Cknzwvc3Bhbj5cbiAgICAgICAgPC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAg4KSV4KWD4KSq4KSv4KS+IOCkuOCkvuCkteCkp+CkvuCkqOClgCDgpLjgpYcg4KSJ4KSq4KSv4KWL4KSXIOCkleCksOClh+CkguClpCDgpLDgpYDgpLjgpYfgpJ8g4KSV4KSw4KSo4KWHIOCkuOClhyDgpKrgpLngpLLgpYcg4KSq4KWB4KS34KWN4KSf4KS/IOCkquClguCkm+ClgCDgpJzgpL7gpI/gpJfgpYDgpaRcbiAgICAgICAgPC9wPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHB0LTFcIj5cbiAgICAgICAgICB7LyogUmVzdG9yZSBTdGFydGVyIEhhYml0cyAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvblJlcXVlc3RSZXN0b3JlRGVmYXVsdHN9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMi41IHB4LTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBob3ZlcjpiZy1zdG9uZS01MCBkYXJrOmhvdmVyOmJnLXN0b25lLTgwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFJvdGF0ZUNjdyBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDxzcGFuPuCkquCljeCksOCkvuCksOCkguCkreCkv+CklSA1IOCkoeCkv+Ckq+CkvOClieCksuCljeCknyDgpIbgpKbgpKTgpYfgpIIg4KSq4KWB4KSo4KSDIOCksuCli+CkoSDgpJXgpLDgpYfgpII8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogUmVzZXQgQWxsIERhdGEgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25SZXF1ZXN0UmVzZXREYXRhfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBweC0zIHJvdW5kZWQteGwgYmctcmVkLTUwIGRhcms6YmctcmVkLTk1MC80MCBob3ZlcjpiZy1yZWQtMTAwIGRhcms6aG92ZXI6YmctcmVkLTkwMC80MCB0ZXh0LXJlZC02MDAgZGFyazp0ZXh0LXJlZC00MDAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIGRhcms6Ym9yZGVyLXJlZC05MDAvNjAgdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFRyYXNoMiBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDxzcGFuPuCkuOCkreClgCDgpIbgpKbgpKTgpYfgpIIg4KS1IOCkh+CkpOCkv+CkueCkvuCkuCDgpKrgpYLgpLDgpY3gpKPgpKTgpIMg4KSw4KWA4KS44KWH4KSfIOCkleCksOClh+Ckgjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEFwcCBWZXJzaW9uICYgQ3JlZGl0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgdGV4dC1bMTFweF0gdGV4dC1zdG9uZS00MDAgZGFyazp0ZXh0LXN0b25lLTYwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICBEYWlseSBIYWJpdHMg4oCTIOCkruClh+CksOClgCDgpIXgpJrgpY3gpJvgpYAg4KSG4KSm4KSk4KWH4KSCIHYxLjBcbiAgICAgICAgPC9wPlxuICAgICAgICA8cD4xMDAlIOCkueCkv+CkguCkpuClgCDgpK7gpYfgpIIsIOCkuOClgeCksOCkleCljeCkt+Ckv+CkpCDgpLjgpY3gpKXgpL7gpKjgpYDgpK8g4KS44KWN4KSf4KWL4KSw4KWH4KScIOCkleClhyDgpLjgpL7gpKUg4KSo4KS/4KSw4KWN4KSu4KS/4KSkPC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBbmRyb2lkIEFQSyBNb2RhbCAqL31cbiAgICAgIDxBbmRyb2lkQXBrTW9kYWxcbiAgICAgICAgaXNPcGVuPXtpc0Fwa01vZGFsT3Blbn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0SXNBcGtNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbiJdfQ==