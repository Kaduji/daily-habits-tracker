const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Circle, Plus, Minus, Flame, Calendar, Clock, Sparkles, Trophy, Check } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=768266e3";
import { HabitIcon, getColorScheme } from "/src/components/HabitIcon.tsx";
import { isHabitScheduledOn, calculateHabitStreak, getMotivationalMessage } from "/src/services/streakService.ts";
import { formatDateToHindi, getTodayDateString } from "/src/services/storageService.ts";
var _jsxFileName = "/app/applet/src/components/TodayTab.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const TodayTab = ({ currentDate, habits, history, onToggleHabit, onUpdateProgress, onOpenAddModal, onNavigateToManage }) => {
	const [filter, setFilter] = useState("all");
	const todayStr = getTodayDateString();
	const isToday = currentDate === todayStr;
	// Selected date object
	const [y, m, d] = currentDate.split("-").map(Number);
	const selectedDateObj = new Date(y, m - 1, d);
	// Active & scheduled habits for this date
	const activeHabits = habits.filter((h) => !h.isPaused);
	const scheduledHabits = activeHabits.filter((h) => isHabitScheduledOn(h, selectedDateObj));
	const dayLogs = history[currentDate] || {};
	// Count completions
	let completedCount = 0;
	scheduledHabits.forEach((h) => {
		if (dayLogs[h.id]?.completed) {
			completedCount++;
		}
	});
	const totalCount = scheduledHabits.length;
	const percentage = totalCount > 0 ? Math.round(completedCount / totalCount * 100) : 0;
	const motivational = getMotivationalMessage(percentage, completedCount, totalCount);
	// Filtered habits
	const filteredHabits = scheduledHabits.filter((h) => {
		const isDone = Boolean(dayLogs[h.id]?.completed);
		if (filter === "pending") return !isDone;
		if (filter === "completed") return isDone;
		return true;
	});
	// Handle celebration
	const handleToggle = (habit) => {
		const wasCompleted = Boolean(dayLogs[habit.id]?.completed);
		onToggleHabit(habit);
		// If this toggle completes the final remaining habit
		if (!wasCompleted && completedCount + 1 === totalCount) {
			try {
				confetti({
					particleCount: 80,
					spread: 70,
					origin: { y: .6 },
					colors: [
						"#059669",
						"#10b981",
						"#34d399",
						"#f59e0b",
						"#3b82f6"
					]
				});
			} catch {}
		}
	};
	const handleIncrement = (habit, delta) => {
		const currentVal = dayLogs[habit.id]?.currentValue || 0;
		const nextVal = Math.max(0, currentVal + delta);
		onUpdateProgress(habit, nextVal);
		if (nextVal >= habit.targetValue && currentVal < habit.targetValue) {
			// Reached target
			if (completedCount + 1 === totalCount) {
				try {
					confetti({
						particleCount: 60,
						spread: 60,
						origin: { y: .6 },
						colors: [
							"#059669",
							"#10b981",
							"#f59e0b"
						]
					});
				} catch {}
			}
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "pb-24 pt-4 px-4 max-w-md mx-auto space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-gradient-to-br from-emerald-800 to-emerald-950 text-white rounded-3xl p-5 shadow-lg border border-emerald-700/50 relative overflow-hidden",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { className: "absolute -top-12 -right-12 w-36 h-36 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-700/60 border border-emerald-600/40 text-[11px] font-semibold text-emerald-200",
									children: [/* @__PURE__ */ _jsxDEV(Calendar, { size: 12 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 15
									}, this), isToday ? "आज का दिन" : formatDateToHindi(currentDate)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-extrabold leading-snug pt-1 text-white",
									children: motivational.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-emerald-200/90 leading-relaxed max-w-xs",
									children: motivational.subtitle
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative shrink-0 flex items-center justify-center",
							children: [/* @__PURE__ */ _jsxDEV("svg", {
								className: "w-20 h-20 transform -rotate-90",
								children: [/* @__PURE__ */ _jsxDEV("circle", {
									cx: "40",
									cy: "40",
									r: "33",
									className: "stroke-emerald-900/80",
									strokeWidth: "7",
									fill: "transparent"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("circle", {
									cx: "40",
									cy: "40",
									r: "33",
									className: "stroke-emerald-400 transition-all duration-500 ease-out",
									strokeWidth: "7",
									strokeDasharray: 207,
									strokeDashoffset: 207 - 207 * percentage / 100,
									strokeLinecap: "round",
									fill: "transparent"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute flex flex-col items-center justify-center",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-base font-black leading-none text-white",
									children: [percentage, "%"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-emerald-300 font-semibold mt-0.5",
									children: "पूर्ण"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 pt-3 border-t border-emerald-700/60 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "text-emerald-100 font-medium",
							children: ["कुल स्थिति: ", /* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-white",
								children: [
									totalCount,
									" में से ",
									completedCount,
									" आदतें पूरी"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 25
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 11
						}, this), percentage === 100 && totalCount > 0 && /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500 text-emerald-950 font-black text-[11px] animate-bounce",
							children: [/* @__PURE__ */ _jsxDEV(Trophy, { size: 12 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 15
							}, this), " शानदार!"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between gap-2 pt-1",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex bg-stone-200/80 dark:bg-stone-800/80 p-1 rounded-2xl text-xs font-semibold",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setFilter("all"),
							className: `px-3 py-1.5 rounded-xl transition cursor-pointer ${filter === "all" ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" : "text-stone-600 dark:text-stone-400 hover:text-stone-900"}`,
							children: [
								"सभी (",
								scheduledHabits.length,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setFilter("pending"),
							className: `px-3 py-1.5 rounded-xl transition cursor-pointer ${filter === "pending" ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" : "text-stone-600 dark:text-stone-400 hover:text-stone-900"}`,
							children: [
								"बाकी (",
								totalCount - completedCount,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setFilter("completed"),
							className: `px-3 py-1.5 rounded-xl transition cursor-pointer ${filter === "completed" ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" : "text-stone-600 dark:text-stone-400 hover:text-stone-900"}`,
							children: [
								"पूरे (",
								completedCount,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 210,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 189,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onOpenAddModal,
					className: "py-1.5 px-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1 shadow-sm transition active:scale-95 cursor-pointer shrink-0",
					children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 15 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 227,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ नई आदत" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 228,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 223,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 187,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3",
				children: filteredHabits.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-stone-900 border border-dashed border-stone-300 dark:border-stone-800 rounded-3xl p-8 text-center space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 mx-auto rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(Sparkles, { size: 24 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-stone-800 dark:text-stone-200 text-base",
							children: filter === "completed" ? "अभी कोई आदत पूरी नहीं हुई है" : filter === "pending" ? "सभी आदतें पूरी हो चुकी हैं! शाबाश!" : "आज के लिए कोई आदत निर्धारित नहीं है"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-stone-500 dark:text-stone-400 mt-1 max-w-xs mx-auto",
							children: filter === "completed" ? "ऊपर दी गई आदतों को पूरा करके यहाँ जोड़ें।" : filter === "pending" ? "आपने आज का सारा काम पूरा कर लिया है।" : "नई आदत जोड़ें या अपनी मौजूदा आदतों की दिन-सूची जांचें।"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 239,
							columnNumber: 13
						}, this),
						scheduledHabits.length === 0 && /* @__PURE__ */ _jsxDEV("button", {
							onClick: onOpenAddModal,
							className: "mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition shadow-xs cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 17
							}, this), " नई आदत जोड़ें"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 256,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 235,
					columnNumber: 11
				}, this) : filteredHabits.map((habit) => {
					const log = dayLogs[habit.id];
					const isCompleted = Boolean(log?.completed);
					const currentVal = log?.currentValue || 0;
					const streak = calculateHabitStreak(habit, history);
					const colorScheme = getColorScheme(habit.color);
					return /* @__PURE__ */ _jsxDEV("div", {
						className: `bg-white dark:bg-stone-900 border transition-all duration-200 rounded-3xl p-4 shadow-xs relative overflow-hidden ${isCompleted ? "border-emerald-300 dark:border-emerald-900/60 bg-emerald-50/20 dark:bg-emerald-950/20" : "border-stone-200/80 dark:border-stone-800 hover:border-stone-300"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-3 flex-1 min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${colorScheme.bg} ${colorScheme.border} ${colorScheme.text}`,
									children: /* @__PURE__ */ _jsxDEV(HabitIcon, {
										name: habit.icon,
										size: 22
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex-1 min-w-0",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5 flex-wrap",
											children: [
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300",
													children: habit.category
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 292,
													columnNumber: 25
												}, this),
												streak.currentStreak > 0 && /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 flex items-center gap-0.5",
													children: [
														/* @__PURE__ */ _jsxDEV(Flame, {
															size: 11,
															className: "fill-amber-500 text-amber-500"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 297,
															columnNumber: 29
														}, this),
														streak.currentStreak,
														" दिन"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 296,
													columnNumber: 27
												}, this),
												habit.reminderTime && /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-medium text-stone-400 dark:text-stone-500 flex items-center gap-0.5",
													children: [
														/* @__PURE__ */ _jsxDEV(Clock, { size: 11 }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 303,
															columnNumber: 29
														}, this),
														" ",
														habit.reminderTime
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 302,
													columnNumber: 27
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 291,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("h4", {
											className: `text-base font-bold mt-1 text-stone-900 dark:text-stone-100 truncate ${isCompleted ? "line-through text-stone-500 dark:text-stone-500" : ""}`,
											children: habit.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 308,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-stone-500 dark:text-stone-400 mt-0.5",
											children: habit.targetType === "numeric" ? /* @__PURE__ */ _jsxDEV("span", { children: [
												"लक्ष्य: ",
												/* @__PURE__ */ _jsxDEV("strong", {
													className: "text-stone-700 dark:text-stone-300",
													children: currentVal
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 320,
													columnNumber: 37
												}, this),
												" / ",
												habit.targetValue,
												" ",
												habit.unit
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 319,
												columnNumber: 27
											}, this) : /* @__PURE__ */ _jsxDEV("span", { children: "दैनिक लक्ष्य: १ बार" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 323,
												columnNumber: 27
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 317,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleToggle(habit),
								title: isCompleted ? "पूरा हुआ (वापस पूर्ववत करने के लिए क्लिक करें)" : "पूरा चिह्नित करें",
								className: `w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 transition-all duration-200 cursor-pointer active:scale-90 ${isCompleted ? "bg-emerald-600 text-white shadow-sm ring-2 ring-emerald-400" : "bg-stone-100 dark:bg-stone-800 text-stone-400 hover:text-emerald-600 dark:hover:text-emerald-400 border border-stone-200 dark:border-stone-700"}`,
								children: isCompleted ? /* @__PURE__ */ _jsxDEV(Check, {
									size: 22,
									strokeWidth: 3
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 339,
									columnNumber: 36
								}, this) : /* @__PURE__ */ _jsxDEV(Circle, {
									size: 22,
									strokeWidth: 2
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 339,
									columnNumber: 74
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 281,
							columnNumber: 17
						}, this), habit.targetType === "numeric" && /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 pt-3 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-1/2 bg-stone-100 dark:bg-stone-800 h-2 rounded-full overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "bg-emerald-600 h-full rounded-full transition-all duration-300",
									style: { width: `${Math.min(100, Math.round(currentVal / habit.targetValue * 100))}%` }
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleIncrement(habit, -1),
										disabled: currentVal <= 0,
										className: "w-7 h-7 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:bg-stone-200 dark:hover:bg-stone-700 flex items-center justify-center text-xs font-bold transition disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer",
										title: "1 घटाएं",
										children: /* @__PURE__ */ _jsxDEV(Minus, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 362,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-stone-800 dark:text-stone-200 px-1 min-w-[32px] text-center",
										children: currentVal
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 365,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleIncrement(habit, 1),
										className: "w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-200 flex items-center justify-center text-xs font-bold transition active:scale-95 cursor-pointer",
										title: "1 बढ़ाएं",
										children: /* @__PURE__ */ _jsxDEV(Plus, { size: 14 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 369,
										columnNumber: 23
									}, this),
									habit.targetValue > 2 && /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onUpdateProgress(habit, habit.targetValue),
										className: "px-2 py-1 rounded-lg bg-stone-100 dark:bg-stone-800 text-[10px] font-semibold text-stone-600 dark:text-stone-300 hover:bg-stone-200 ml-1",
										children: "पूर्ण"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 378,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 355,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 345,
							columnNumber: 19
						}, this)]
					}, habit.id, true, {
						fileName: _jsxFileName,
						lineNumber: 273,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 233,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-6 p-4 rounded-3xl bg-stone-50 dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 text-center",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-stone-600 dark:text-stone-400",
					children: "\"हर दिन की छोटी कोशिशें ही भविष्य की बड़ी उपलब्धियां बनती हैं।\""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 396,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onNavigateToManage,
					className: "mt-2 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline cursor-pointer inline-flex items-center gap-1",
					children: "आदतें व्यवस्थित व संपादित करें →"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 399,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 395,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 119,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUVFLFFBQ0EsTUFDQSxPQUNBLE9BQ0EsVUFDQSxPQUNBLFVBQ0EsUUFFQSxhQUVLO0FBQ1AsT0FBTyxjQUFjO0FBRXJCLFNBQVMsV0FBVyxzQkFBc0I7QUFDMUMsU0FBUyxvQkFBb0Isc0JBQXNCLDhCQUE4QjtBQUNqRixTQUFTLG1CQUFtQiwwQkFBMEI7OztBQWN0RCxPQUFPLE1BQU0sWUFBcUMsRUFDaEQsYUFDQSxRQUNBLFNBQ0EsZUFDQSxrQkFDQSxnQkFDQSx5QkFDSTtDQUNKLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBcUIsS0FBSztDQUV0RCxNQUFNLFdBQVcsbUJBQW1CO0NBQ3BDLE1BQU0sVUFBVSxnQkFBZ0I7O0NBR2hDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsS0FBSyxZQUFZLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxNQUFNO0NBQ25ELE1BQU0sa0JBQWtCLElBQUksS0FBSyxHQUFHLElBQUksR0FBRyxDQUFDOztDQUc1QyxNQUFNLGVBQWUsT0FBTyxRQUFRLE1BQU0sQ0FBQyxFQUFFLFFBQVE7Q0FDckQsTUFBTSxrQkFBa0IsYUFBYSxRQUFRLE1BQU0sbUJBQW1CLEdBQUcsZUFBZSxDQUFDO0NBRXpGLE1BQU0sVUFBVSxRQUFRLGdCQUFnQixDQUFDOztDQUd6QyxJQUFJLGlCQUFpQjtDQUNyQixnQkFBZ0IsU0FBUyxNQUFNO0VBQzdCLElBQUksUUFBUSxFQUFFLEdBQUcsRUFBRSxXQUFXO0dBQzVCO0VBQ0Y7Q0FDRixDQUFDO0NBRUQsTUFBTSxhQUFhLGdCQUFnQjtDQUNuQyxNQUFNLGFBQWEsYUFBYSxJQUFJLEtBQUssTUFBTyxpQkFBaUIsYUFBYyxHQUFHLElBQUk7Q0FDdEYsTUFBTSxlQUFlLHVCQUF1QixZQUFZLGdCQUFnQixVQUFVOztDQUdsRixNQUFNLGlCQUFpQixnQkFBZ0IsUUFBUSxNQUFNO0VBQ25ELE1BQU0sU0FBUyxRQUFRLFFBQVEsRUFBRSxHQUFHLEVBQUUsU0FBUztFQUMvQyxJQUFJLFdBQVcsV0FBVyxPQUFPLENBQUM7RUFDbEMsSUFBSSxXQUFXLGFBQWEsT0FBTztFQUNuQyxPQUFPO0NBQ1QsQ0FBQzs7Q0FHRCxNQUFNLGdCQUFnQixVQUFpQjtFQUNyQyxNQUFNLGVBQWUsUUFBUSxRQUFRLE1BQU0sR0FBRyxFQUFFLFNBQVM7RUFDekQsY0FBYyxLQUFLOztFQUduQixJQUFJLENBQUMsZ0JBQWdCLGlCQUFpQixNQUFNLFlBQVk7R0FDdEQsSUFBSTtJQUNGLFNBQVM7S0FDUCxlQUFlO0tBQ2YsUUFBUTtLQUNSLFFBQVEsRUFBRSxHQUFHLEdBQUk7S0FDakIsUUFBUTtNQUFDO01BQVc7TUFBVztNQUFXO01BQVc7S0FBUztJQUNoRSxDQUFDO0dBQ0gsUUFBUSxDQUVSO0VBQ0Y7Q0FDRjtDQUVBLE1BQU0sbUJBQW1CLE9BQWMsVUFBa0I7RUFDdkQsTUFBTSxhQUFhLFFBQVEsTUFBTSxHQUFHLEVBQUUsZ0JBQWdCO0VBQ3RELE1BQU0sVUFBVSxLQUFLLElBQUksR0FBRyxhQUFhLEtBQUs7RUFDOUMsaUJBQWlCLE9BQU8sT0FBTztFQUUvQixJQUFJLFdBQVcsTUFBTSxlQUFlLGFBQWEsTUFBTSxhQUFhOztHQUVsRSxJQUFJLGlCQUFpQixNQUFNLFlBQVk7SUFDckMsSUFBSTtLQUNGLFNBQVM7TUFDUCxlQUFlO01BQ2YsUUFBUTtNQUNSLFFBQVEsRUFBRSxHQUFHLEdBQUk7TUFDakIsUUFBUTtPQUFDO09BQVc7T0FBVztNQUFTO0tBQzFDLENBQUM7SUFDSCxRQUFRLENBQUM7R0FDWDtFQUNGO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRCxFQUFLLFdBQVUsbUdBQW9HOzs7OztLQUVuSCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OzttQkFDcEIsVUFBVSxjQUFjLGtCQUFrQixXQUFXLENBQ2xEOzs7Ozs7UUFDTix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxhQUFhO1FBQ1o7Ozs7O1FBQ0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsYUFBYTtRQUNiOzs7OztPQUNBOzs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLElBQUc7U0FDSCxJQUFHO1NBQ0gsR0FBRTtTQUNGLFdBQVU7U0FDVixhQUFZO1NBQ1osTUFBSztRQUNOOzs7O2tCQUNELHdCQUFDLFVBQUQ7U0FDRSxJQUFHO1NBQ0gsSUFBRztTQUNILEdBQUU7U0FDRixXQUFVO1NBQ1YsYUFBWTtTQUNaLGlCQUFpQjtTQUNqQixrQkFBa0IsTUFBTyxNQUFNLGFBQWM7U0FDN0MsZUFBYztTQUNkLE1BQUs7UUFDTjs7OztnQkFDRTs7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRyxZQUFXLEdBQ1I7Ozs7O2tCQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvRDtRQUU5RDs7OztnQkFDSDs7Ozs7ZUFDRjs7Ozs7Y0FDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUE4QyxnQkFDaEMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQXdDO1NBQVc7U0FBUztTQUFlO1FBQWlCOzs7OztlQUNyRzs7Ozs7Z0JBQ0osZUFBZSxPQUFPLGFBQWEsS0FDbEMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7OztpQkFBQyxVQUNoQjs7Ozs7Y0FFTDs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsVUFBVSxLQUFLO09BQzlCLFdBQVcsb0RBQ1QsV0FBVyxRQUNQLDRFQUNBO2lCQUxSO1FBT0M7UUFDTyxnQkFBZ0I7UUFBTztPQUN2Qjs7Ozs7O01BQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsVUFBVSxTQUFTO09BQ2xDLFdBQVcsb0RBQ1QsV0FBVyxZQUNQLDRFQUNBO2lCQUxSO1FBT0M7UUFDUSxhQUFhO1FBQWU7T0FDN0I7Ozs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFVBQVUsV0FBVztPQUNwQyxXQUFXLG9EQUNULFdBQVcsY0FDUCw0RUFDQTtpQkFMUjtRQU9DO1FBQ1E7UUFBZTtPQUNoQjs7Ozs7O0tBQ0w7Ozs7O2NBR0wsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2VBQ2pCLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O2FBQ2Q7Ozs7O1lBQ0w7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osZUFBZSxXQUFXLElBQ3pCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFELEVBQVUsTUFBTSxHQUFLOzs7OztNQUNsQjs7Ozs7TUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsV0FBVyxjQUNSLGlDQUNBLFdBQVcsWUFDWCx1Q0FDQTtNQUNGOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUNWLFdBQVcsY0FDUiw4Q0FDQSxXQUFXLFlBQ1gseUNBQ0E7TUFDSDs7OztjQUNBOzs7OztNQUNKLGdCQUFnQixXQUFXLEtBQzFCLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7aUJBQUMsZ0JBQ1o7Ozs7OztLQUVQOzs7OztlQUVMLGVBQWUsS0FBSyxVQUFVO0tBQzVCLE1BQU0sTUFBK0IsUUFBUSxNQUFNO0tBQ25ELE1BQU0sY0FBYyxRQUFRLEtBQUssU0FBUztLQUMxQyxNQUFNLGFBQWEsS0FBSyxnQkFBZ0I7S0FDeEMsTUFBTSxTQUFTLHFCQUFxQixPQUFPLE9BQU87S0FDbEQsTUFBTSxjQUFjLGVBQWUsTUFBTSxLQUFLO0tBRTlDLE9BQ0Usd0JBQUMsT0FBRDtNQUVFLFdBQVcsb0hBQ1QsY0FDSSwwRkFDQTtnQkFMUixDQVFFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQ0UsV0FBVywwRUFBMEUsWUFBWSxHQUFHLEdBQUcsWUFBWSxPQUFPLEdBQUcsWUFBWTttQkFFekksd0JBQUMsV0FBRDtVQUFXLE1BQU0sTUFBTTtVQUFNLE1BQU07U0FBSzs7Ozs7UUFDckM7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUNiLE1BQU07WUFDSDs7Ozs7WUFDTCxPQUFPLGdCQUFnQixLQUN0Qix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FDRSx3QkFBQyxPQUFEO2VBQU8sTUFBTTtlQUFJLFdBQVU7Y0FBaUM7Ozs7O2NBQzNELE9BQU87Y0FBYzthQUNsQjs7Ozs7O1lBRVAsTUFBTSxnQkFDTCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FDRSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztjQUFDO2NBQUUsTUFBTTthQUN2Qjs7Ozs7O1dBRUw7Ozs7OztVQUVMLHdCQUFDLE1BQUQ7V0FDRSxXQUFXLHdFQUNULGNBQWMsb0RBQW9EO3FCQUduRSxNQUFNO1VBQ0w7Ozs7O1VBR0osd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsTUFBTSxlQUFlLFlBQ3BCLHdCQUFDLFFBQUQ7WUFBTTtZQUNJLHdCQUFDLFVBQUQ7YUFBUSxXQUFVO3VCQUFzQztZQUFtQjs7Ozs7WUFBQztZQUFJLE1BQU07WUFBWTtZQUFFLE1BQU07V0FDOUc7Ozs7c0JBRU4sd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7Ozs7VUFFaEM7Ozs7O1NBQ0E7Ozs7O2dCQUNGOzs7OztpQkFHTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFhLEtBQUs7UUFDakMsT0FBTyxjQUFjLG1EQUFtRDtRQUN4RSxXQUFXLDhIQUNULGNBQ0ksZ0VBQ0E7a0JBR0wsY0FBYyx3QkFBQyxPQUFEO1NBQU8sTUFBTTtTQUFJLGFBQWE7UUFBSTs7OzttQkFBSSx3QkFBQyxRQUFEO1NBQVEsTUFBTTtTQUFJLGFBQWE7UUFBSTs7Ozs7T0FDbEY7Ozs7ZUFDTDs7Ozs7Z0JBR0osTUFBTSxlQUFlLGFBQ3BCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsT0FBRDtTQUNFLFdBQVU7U0FDVixPQUFPLEVBQ0wsT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTyxhQUFhLE1BQU0sY0FBZSxHQUFHLENBQUMsRUFBRSxHQUM5RTtRQUNEOzs7OztPQUNFOzs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsVUFBRDtVQUNFLGVBQWUsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDO1VBQ3hDLFVBQVUsY0FBYztVQUN4QixXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7OztTQUNaOzs7OztTQUVSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiO1NBQ0c7Ozs7O1NBRU4sd0JBQUMsVUFBRDtVQUNFLGVBQWUsZ0JBQWdCLE9BQU8sQ0FBQztVQUN2QyxXQUFVO1VBQ1YsT0FBTTtvQkFFTix3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7OztTQUNYOzs7OztTQUVQLE1BQU0sY0FBYyxLQUNuQix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxpQkFBaUIsT0FBTyxNQUFNLFdBQVc7VUFDeEQsV0FBVTtvQkFDWDtTQUVPOzs7OztRQUVQOzs7OztlQUNGOzs7OztjQUVKO1FBbEhFLE1BQU07Ozs7WUFrSFI7SUFFVCxDQUFDO0dBRUE7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTZDO0lBRXZEOzs7O2NBQ0gsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBQ1g7SUFFTzs7OztZQUNMOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVG9kYXlUYWIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBDaGVja0NpcmNsZTIsIFxuICBDaXJjbGUsIFxuICBQbHVzLCBcbiAgTWludXMsIFxuICBGbGFtZSwgXG4gIENhbGVuZGFyLCBcbiAgQ2xvY2ssIFxuICBTcGFya2xlcyxcbiAgVHJvcGh5LFxuICBGaWx0ZXIsXG4gIENoZWNrLFxuICBSb3RhdGVDY3dcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCBjb25mZXR0aSBmcm9tICdjYW52YXMtY29uZmV0dGknO1xuaW1wb3J0IHsgSGFiaXQsIEhhYml0SGlzdG9yeSwgRGF5SGFiaXRMb2cgfSBmcm9tICcuLi90eXBlcy9oYWJpdCc7XG5pbXBvcnQgeyBIYWJpdEljb24sIGdldENvbG9yU2NoZW1lIH0gZnJvbSAnLi9IYWJpdEljb24nO1xuaW1wb3J0IHsgaXNIYWJpdFNjaGVkdWxlZE9uLCBjYWxjdWxhdGVIYWJpdFN0cmVhaywgZ2V0TW90aXZhdGlvbmFsTWVzc2FnZSB9IGZyb20gJy4uL3NlcnZpY2VzL3N0cmVha1NlcnZpY2UnO1xuaW1wb3J0IHsgZm9ybWF0RGF0ZVRvSGluZGksIGdldFRvZGF5RGF0ZVN0cmluZyB9IGZyb20gJy4uL3NlcnZpY2VzL3N0b3JhZ2VTZXJ2aWNlJztcblxuaW50ZXJmYWNlIFRvZGF5VGFiUHJvcHMge1xuICBjdXJyZW50RGF0ZTogc3RyaW5nO1xuICBoYWJpdHM6IEhhYml0W107XG4gIGhpc3Rvcnk6IEhhYml0SGlzdG9yeTtcbiAgb25Ub2dnbGVIYWJpdDogKGhhYml0OiBIYWJpdCkgPT4gdm9pZDtcbiAgb25VcGRhdGVQcm9ncmVzczogKGhhYml0OiBIYWJpdCwgbmV3VmFsdWU6IG51bWJlcikgPT4gdm9pZDtcbiAgb25PcGVuQWRkTW9kYWw6ICgpID0+IHZvaWQ7XG4gIG9uTmF2aWdhdGVUb01hbmFnZTogKCkgPT4gdm9pZDtcbn1cblxudHlwZSBGaWx0ZXJUeXBlID0gJ2FsbCcgfCAncGVuZGluZycgfCAnY29tcGxldGVkJztcblxuZXhwb3J0IGNvbnN0IFRvZGF5VGFiOiBSZWFjdC5GQzxUb2RheVRhYlByb3BzPiA9ICh7XG4gIGN1cnJlbnREYXRlLFxuICBoYWJpdHMsXG4gIGhpc3RvcnksXG4gIG9uVG9nZ2xlSGFiaXQsXG4gIG9uVXBkYXRlUHJvZ3Jlc3MsXG4gIG9uT3BlbkFkZE1vZGFsLFxuICBvbk5hdmlnYXRlVG9NYW5hZ2UsXG59KSA9PiB7XG4gIGNvbnN0IFtmaWx0ZXIsIHNldEZpbHRlcl0gPSB1c2VTdGF0ZTxGaWx0ZXJUeXBlPignYWxsJyk7XG5cbiAgY29uc3QgdG9kYXlTdHIgPSBnZXRUb2RheURhdGVTdHJpbmcoKTtcbiAgY29uc3QgaXNUb2RheSA9IGN1cnJlbnREYXRlID09PSB0b2RheVN0cjtcblxuICAvLyBTZWxlY3RlZCBkYXRlIG9iamVjdFxuICBjb25zdCBbeSwgbSwgZF0gPSBjdXJyZW50RGF0ZS5zcGxpdCgnLScpLm1hcChOdW1iZXIpO1xuICBjb25zdCBzZWxlY3RlZERhdGVPYmogPSBuZXcgRGF0ZSh5LCBtIC0gMSwgZCk7XG5cbiAgLy8gQWN0aXZlICYgc2NoZWR1bGVkIGhhYml0cyBmb3IgdGhpcyBkYXRlXG4gIGNvbnN0IGFjdGl2ZUhhYml0cyA9IGhhYml0cy5maWx0ZXIoKGgpID0+ICFoLmlzUGF1c2VkKTtcbiAgY29uc3Qgc2NoZWR1bGVkSGFiaXRzID0gYWN0aXZlSGFiaXRzLmZpbHRlcigoaCkgPT4gaXNIYWJpdFNjaGVkdWxlZE9uKGgsIHNlbGVjdGVkRGF0ZU9iaikpO1xuXG4gIGNvbnN0IGRheUxvZ3MgPSBoaXN0b3J5W2N1cnJlbnREYXRlXSB8fCB7fTtcblxuICAvLyBDb3VudCBjb21wbGV0aW9uc1xuICBsZXQgY29tcGxldGVkQ291bnQgPSAwO1xuICBzY2hlZHVsZWRIYWJpdHMuZm9yRWFjaCgoaCkgPT4ge1xuICAgIGlmIChkYXlMb2dzW2guaWRdPy5jb21wbGV0ZWQpIHtcbiAgICAgIGNvbXBsZXRlZENvdW50Kys7XG4gICAgfVxuICB9KTtcblxuICBjb25zdCB0b3RhbENvdW50ID0gc2NoZWR1bGVkSGFiaXRzLmxlbmd0aDtcbiAgY29uc3QgcGVyY2VudGFnZSA9IHRvdGFsQ291bnQgPiAwID8gTWF0aC5yb3VuZCgoY29tcGxldGVkQ291bnQgLyB0b3RhbENvdW50KSAqIDEwMCkgOiAwO1xuICBjb25zdCBtb3RpdmF0aW9uYWwgPSBnZXRNb3RpdmF0aW9uYWxNZXNzYWdlKHBlcmNlbnRhZ2UsIGNvbXBsZXRlZENvdW50LCB0b3RhbENvdW50KTtcblxuICAvLyBGaWx0ZXJlZCBoYWJpdHNcbiAgY29uc3QgZmlsdGVyZWRIYWJpdHMgPSBzY2hlZHVsZWRIYWJpdHMuZmlsdGVyKChoKSA9PiB7XG4gICAgY29uc3QgaXNEb25lID0gQm9vbGVhbihkYXlMb2dzW2guaWRdPy5jb21wbGV0ZWQpO1xuICAgIGlmIChmaWx0ZXIgPT09ICdwZW5kaW5nJykgcmV0dXJuICFpc0RvbmU7XG4gICAgaWYgKGZpbHRlciA9PT0gJ2NvbXBsZXRlZCcpIHJldHVybiBpc0RvbmU7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG4gIC8vIEhhbmRsZSBjZWxlYnJhdGlvblxuICBjb25zdCBoYW5kbGVUb2dnbGUgPSAoaGFiaXQ6IEhhYml0KSA9PiB7XG4gICAgY29uc3Qgd2FzQ29tcGxldGVkID0gQm9vbGVhbihkYXlMb2dzW2hhYml0LmlkXT8uY29tcGxldGVkKTtcbiAgICBvblRvZ2dsZUhhYml0KGhhYml0KTtcblxuICAgIC8vIElmIHRoaXMgdG9nZ2xlIGNvbXBsZXRlcyB0aGUgZmluYWwgcmVtYWluaW5nIGhhYml0XG4gICAgaWYgKCF3YXNDb21wbGV0ZWQgJiYgY29tcGxldGVkQ291bnQgKyAxID09PSB0b3RhbENvdW50KSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25mZXR0aSh7XG4gICAgICAgICAgcGFydGljbGVDb3VudDogODAsXG4gICAgICAgICAgc3ByZWFkOiA3MCxcbiAgICAgICAgICBvcmlnaW46IHsgeTogMC42IH0sXG4gICAgICAgICAgY29sb3JzOiBbJyMwNTk2NjknLCAnIzEwYjk4MScsICcjMzRkMzk5JywgJyNmNTllMGInLCAnIzNiODJmNiddLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBTYWZlIGZhbGxiYWNrXG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUluY3JlbWVudCA9IChoYWJpdDogSGFiaXQsIGRlbHRhOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBjdXJyZW50VmFsID0gZGF5TG9nc1toYWJpdC5pZF0/LmN1cnJlbnRWYWx1ZSB8fCAwO1xuICAgIGNvbnN0IG5leHRWYWwgPSBNYXRoLm1heCgwLCBjdXJyZW50VmFsICsgZGVsdGEpO1xuICAgIG9uVXBkYXRlUHJvZ3Jlc3MoaGFiaXQsIG5leHRWYWwpO1xuXG4gICAgaWYgKG5leHRWYWwgPj0gaGFiaXQudGFyZ2V0VmFsdWUgJiYgY3VycmVudFZhbCA8IGhhYml0LnRhcmdldFZhbHVlKSB7XG4gICAgICAvLyBSZWFjaGVkIHRhcmdldFxuICAgICAgaWYgKGNvbXBsZXRlZENvdW50ICsgMSA9PT0gdG90YWxDb3VudCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbmZldHRpKHtcbiAgICAgICAgICAgIHBhcnRpY2xlQ291bnQ6IDYwLFxuICAgICAgICAgICAgc3ByZWFkOiA2MCxcbiAgICAgICAgICAgIG9yaWdpbjogeyB5OiAwLjYgfSxcbiAgICAgICAgICAgIGNvbG9yczogWycjMDU5NjY5JywgJyMxMGI5ODEnLCAnI2Y1OWUwYiddLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIHt9XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwYi0yNCBwdC00IHB4LTQgbWF4LXctbWQgbXgtYXV0byBzcGFjZS15LTRcIj5cbiAgICAgIHsvKiBNb3RpdmF0aW9uYWwgJiBUb2RheSBTdW1tYXJ5IENhcmQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLWJyIGZyb20tZW1lcmFsZC04MDAgdG8tZW1lcmFsZC05NTAgdGV4dC13aGl0ZSByb3VuZGVkLTN4bCBwLTUgc2hhZG93LWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC03MDAvNTAgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgIHsvKiBTdWJ0bGUgZGVjb3JhdGl2ZSBnbG93ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMTIgLXJpZ2h0LTEyIHctMzYgaC0zNiBiZy1lbWVyYWxkLTUwMC8yMCByb3VuZGVkLWZ1bGwgYmx1ci0yeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC03MDAvNjAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTYwMC80MCB0ZXh0LVsxMXB4XSBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC0yMDBcIj5cbiAgICAgICAgICAgICAgPENhbGVuZGFyIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAgICB7aXNUb2RheSA/ICfgpIbgpJwg4KSV4KS+IOCkpuCkv+CkqCcgOiBmb3JtYXREYXRlVG9IaW5kaShjdXJyZW50RGF0ZSl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCBsZWFkaW5nLXNudWcgcHQtMSB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgIHttb3RpdmF0aW9uYWwudGl0bGV9XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWVtZXJhbGQtMjAwLzkwIGxlYWRpbmctcmVsYXhlZCBtYXgtdy14c1wiPlxuICAgICAgICAgICAgICB7bW90aXZhdGlvbmFsLnN1YnRpdGxlfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENpcmN1bGFyIFByb2dyZXNzIFJpbmcgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBzaHJpbmstMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTIwIGgtMjAgdHJhbnNmb3JtIC1yb3RhdGUtOTBcIj5cbiAgICAgICAgICAgICAgPGNpcmNsZVxuICAgICAgICAgICAgICAgIGN4PVwiNDBcIlxuICAgICAgICAgICAgICAgIGN5PVwiNDBcIlxuICAgICAgICAgICAgICAgIHI9XCIzM1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic3Ryb2tlLWVtZXJhbGQtOTAwLzgwXCJcbiAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjdcIlxuICAgICAgICAgICAgICAgIGZpbGw9XCJ0cmFuc3BhcmVudFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxjaXJjbGVcbiAgICAgICAgICAgICAgICBjeD1cIjQwXCJcbiAgICAgICAgICAgICAgICBjeT1cIjQwXCJcbiAgICAgICAgICAgICAgICByPVwiMzNcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInN0cm9rZS1lbWVyYWxkLTQwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi01MDAgZWFzZS1vdXRcIlxuICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiN1wiXG4gICAgICAgICAgICAgICAgc3Ryb2tlRGFzaGFycmF5PXsyMDd9XG4gICAgICAgICAgICAgICAgc3Ryb2tlRGFzaG9mZnNldD17MjA3IC0gKDIwNyAqIHBlcmNlbnRhZ2UpIC8gMTAwfVxuICAgICAgICAgICAgICAgIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiXG4gICAgICAgICAgICAgICAgZmlsbD1cInRyYW5zcGFyZW50XCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ibGFjayBsZWFkaW5nLW5vbmUgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIHtwZXJjZW50YWdlfSVcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWVtZXJhbGQtMzAwIGZvbnQtc2VtaWJvbGQgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAg4KSq4KWC4KSw4KWN4KSjXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRGFpbHkgQ29tcGxldGlvbiBTdW1tYXJ5IFBpbGwgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1lbWVyYWxkLTcwMC82MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTEwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAg4KSV4KWB4KSyIOCkuOCljeCkpeCkv+CkpOCkvzogPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj57dG90YWxDb3VudH0g4KSu4KWH4KSCIOCkuOClhyB7Y29tcGxldGVkQ291bnR9IOCkhuCkpuCkpOClh+CkgiDgpKrgpYLgpLDgpYA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge3BlcmNlbnRhZ2UgPT09IDEwMCAmJiB0b3RhbENvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBiZy1lbWVyYWxkLTUwMCB0ZXh0LWVtZXJhbGQtOTUwIGZvbnQtYmxhY2sgdGV4dC1bMTFweF0gYW5pbWF0ZS1ib3VuY2VcIj5cbiAgICAgICAgICAgICAgPFRyb3BoeSBzaXplPXsxMn0gLz4g4KS24KS+4KSo4KSm4KS+4KSwIVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBRdWljayBBZGQgSGFiaXQgJiBGaWx0ZXIgQ29udHJvbHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBwdC0xXCI+XG4gICAgICAgIHsvKiBGaWx0ZXIgUGlsbHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1zdG9uZS0yMDAvODAgZGFyazpiZy1zdG9uZS04MDAvODAgcC0xIHJvdW5kZWQtMnhsIHRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcignYWxsJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgZmlsdGVyID09PSAnYWxsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1zdG9uZS05MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDgpLjgpK3gpYAgKHtzY2hlZHVsZWRIYWJpdHMubGVuZ3RofSlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXIoJ3BlbmRpbmcnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBmaWx0ZXIgPT09ICdwZW5kaW5nJ1xuICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1zdG9uZS05MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDgpKzgpL7gpJXgpYAgKHt0b3RhbENvdW50IC0gY29tcGxldGVkQ291bnR9KVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlcignY29tcGxldGVkJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgZmlsdGVyID09PSAnY29tcGxldGVkJ1xuICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1zdG9uZS05MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDgpKrgpYLgpLDgpYcgKHtjb21wbGV0ZWRDb3VudH0pXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBY3Rpb24gQnV0dG9uICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25PcGVuQWRkTW9kYWx9XG4gICAgICAgICAgY2xhc3NOYW1lPVwicHktMS41IHB4LTMgcm91bmRlZC0yeGwgYmctZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC04MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBzaGFkb3ctc20gdHJhbnNpdGlvbiBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXIgc2hyaW5rLTBcIlxuICAgICAgICA+XG4gICAgICAgICAgPFBsdXMgc2l6ZT17MTV9IC8+XG4gICAgICAgICAgPHNwYW4+KyDgpKjgpIgg4KSG4KSm4KSkPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogSGFiaXQgTGlzdCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgIHtmaWx0ZXJlZEhhYml0cy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItc3RvbmUtMzAwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCByb3VuZGVkLTN4bCBwLTggdGV4dC1jZW50ZXIgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiBteC1hdXRvIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBzaXplPXsyNH0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXN0b25lLTgwMCBkYXJrOnRleHQtc3RvbmUtMjAwIHRleHQtYmFzZVwiPlxuICAgICAgICAgICAgICAgIHtmaWx0ZXIgPT09ICdjb21wbGV0ZWQnIFxuICAgICAgICAgICAgICAgICAgPyAn4KSF4KSt4KWAIOCkleCli+CkiCDgpIbgpKbgpKQg4KSq4KWC4KSw4KWAIOCkqOCkueClgOCkgiDgpLngpYHgpIgg4KS54KWIJyBcbiAgICAgICAgICAgICAgICAgIDogZmlsdGVyID09PSAncGVuZGluZydcbiAgICAgICAgICAgICAgICAgID8gJ+CkuOCkreClgCDgpIbgpKbgpKTgpYfgpIIg4KSq4KWC4KSw4KWAIOCkueCliyDgpJrgpYHgpJXgpYAg4KS54KWI4KSCISDgpLbgpL7gpKzgpL7gpLYhJ1xuICAgICAgICAgICAgICAgICAgOiAn4KSG4KScIOCkleClhyDgpLLgpL/gpI8g4KSV4KWL4KSIIOCkhuCkpuCkpCDgpKjgpL/gpLDgpY3gpKfgpL7gpLDgpL/gpKQg4KSo4KS54KWA4KSCIOCkueCliCd9XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMCBtdC0xIG1heC13LXhzIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICB7ZmlsdGVyID09PSAnY29tcGxldGVkJ1xuICAgICAgICAgICAgICAgICAgPyAn4KSK4KSq4KSwIOCkpuClgCDgpJfgpIgg4KSG4KSm4KSk4KWL4KSCIOCkleCliyDgpKrgpYLgpLDgpL4g4KSV4KSw4KSV4KWHIOCkr+CkueCkvuCkgSDgpJzgpYvgpKHgpLzgpYfgpILgpaQnXG4gICAgICAgICAgICAgICAgICA6IGZpbHRlciA9PT0gJ3BlbmRpbmcnXG4gICAgICAgICAgICAgICAgICA/ICfgpIbgpKrgpKjgpYcg4KSG4KScIOCkleCkviDgpLjgpL7gpLDgpL4g4KSV4KS+4KSuIOCkquClguCksOCkviDgpJXgpLAg4KSy4KS/4KSv4KS+IOCkueCliOClpCdcbiAgICAgICAgICAgICAgICAgIDogJ+CkqOCkiCDgpIbgpKbgpKQg4KSc4KWL4KSh4KS84KWH4KSCIOCkr+CkviDgpIXgpKrgpKjgpYAg4KSu4KWM4KSc4KWC4KSm4KS+IOCkhuCkpuCkpOCli+CkgiDgpJXgpYAg4KSm4KS/4KSoLeCkuOClguCkmuClgCDgpJzgpL7gpILgpJrgpYfgpILgpaQnfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIHtzY2hlZHVsZWRIYWJpdHMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlbkFkZE1vZGFsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQteGwgYmctZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC04MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uIHNoYWRvdy14cyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UGx1cyBzaXplPXsxNH0gLz4g4KSo4KSIIOCkhuCkpuCkpCDgpJzgpYvgpKHgpLzgpYfgpIJcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIGZpbHRlcmVkSGFiaXRzLm1hcCgoaGFiaXQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGxvZzogRGF5SGFiaXRMb2cgfCB1bmRlZmluZWQgPSBkYXlMb2dzW2hhYml0LmlkXTtcbiAgICAgICAgICAgIGNvbnN0IGlzQ29tcGxldGVkID0gQm9vbGVhbihsb2c/LmNvbXBsZXRlZCk7XG4gICAgICAgICAgICBjb25zdCBjdXJyZW50VmFsID0gbG9nPy5jdXJyZW50VmFsdWUgfHwgMDtcbiAgICAgICAgICAgIGNvbnN0IHN0cmVhayA9IGNhbGN1bGF0ZUhhYml0U3RyZWFrKGhhYml0LCBoaXN0b3J5KTtcbiAgICAgICAgICAgIGNvbnN0IGNvbG9yU2NoZW1lID0gZ2V0Q29sb3JTY2hlbWUoaGFiaXQuY29sb3IpO1xuXG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtoYWJpdC5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHJvdW5kZWQtM3hsIHAtNCBzaGFkb3cteHMgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuICR7XG4gICAgICAgICAgICAgICAgICBpc0NvbXBsZXRlZFxuICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItZW1lcmFsZC0zMDAgZGFyazpib3JkZXItZW1lcmFsZC05MDAvNjAgYmctZW1lcmFsZC01MC8yMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzIwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc3RvbmUtMjAwLzgwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBob3Zlcjpib3JkZXItc3RvbmUtMzAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgey8qIExlZnQ6IEljb24gYW5kIERldGFpbHMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgZmxleC0xIG1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMTEgaC0xMSByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCBib3JkZXIgJHtjb2xvclNjaGVtZS5iZ30gJHtjb2xvclNjaGVtZS5ib3JkZXJ9ICR7Y29sb3JTY2hlbWUudGV4dH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEhhYml0SWNvbiBuYW1lPXtoYWJpdC5pY29ufSBzaXplPXsyMn0gLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwIHRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2hhYml0LmNhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAge3N0cmVhay5jdXJyZW50U3RyZWFrID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgZGFyazpiZy1hbWJlci05NTAvNjAgdGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZsYW1lIHNpemU9ezExfSBjbGFzc05hbWU9XCJmaWxsLWFtYmVyLTUwMCB0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3N0cmVhay5jdXJyZW50U3RyZWFrfSDgpKbgpL/gpKhcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHtoYWJpdC5yZW1pbmRlclRpbWUgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1lZGl1bSB0ZXh0LXN0b25lLTQwMCBkYXJrOnRleHQtc3RvbmUtNTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgc2l6ZT17MTF9IC8+IHtoYWJpdC5yZW1pbmRlclRpbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8aDRcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtYmFzZSBmb250LWJvbGQgbXQtMSB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwIHRydW5jYXRlICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGlzQ29tcGxldGVkID8gJ2xpbmUtdGhyb3VnaCB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNTAwJyA6ICcnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aGFiaXQubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2g0PlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIFRhcmdldCBzdGF0dXMgZGVzY3JpcHRpb24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2hhYml0LnRhcmdldFR5cGUgPT09ICdudW1lcmljJyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAg4KSy4KSV4KWN4KS34KWN4KSvOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDBcIj57Y3VycmVudFZhbH08L3N0cm9uZz4gLyB7aGFiaXQudGFyZ2V0VmFsdWV9IHtoYWJpdC51bml0fVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7gpKbgpYjgpKjgpL/gpJUg4KSy4KSV4KWN4KS34KWN4KSvOiDgpacg4KSs4KS+4KSwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBSaWdodDogQ29tcGxldGlvbiBUb2dnbGUgLyBDaGVja2JveCAqL31cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlVG9nZ2xlKGhhYml0KX1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2lzQ29tcGxldGVkID8gJ+CkquClguCksOCkviDgpLngpYHgpIYgKOCkteCkvuCkquCkuCDgpKrgpYLgpLDgpY3gpLXgpLXgpKQg4KSV4KSw4KSo4KWHIOCkleClhyDgpLLgpL/gpI8g4KSV4KWN4KSy4KS/4KSVIOCkleCksOClh+CkgiknIDogJ+CkquClguCksOCkviDgpJrgpL/gpLngpY3gpKjgpL/gpKQg4KSV4KSw4KWH4KSCJ31cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy0xMSBoLTExIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNocmluay0wIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTAgJHtcbiAgICAgICAgICAgICAgICAgICAgICBpc0NvbXBsZXRlZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBzaGFkb3ctc20gcmluZy0yIHJpbmctZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zdG9uZS0xMDAgZGFyazpiZy1zdG9uZS04MDAgdGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTYwMCBkYXJrOmhvdmVyOnRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2lzQ29tcGxldGVkID8gPENoZWNrIHNpemU9ezIyfSBzdHJva2VXaWR0aD17M30gLz4gOiA8Q2lyY2xlIHNpemU9ezIyfSBzdHJva2VXaWR0aD17Mn0gLz59XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBOdW1lcmljIEhhYml0IEluY3JlbWVudGFsIENvbnRyb2xzIEJhciAqL31cbiAgICAgICAgICAgICAgICB7aGFiaXQudGFyZ2V0VHlwZSA9PT0gJ251bWVyaWMnICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwdC0zIGJvcmRlci10IGJvcmRlci1zdG9uZS0xMDAgZGFyazpib3JkZXItc3RvbmUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMS8yIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCBoLTIgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNjAwIGgtZnVsbCByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiBgJHtNYXRoLm1pbigxMDAsIE1hdGgucm91bmQoKGN1cnJlbnRWYWwgLyBoYWJpdC50YXJnZXRWYWx1ZSkgKiAxMDApKX0lYCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlSW5jcmVtZW50KGhhYml0LCAtMSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y3VycmVudFZhbCA8PSAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy03IGgtNyByb3VuZGVkLWxnIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGhvdmVyOmJnLXN0b25lLTIwMCBkYXJrOmhvdmVyOmJnLXN0b25lLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uIGRpc2FibGVkOm9wYWNpdHktMzAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiMSDgpJjgpJ/gpL7gpI/gpIJcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxNaW51cyBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTgwMCBkYXJrOnRleHQtc3RvbmUtMjAwIHB4LTEgbWluLXctWzMycHhdIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudFZhbH1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVJbmNyZW1lbnQoaGFiaXQsIDEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy03IGgtNyByb3VuZGVkLWxnIGJnLWVtZXJhbGQtMTAwIGRhcms6YmctZW1lcmFsZC05NTAvNjAgdGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgaG92ZXI6YmctZW1lcmFsZC0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbiBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCIxIOCkrOCkouCkvOCkvuCkj+CkglwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBsdXMgc2l6ZT17MTR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7aGFiaXQudGFyZ2V0VmFsdWUgPiAyICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25VcGRhdGVQcm9ncmVzcyhoYWJpdCwgaGFiaXQudGFyZ2V0VmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTEgcm91bmRlZC1sZyBiZy1zdG9uZS0xMDAgZGFyazpiZy1zdG9uZS04MDAgdGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtMzAwIGhvdmVyOmJnLXN0b25lLTIwMCBtbC0xXCJcbiAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAg4KSq4KWC4KSw4KWN4KSjXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KVxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBGb290ZXIgRW5jb3VyYWdlbWVudCBCYW5uZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcC00IHJvdW5kZWQtM3hsIGJnLXN0b25lLTUwIGRhcms6Ymctc3RvbmUtOTAwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwLzgwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICBcIuCkueCksCDgpKbgpL/gpKgg4KSV4KWAIOCkm+Cli+Ckn+ClgCDgpJXgpYvgpLbgpL/gpLbgpYfgpIIg4KS54KWAIOCkreCkteCkv+Ckt+CljeCkryDgpJXgpYAg4KSs4KSh4KS84KWAIOCkieCkquCksuCkrOCljeCkp+Ckv+Ckr+CkvuCkgiDgpKzgpKjgpKTgpYAg4KS54KWI4KSC4KWkXCJcbiAgICAgICAgPC9wPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25OYXZpZ2F0ZVRvTWFuYWdlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgID5cbiAgICAgICAgICDgpIbgpKbgpKTgpYfgpIIg4KS14KWN4KSv4KS14KS44KWN4KSl4KS/4KSkIOCktSDgpLjgpILgpKrgpL7gpKbgpL/gpKQg4KSV4KSw4KWH4KSCIOKGklxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==