const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Plus, Edit3, Trash2, PauseCircle, PlayCircle, Calendar, Clock, AlertCircle, Archive, Layers } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { HabitIcon, getColorScheme } from "/src/components/HabitIcon.tsx";
import { getHindiDayOfWeek } from "/src/services/storageService.ts";
var _jsxFileName = "/app/applet/src/components/HabitsTab.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
const CATEGORIES = [
	"सभी",
	"स्वास्थ्य",
	"पढ़ाई",
	"इबादत",
	"व्यक्तिगत विकास",
	"अन्य"
];
export const HabitsTab = ({ habits, onOpenAddModal, onOpenEditModal, onRequestDeleteHabit, onTogglePauseHabit }) => {
	const [selectedCategory, setSelectedCategory] = useState("सभी");
	const [viewArchived, setViewArchived] = useState(false);
	const activeHabits = habits.filter((h) => !h.isPaused);
	const pausedHabits = habits.filter((h) => h.isPaused);
	const displayedList = (viewArchived ? pausedHabits : activeHabits).filter((h) => {
		if (selectedCategory === "सभी") return true;
		return h.category === selectedCategory;
	});
	const formatScheduledDays = (habit) => {
		if (habit.frequencyType === "daily" || !habit.scheduledDays || habit.scheduledDays.length === 7) {
			return "प्रतिदिन (रोज़ाना)";
		}
		return habit.scheduledDays.map((d) => getHindiDayOfWeek(d)).join(", ");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "pb-24 pt-4 px-4 max-w-md mx-auto space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl font-black text-stone-900 dark:text-stone-100",
					children: "मेरी आदतें प्रबंधित करें"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-stone-500 dark:text-stone-400",
					children: [
						"कुल आदतें: ",
						habits.length,
						" (सक्रिय: ",
						activeHabits.length,
						", रोकी गई: ",
						pausedHabits.length,
						")"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onOpenAddModal,
					className: "py-2 px-3.5 rounded-2xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition active:scale-95 cursor-pointer",
					children: [/* @__PURE__ */ _jsxDEV(Plus, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "नई आदत" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 68,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex bg-stone-200/80 dark:bg-stone-800/80 p-1 rounded-2xl text-xs font-semibold",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setViewArchived(false),
					className: `flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${!viewArchived ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" : "text-stone-600 dark:text-stone-400"}`,
					children: [/* @__PURE__ */ _jsxDEV(Layers, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 87,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						"सक्रिय आदतें (",
						activeHabits.length,
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setViewArchived(true),
					className: `flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${viewArchived ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs" : "text-stone-600 dark:text-stone-400"}`,
					children: [/* @__PURE__ */ _jsxDEV(Archive, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
						"रोकी गई / पुरालेख (",
						pausedHabits.length,
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none",
				children: CATEGORIES.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setSelectedCategory(cat),
					className: `px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition cursor-pointer ${selectedCategory === cat ? "bg-emerald-700 text-white font-bold shadow-xs" : "bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hover:bg-stone-100"}`,
					children: cat
				}, cat, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3",
				children: displayedList.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white dark:bg-stone-900 border border-dashed border-stone-300 dark:border-stone-800 rounded-3xl p-8 text-center space-y-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-12 h-12 mx-auto rounded-full bg-stone-100 dark:bg-stone-800 text-stone-400 flex items-center justify-center",
						children: /* @__PURE__ */ _jsxDEV(Layers, { size: 22 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-stone-800 dark:text-stone-200 text-sm",
						children: viewArchived ? "कोई रोकी गई आदत नहीं है" : "इस श्रेणी में कोई सक्रिय आदत नहीं मिली"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-stone-500 dark:text-stone-400 mt-1",
						children: viewArchived ? "जब आप किसी आदत को अस्थायी रूप से रोकते हैं, तो वह यहाँ दिखाई देगी।" : "आप ऊपर दिए गए \"+ नई आदत\" बटन से नई आदत जोड़ सकते हैं।"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 11
				}, this) : displayedList.map((habit) => {
					const colorScheme = getColorScheme(habit.color);
					return /* @__PURE__ */ _jsxDEV("div", {
						className: `bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 rounded-3xl p-4 shadow-xs transition hover:border-stone-300 ${habit.isPaused ? "opacity-75 bg-stone-50/50 dark:bg-stone-900/40" : ""}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: `w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${colorScheme.bg} ${colorScheme.border} ${colorScheme.text}`,
								children: /* @__PURE__ */ _jsxDEV(HabitIcon, {
									name: habit.icon,
									size: 22
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 21
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 flex-wrap",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300",
											children: habit.category
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 162,
											columnNumber: 23
										}, this), habit.isPaused && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-400",
											children: "अस्थायी रोकी गई"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 166,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-base font-bold text-stone-900 dark:text-stone-100 mt-1 truncate",
										children: habit.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-0.5 mt-1 text-xs text-stone-500 dark:text-stone-400",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "लक्ष्य:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 179,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("strong", {
													className: "text-stone-700 dark:text-stone-300 font-semibold",
													children: habit.targetType === "numeric" ? `${habit.targetValue} ${habit.unit}` : "दैनिक १ बार"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 180,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 178,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5 text-[11px]",
												children: [/* @__PURE__ */ _jsxDEV(Calendar, {
													size: 12,
													className: "shrink-0 text-stone-400"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 187,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "truncate",
													children: formatScheduledDays(habit)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 188,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 186,
												columnNumber: 23
											}, this),
											habit.reminderTime && /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1.5 text-[11px] text-emerald-700 dark:text-emerald-400 font-medium",
												children: [/* @__PURE__ */ _jsxDEV(Clock, {
													size: 12,
													className: "shrink-0"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 192,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["रिमाइंडर: ", habit.reminderTime] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 191,
												columnNumber: 25
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 177,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3.5 pt-3 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => onTogglePauseHabit(habit),
								className: "flex items-center gap-1 text-stone-600 dark:text-stone-400 hover:text-emerald-700 dark:hover:text-emerald-400 font-semibold transition cursor-pointer",
								title: habit.isPaused ? "आदत पुनः शुरू करें" : "आदत रोकें",
								children: habit.isPaused ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(PlayCircle, {
									size: 15,
									className: "text-emerald-600"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 210,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "पुनः शुरू करें" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 211,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 209,
									columnNumber: 23
								}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(PauseCircle, { size: 15 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "रोकें (Pause)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onOpenEditModal(habit),
									className: "px-2.5 py-1 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 font-semibold flex items-center gap-1 transition cursor-pointer",
									children: [/* @__PURE__ */ _jsxDEV(Edit3, { size: 13 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "संपादित करें" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 228,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onRequestDeleteHabit(habit),
									className: "p-1.5 rounded-xl text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/40 transition cursor-pointer",
									title: "आदत हटाएं",
									children: /* @__PURE__ */ _jsxDEV(Trash2, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 17
						}, this)]
					}, habit.id, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 121,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-800/60 text-xs text-emerald-800 dark:text-emerald-300 flex items-start gap-2",
				children: [/* @__PURE__ */ _jsxDEV(AlertCircle, {
					size: 16,
					className: "shrink-0 mt-0.5"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 249,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "आदत को \"रोकने\" (Pause) से आपका पुराना इतिहास सुरक्षित रहता है और स्ट्रीक रिकॉर्ड नष्ट नहीं होते।" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 250,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 248,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 56,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLE1BQ0EsT0FDQSxRQUNBLGFBQ0EsWUFDQSxVQUNBLE9BR0EsYUFDQSxTQUNBLGNBQ0s7QUFFUCxTQUFTLFdBQVcsc0JBQXNCO0FBQzFDLFNBQVMseUJBQXlCOzs7QUFVbEMsTUFBTSxhQUF3QztDQUFDO0NBQU87Q0FBYTtDQUFTO0NBQVM7Q0FBbUI7QUFBTTtBQUU5RyxPQUFPLE1BQU0sYUFBdUMsRUFDbEQsUUFDQSxnQkFDQSxpQkFDQSxzQkFDQSx5QkFDSTtDQUNKLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQWdDLEtBQUs7Q0FDckYsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQVMsS0FBSztDQUV0RCxNQUFNLGVBQWUsT0FBTyxRQUFRLE1BQU0sQ0FBQyxFQUFFLFFBQVE7Q0FDckQsTUFBTSxlQUFlLE9BQU8sUUFBUSxNQUFNLEVBQUUsUUFBUTtDQUVwRCxNQUFNLGlCQUFpQixlQUFlLGVBQWUsYUFBWSxDQUFFLFFBQVEsTUFBTTtFQUMvRSxJQUFJLHFCQUFxQixPQUFPLE9BQU87RUFDdkMsT0FBTyxFQUFFLGFBQWE7Q0FDeEIsQ0FBQztDQUVELE1BQU0sdUJBQXVCLFVBQXlCO0VBQ3BELElBQUksTUFBTSxrQkFBa0IsV0FBVyxDQUFDLE1BQU0saUJBQWlCLE1BQU0sY0FBYyxXQUFXLEdBQUc7R0FDL0YsT0FBTztFQUNUO0VBQ0EsT0FBTyxNQUFNLGNBQWMsS0FBSyxNQUFNLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSTtDQUN2RTtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBd0Q7SUFFbEU7Ozs7Y0FDSix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFiO01BQTBEO01BQzVDLE9BQU87TUFBTztNQUFXLGFBQWE7TUFBTztNQUFZLGFBQWE7TUFBTztLQUN4Rjs7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUZaLENBSUUsd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7OztlQUNqQix3QkFBQyxRQUFELFlBQU0sU0FBWTs7OzthQUNaOzs7OztZQUNMOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLGVBQWUsZ0JBQWdCLEtBQUs7S0FDcEMsV0FBVyw2RkFDVCxDQUFDLGVBQ0csNEVBQ0E7ZUFMUixDQVFFLHdCQUFDLFFBQUQsRUFBUSxNQUFNLEdBQUs7Ozs7ZUFDbkIsd0JBQUMsUUFBRDtNQUFNO01BQWUsYUFBYTtNQUFPO0tBQU87Ozs7YUFDMUM7Ozs7O2NBQ1Isd0JBQUMsVUFBRDtLQUNFLGVBQWUsZ0JBQWdCLElBQUk7S0FDbkMsV0FBVyw2RkFDVCxlQUNJLDRFQUNBO2VBTFIsQ0FRRSx3QkFBQyxTQUFELEVBQVMsTUFBTSxHQUFLOzs7O2VBQ3BCLHdCQUFDLFFBQUQ7TUFBTTtNQUFvQixhQUFhO01BQU87S0FBTzs7OzthQUMvQzs7Ozs7WUFDTDs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDWixXQUFXLEtBQUssUUFDZix3QkFBQyxVQUFEO0tBRUUsZUFBZSxvQkFBb0IsR0FBRztLQUN0QyxXQUFXLGlGQUNULHFCQUFxQixNQUNqQixrREFDQTtlQUdMO0lBQ0ssR0FURDs7OztXQVNDLENBQ1Q7R0FDRTs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLGNBQWMsV0FBVyxJQUN4Qix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7S0FDaEI7Ozs7ZUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsZUFDRyw0QkFDQTtLQUNGOzs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsZUFDRyx1RUFDQTtLQUNIOzs7O2FBQ0E7Ozs7YUFDRjs7Ozs7ZUFFTCxjQUFjLEtBQUssVUFBVTtLQUMzQixNQUFNLGNBQWMsZUFBZSxNQUFNLEtBQUs7S0FFOUMsT0FDRSx3QkFBQyxPQUFEO01BRUUsV0FBVywySUFDVCxNQUFNLFdBQVcsbURBQW1EO2dCQUh4RSxDQU1FLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBRUUsd0JBQUMsT0FBRDtRQUNFLFdBQVcsMEVBQTBFLFlBQVksR0FBRyxHQUFHLFlBQVksT0FBTyxHQUFHLFlBQVk7a0JBRXpJLHdCQUFDLFdBQUQ7U0FBVyxNQUFNLE1BQU07U0FBTSxNQUFNO1FBQUs7Ozs7O09BQ3JDOzs7O2lCQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFDYixNQUFNO1VBQ0g7Ozs7b0JBQ0wsTUFBTSxZQUNMLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFzSDtVQUVoSTs7OztrQkFFTDs7Ozs7O1NBRUwsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQ1gsTUFBTTtTQUNMOzs7OztTQUdKLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sVUFBYTs7OztzQkFDbkIsd0JBQUMsVUFBRDthQUFRLFdBQVU7dUJBQ2YsTUFBTSxlQUFlLFlBQ2xCLEdBQUcsTUFBTSxZQUFZLEdBQUcsTUFBTSxTQUM5QjtZQUNFOzs7O29CQUNMOzs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFVBQUQ7YUFBVSxNQUFNO2FBQUksV0FBVTtZQUEyQjs7OztzQkFDekQsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQVksb0JBQW9CLEtBQUs7WUFBUTs7OztvQkFDMUQ7Ozs7OztXQUNKLE1BQU0sZ0JBQ0wsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQU8sTUFBTTthQUFJLFdBQVU7WUFBWTs7OztzQkFDdkMsd0JBQUMsUUFBRCxhQUFNLGNBQVcsTUFBTSxZQUFtQjs7OztvQkFDdkM7Ozs7OztVQUVKOzs7Ozs7UUFDRjs7Ozs7ZUFDRjs7Ozs7Z0JBR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FFRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxtQkFBbUIsS0FBSztRQUN2QyxXQUFVO1FBQ1YsT0FBTyxNQUFNLFdBQVcsdUJBQXVCO2tCQUU5QyxNQUFNLFdBQ0wsZ0RBQ0Usd0JBQUMsWUFBRDtTQUFZLE1BQU07U0FBSSxXQUFVO1FBQW9COzs7O2tCQUNwRCx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2dCQUMxQjs7OzttQkFFRixnREFDRSx3QkFBQyxhQUFELEVBQWEsTUFBTSxHQUFLOzs7O2tCQUN4Qix3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2dCQUN6Qjs7Ozs7T0FFRTs7OztpQkFFUix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUVFLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGdCQUFnQixLQUFLO1NBQ3BDLFdBQVU7bUJBRlosQ0FJRSx3QkFBQyxPQUFELEVBQU8sTUFBTSxHQUFLOzs7O21CQUNsQix3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7aUJBQ2xCOzs7OztrQkFHUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxxQkFBcUIsS0FBSztTQUN6QyxXQUFVO1NBQ1YsT0FBTTttQkFFTix3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztRQUNiOzs7O2dCQUNMOzs7OztlQUNGOzs7OztjQUNGO1FBL0ZFLE1BQU07Ozs7WUErRlI7SUFFVCxDQUFDO0dBRUE7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLGFBQUQ7S0FBYSxNQUFNO0tBQUksV0FBVTtJQUFtQjs7OztjQUNwRCx3QkFBQyxLQUFELFlBQUcscUdBRUE7Ozs7WUFDQTs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhhYml0c1RhYi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIFBsdXMsIFxuICBFZGl0MywgXG4gIFRyYXNoMiwgXG4gIFBhdXNlQ2lyY2xlLCBcbiAgUGxheUNpcmNsZSwgXG4gIENhbGVuZGFyLCBcbiAgQ2xvY2ssIFxuICBUYWcsIFxuICBDaGVja0NpcmNsZTIsXG4gIEFsZXJ0Q2lyY2xlLFxuICBBcmNoaXZlLFxuICBMYXllcnNcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IEhhYml0LCBIYWJpdENhdGVnb3J5IH0gZnJvbSAnLi4vdHlwZXMvaGFiaXQnO1xuaW1wb3J0IHsgSGFiaXRJY29uLCBnZXRDb2xvclNjaGVtZSB9IGZyb20gJy4vSGFiaXRJY29uJztcbmltcG9ydCB7IGdldEhpbmRpRGF5T2ZXZWVrIH0gZnJvbSAnLi4vc2VydmljZXMvc3RvcmFnZVNlcnZpY2UnO1xuXG5pbnRlcmZhY2UgSGFiaXRzVGFiUHJvcHMge1xuICBoYWJpdHM6IEhhYml0W107XG4gIG9uT3BlbkFkZE1vZGFsOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5FZGl0TW9kYWw6IChoYWJpdDogSGFiaXQpID0+IHZvaWQ7XG4gIG9uUmVxdWVzdERlbGV0ZUhhYml0OiAoaGFiaXQ6IEhhYml0KSA9PiB2b2lkO1xuICBvblRvZ2dsZVBhdXNlSGFiaXQ6IChoYWJpdDogSGFiaXQpID0+IHZvaWQ7XG59XG5cbmNvbnN0IENBVEVHT1JJRVM6ICgn4KS44KSt4KWAJyB8IEhhYml0Q2F0ZWdvcnkpW10gPSBbJ+CkuOCkreClgCcsICfgpLjgpY3gpLXgpL7gpLjgpY3gpKXgpY3gpK8nLCAn4KSq4KSi4KS84KS+4KSIJywgJ+Ckh+CkrOCkvuCkpuCkpCcsICfgpLXgpY3gpK/gpJXgpY3gpKTgpL/gpJfgpKQg4KS14KS/4KSV4KS+4KS4JywgJ+CkheCkqOCljeCkryddO1xuXG5leHBvcnQgY29uc3QgSGFiaXRzVGFiOiBSZWFjdC5GQzxIYWJpdHNUYWJQcm9wcz4gPSAoe1xuICBoYWJpdHMsXG4gIG9uT3BlbkFkZE1vZGFsLFxuICBvbk9wZW5FZGl0TW9kYWwsXG4gIG9uUmVxdWVzdERlbGV0ZUhhYml0LFxuICBvblRvZ2dsZVBhdXNlSGFiaXQsXG59KSA9PiB7XG4gIGNvbnN0IFtzZWxlY3RlZENhdGVnb3J5LCBzZXRTZWxlY3RlZENhdGVnb3J5XSA9IHVzZVN0YXRlPCfgpLjgpK3gpYAnIHwgSGFiaXRDYXRlZ29yeT4oJ+CkuOCkreClgCcpO1xuICBjb25zdCBbdmlld0FyY2hpdmVkLCBzZXRWaWV3QXJjaGl2ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGFjdGl2ZUhhYml0cyA9IGhhYml0cy5maWx0ZXIoKGgpID0+ICFoLmlzUGF1c2VkKTtcbiAgY29uc3QgcGF1c2VkSGFiaXRzID0gaGFiaXRzLmZpbHRlcigoaCkgPT4gaC5pc1BhdXNlZCk7XG5cbiAgY29uc3QgZGlzcGxheWVkTGlzdCA9ICh2aWV3QXJjaGl2ZWQgPyBwYXVzZWRIYWJpdHMgOiBhY3RpdmVIYWJpdHMpLmZpbHRlcigoaCkgPT4ge1xuICAgIGlmIChzZWxlY3RlZENhdGVnb3J5ID09PSAn4KS44KSt4KWAJykgcmV0dXJuIHRydWU7XG4gICAgcmV0dXJuIGguY2F0ZWdvcnkgPT09IHNlbGVjdGVkQ2F0ZWdvcnk7XG4gIH0pO1xuXG4gIGNvbnN0IGZvcm1hdFNjaGVkdWxlZERheXMgPSAoaGFiaXQ6IEhhYml0KTogc3RyaW5nID0+IHtcbiAgICBpZiAoaGFiaXQuZnJlcXVlbmN5VHlwZSA9PT0gJ2RhaWx5JyB8fCAhaGFiaXQuc2NoZWR1bGVkRGF5cyB8fCBoYWJpdC5zY2hlZHVsZWREYXlzLmxlbmd0aCA9PT0gNykge1xuICAgICAgcmV0dXJuICfgpKrgpY3gpLDgpKTgpL/gpKbgpL/gpKggKOCksOCli+CknOCkvOCkvuCkqOCkviknO1xuICAgIH1cbiAgICByZXR1cm4gaGFiaXQuc2NoZWR1bGVkRGF5cy5tYXAoKGQpID0+IGdldEhpbmRpRGF5T2ZXZWVrKGQpKS5qb2luKCcsICcpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwYi0yNCBwdC00IHB4LTQgbWF4LXctbWQgbXgtYXV0byBzcGFjZS15LTRcIj5cbiAgICAgIHsvKiBUb3AgSGVhZGVyIENhcmQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgICAg4KSu4KWH4KSw4KWAIOCkhuCkpuCkpOClh+CkgiDgpKrgpY3gpLDgpKzgpILgpKfgpL/gpKQg4KSV4KSw4KWH4KSCXG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICAgIOCkleClgeCksiDgpIbgpKbgpKTgpYfgpII6IHtoYWJpdHMubGVuZ3RofSAo4KS44KSV4KWN4KSw4KS/4KSvOiB7YWN0aXZlSGFiaXRzLmxlbmd0aH0sIOCksOCli+CkleClgCDgpJfgpIg6IHtwYXVzZWRIYWJpdHMubGVuZ3RofSlcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5BZGRNb2RhbH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJweS0yIHB4LTMuNSByb3VuZGVkLTJ4bCBiZy1lbWVyYWxkLTcwMCBob3ZlcjpiZy1lbWVyYWxkLTgwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hhZG93LW1kIHRyYW5zaXRpb24gYWN0aXZlOnNjYWxlLTk1IGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxQbHVzIHNpemU9ezE2fSAvPlxuICAgICAgICAgIDxzcGFuPuCkqOCkiCDgpIbgpKbgpKQ8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBY3RpdmUgdnMgUGF1c2VkL0FyY2hpdmVkIFRhYnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctc3RvbmUtMjAwLzgwIGRhcms6Ymctc3RvbmUtODAwLzgwIHAtMSByb3VuZGVkLTJ4bCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFZpZXdBcmNoaXZlZChmYWxzZSl9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTIgcm91bmRlZC14bCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICF2aWV3QXJjaGl2ZWRcbiAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8TGF5ZXJzIHNpemU9ezE0fSAvPlxuICAgICAgICAgIDxzcGFuPuCkuOCkleCljeCksOCkv+CkryDgpIbgpKbgpKTgpYfgpIIgKHthY3RpdmVIYWJpdHMubGVuZ3RofSk8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Vmlld0FyY2hpdmVkKHRydWUpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0yIHJvdW5kZWQteGwgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICB2aWV3QXJjaGl2ZWRcbiAgICAgICAgICAgICAgPyAnYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8QXJjaGl2ZSBzaXplPXsxNH0gLz5cbiAgICAgICAgICA8c3Bhbj7gpLDgpYvgpJXgpYAg4KSX4KSIIC8g4KSq4KWB4KSw4KS+4KSy4KWH4KSWICh7cGF1c2VkSGFiaXRzLmxlbmd0aH0pPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ2F0ZWdvcnkgRmlsdGVyIENoaXBzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG92ZXJmbG93LXgtYXV0byBwYi0xIHNjcm9sbGJhci1ub25lXCI+XG4gICAgICAgIHtDQVRFR09SSUVTLm1hcCgoY2F0KSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtjYXR9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZENhdGVnb3J5KGNhdCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1tZWRpdW0gc2hyaW5rLTAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBzZWxlY3RlZENhdGVnb3J5ID09PSBjYXRcbiAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgZGFyazpiZy1zdG9uZS04MDAgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgaG92ZXI6Ymctc3RvbmUtMTAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2NhdH1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEhhYml0cyBMaXN0ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAge2Rpc3BsYXllZExpc3QubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLXN0b25lLTMwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgcm91bmRlZC0zeGwgcC04IHRleHQtY2VudGVyIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgbXgtYXV0byByb3VuZGVkLWZ1bGwgYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwIHRleHQtc3RvbmUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxMYXllcnMgc2l6ZT17MjJ9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS04MDAgZGFyazp0ZXh0LXN0b25lLTIwMCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAge3ZpZXdBcmNoaXZlZFxuICAgICAgICAgICAgICAgICAgPyAn4KSV4KWL4KSIIOCksOCli+CkleClgCDgpJfgpIgg4KSG4KSm4KSkIOCkqOCkueClgOCkgiDgpLngpYgnXG4gICAgICAgICAgICAgICAgICA6ICfgpIfgpLgg4KS24KWN4KSw4KWH4KSj4KWAIOCkruClh+CkgiDgpJXgpYvgpIgg4KS44KSV4KWN4KSw4KS/4KSvIOCkhuCkpuCkpCDgpKjgpLngpYDgpIIg4KSu4KS/4KSy4KWAJ31cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICB7dmlld0FyY2hpdmVkXG4gICAgICAgICAgICAgICAgICA/ICfgpJzgpKwg4KSG4KSqIOCkleCkv+CkuOClgCDgpIbgpKbgpKQg4KSV4KWLIOCkheCkuOCljeCkpeCkvuCkr+ClgCDgpLDgpYLgpKog4KS44KWHIOCksOCli+CkleCkpOClhyDgpLngpYjgpIIsIOCkpOCliyDgpLXgpLkg4KSv4KS54KS+4KSBIOCkpuCkv+CkluCkvuCkiCDgpKbgpYfgpJfgpYDgpaQnXG4gICAgICAgICAgICAgICAgICA6ICfgpIbgpKog4KSK4KSq4KSwIOCkpuCkv+CkjyDgpJfgpI8gXCIrIOCkqOCkiCDgpIbgpKbgpKRcIiDgpKzgpJ/gpKgg4KS44KWHIOCkqOCkiCDgpIbgpKbgpKQg4KSc4KWL4KSh4KS8IOCkuOCkleCkpOClhyDgpLngpYjgpILgpaQnfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICBkaXNwbGF5ZWRMaXN0Lm1hcCgoaGFiaXQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvbG9yU2NoZW1lID0gZ2V0Q29sb3JTY2hlbWUoaGFiaXQuY29sb3IpO1xuXG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtoYWJpdC5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC84MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgcm91bmRlZC0zeGwgcC00IHNoYWRvdy14cyB0cmFuc2l0aW9uIGhvdmVyOmJvcmRlci1zdG9uZS0zMDAgJHtcbiAgICAgICAgICAgICAgICAgIGhhYml0LmlzUGF1c2VkID8gJ29wYWNpdHktNzUgYmctc3RvbmUtNTAvNTAgZGFyazpiZy1zdG9uZS05MDAvNDAnIDogJydcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgey8qIEljb24gKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMTEgaC0xMSByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCBib3JkZXIgJHtjb2xvclNjaGVtZS5iZ30gJHtjb2xvclNjaGVtZS5ib3JkZXJ9ICR7Y29sb3JTY2hlbWUudGV4dH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8SGFiaXRJY29uIG5hbWU9e2hhYml0Lmljb259IHNpemU9ezIyfSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBIYWJpdCBEZXRhaWxzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1zdG9uZS0xMDAgZGFyazpiZy1zdG9uZS04MDAgdGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2hhYml0LmNhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7aGFiaXQuaXNQYXVzZWQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgdGV4dC1hbWJlci04MDAgZGFyazpiZy1hbWJlci05NTAvNjAgZGFyazp0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICDgpIXgpLjgpY3gpKXgpL7gpK/gpYAg4KSw4KWL4KSV4KWAIOCkl+CkiFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgbXQtMSB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtoYWJpdC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2g0PlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBUYXJnZXQgJiBTY2hlZHVsZSBpbmZvICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41IG10LTEgdGV4dC14cyB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4KSy4KSV4KWN4KS34KWN4KSvOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtoYWJpdC50YXJnZXRUeXBlID09PSAnbnVtZXJpYydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGAke2hhYml0LnRhcmdldFZhbHVlfSAke2hhYml0LnVuaXR9YFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ+CkpuCliOCkqOCkv+CklSDgpacg4KSs4KS+4KSwJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIHNpemU9ezEyfSBjbGFzc05hbWU9XCJzaHJpbmstMCB0ZXh0LXN0b25lLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntmb3JtYXRTY2hlZHVsZWREYXlzKGhhYml0KX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAge2hhYml0LnJlbWluZGVyVGltZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1bMTFweF0gdGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPENsb2NrIHNpemU9ezEyfSBjbGFzc05hbWU9XCJzaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuCksOCkv+CkruCkvuCkh+CkguCkoeCksDoge2hhYml0LnJlbWluZGVyVGltZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEhhYml0IEFjdGlvbnMgQmFyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMy41IHB0LTMgYm9yZGVyLXQgYm9yZGVyLXN0b25lLTEwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIHsvKiBQYXVzZSAvIFJlc3VtZSBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uVG9nZ2xlUGF1c2VIYWJpdChoYWJpdCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1lbWVyYWxkLTcwMCBkYXJrOmhvdmVyOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2hhYml0LmlzUGF1c2VkID8gJ+CkhuCkpuCkpCDgpKrgpYHgpKjgpIMg4KS24KWB4KSw4KWCIOCkleCksOClh+CkgicgOiAn4KSG4KSm4KSkIOCksOCli+CkleClh+Ckgid9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtoYWJpdC5pc1BhdXNlZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgPFBsYXlDaXJjbGUgc2l6ZT17MTV9IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4KSq4KWB4KSo4KSDIOCktuClgeCksOClgiDgpJXgpLDgpYfgpII8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYXVzZUNpcmNsZSBzaXplPXsxNX0gLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuCksOCli+CkleClh+CkgiAoUGF1c2UpPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgey8qIEVkaXQgQnV0dG9uICovfVxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuRWRpdE1vZGFsKGhhYml0KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkLXhsIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCBob3ZlcjpiZy1zdG9uZS0yMDAgZGFyazpob3ZlcjpiZy1zdG9uZS03MDAgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPEVkaXQzIHNpemU9ezEzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuCkuOCkguCkquCkvuCkpuCkv+CkpCDgpJXgpLDgpYfgpII8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICAgIHsvKiBEZWxldGUgQnV0dG9uICovfVxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25SZXF1ZXN0RGVsZXRlSGFiaXQoaGFiaXQpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQteGwgdGV4dC1yZWQtNTAwIGhvdmVyOnRleHQtcmVkLTcwMCBob3ZlcjpiZy1yZWQtNTAgZGFyazpob3ZlcjpiZy1yZWQtOTUwLzQwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwi4KSG4KSm4KSkIOCkueCkn+CkvuCkj+CkglwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSlcbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogSW5mbyBUaXAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQtMnhsIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC8zMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwLzYwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwLzYwIHRleHQteHMgdGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICA8QWxlcnRDaXJjbGUgc2l6ZT17MTZ9IGNsYXNzTmFtZT1cInNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgIDxwPlxuICAgICAgICAgIOCkhuCkpuCkpCDgpJXgpYsgXCLgpLDgpYvgpJXgpKjgpYdcIiAoUGF1c2UpIOCkuOClhyDgpIbgpKrgpJXgpL4g4KSq4KWB4KSw4KS+4KSo4KS+IOCkh+CkpOCkv+CkueCkvuCkuCDgpLjgpYHgpLDgpJXgpY3gpLfgpL/gpKQg4KSw4KS54KSk4KS+IOCkueCliCDgpJTgpLAg4KS44KWN4KSf4KWN4KSw4KWA4KSVIOCksOCkv+CkleClieCksOCljeCkoSDgpKjgpLfgpY3gpJ8g4KSo4KS54KWA4KSCIOCkueCli+CkpOClh+ClpFxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=