const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { CalendarCheck, ListCheck, BarChart3, Settings } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
var _jsxFileName = "/app/applet/src/components/BottomNav.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const BottomNav = ({ currentTab, onChangeTab, pendingTodayCount = 0 }) => {
	const tabs = [
		{
			id: "today",
			label: "आज",
			icon: CalendarCheck,
			badge: pendingTodayCount > 0 ? pendingTodayCount : null
		},
		{
			id: "habits",
			label: "मेरी आदतें",
			icon: ListCheck,
			badge: null
		},
		{
			id: "progress",
			label: "प्रगति",
			icon: BarChart3,
			badge: null
		},
		{
			id: "settings",
			label: "सेटिंग्स",
			icon: Settings,
			badge: null
		}
	];
	return /* @__PURE__ */ _jsxDEV("nav", {
		className: "fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-t border-stone-200 dark:border-stone-800 shadow-lg",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-md mx-auto grid grid-cols-4 px-2 py-1.5",
			children: tabs.map((tab) => {
				const Icon = tab.icon;
				const isActive = currentTab === tab.id;
				return /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onChangeTab(tab.id),
					className: `flex flex-col items-center justify-center py-1.5 px-1 rounded-2xl relative transition-all duration-150 cursor-pointer ${isActive ? "text-emerald-700 dark:text-emerald-400 font-bold" : "text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200 font-medium"}`,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: `p-1 rounded-xl transition ${isActive ? "bg-emerald-100 dark:bg-emerald-950/60 scale-105" : ""}`,
								children: /* @__PURE__ */ _jsxDEV(Icon, {
									size: 22,
									strokeWidth: isActive ? 2.4 : 1.9
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 17
							}, this), tab.badge !== null && /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute -top-1 -right-1.5 min-w-[17px] h-[17px] px-1 bg-amber-500 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-xs",
								children: tab.badge
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: `text-[11px] mt-0.5 tracking-tight ${isActive ? "font-bold" : ""}`,
							children: tab.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 15
						}, this),
						isActive && /* @__PURE__ */ _jsxDEV("span", { className: "w-1.5 h-1.5 bg-emerald-600 dark:bg-emerald-400 rounded-full mt-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 17
						}, this)
					]
				}, tab.id, true, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZUFBZSxXQUFXLFdBQVcsZ0JBQWdCOzs7QUFVOUQsT0FBTyxNQUFNLGFBQXVDLEVBQ2xELFlBQ0EsYUFDQSxvQkFBb0IsUUFDaEI7Q0FDSixNQUFNLE9BQU87RUFDWDtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU8sb0JBQW9CLElBQUksb0JBQW9CO0VBQ3JEO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPO0VBQ1Q7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87RUFDVDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztFQUNUO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixLQUFLLEtBQUssUUFBUTtJQUNqQixNQUFNLE9BQU8sSUFBSTtJQUNqQixNQUFNLFdBQVcsZUFBZSxJQUFJO0lBRXBDLE9BQ0Usd0JBQUMsVUFBRDtLQUVFLGVBQWUsWUFBWSxJQUFJLEVBQUU7S0FDakMsV0FBVyx5SEFDVCxXQUNJLHFEQUNBO2VBTlI7TUFTRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFDRSxXQUFXLDZCQUNULFdBQVcsb0RBQW9EO2tCQUdqRSx3QkFBQyxNQUFEO1NBQU0sTUFBTTtTQUFJLGFBQWEsV0FBVyxNQUFNO1FBQU07Ozs7O09BQ2pEOzs7O2lCQUNKLElBQUksVUFBVSxRQUNiLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiLElBQUk7T0FDRDs7OztlQUVMOzs7Ozs7TUFDTCx3QkFBQyxRQUFEO09BQU0sV0FBVyxxQ0FBcUMsV0FBVyxjQUFjO2lCQUM1RSxJQUFJO01BQ0Q7Ozs7O01BQ0wsWUFDQyx3QkFBQyxRQUFELEVBQU0sV0FBVSxxRUFBc0U7Ozs7O0tBRWxGO09BNUJELElBQUk7Ozs7V0E0Qkg7R0FFWixDQUFDO0VBQ0U7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQm90dG9tTmF2LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ2FsZW5kYXJDaGVjaywgTGlzdENoZWNrLCBCYXJDaGFydDMsIFNldHRpbmdzIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IHR5cGUgTmF2VGFiID0gJ3RvZGF5JyB8ICdoYWJpdHMnIHwgJ3Byb2dyZXNzJyB8ICdzZXR0aW5ncyc7XG5cbmludGVyZmFjZSBCb3R0b21OYXZQcm9wcyB7XG4gIGN1cnJlbnRUYWI6IE5hdlRhYjtcbiAgb25DaGFuZ2VUYWI6ICh0YWI6IE5hdlRhYikgPT4gdm9pZDtcbiAgcGVuZGluZ1RvZGF5Q291bnQ/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBjb25zdCBCb3R0b21OYXY6IFJlYWN0LkZDPEJvdHRvbU5hdlByb3BzPiA9ICh7XG4gIGN1cnJlbnRUYWIsXG4gIG9uQ2hhbmdlVGFiLFxuICBwZW5kaW5nVG9kYXlDb3VudCA9IDAsXG59KSA9PiB7XG4gIGNvbnN0IHRhYnMgPSBbXG4gICAge1xuICAgICAgaWQ6ICd0b2RheScgYXMgTmF2VGFiLFxuICAgICAgbGFiZWw6ICfgpIbgpJwnLFxuICAgICAgaWNvbjogQ2FsZW5kYXJDaGVjayxcbiAgICAgIGJhZGdlOiBwZW5kaW5nVG9kYXlDb3VudCA+IDAgPyBwZW5kaW5nVG9kYXlDb3VudCA6IG51bGwsXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2hhYml0cycgYXMgTmF2VGFiLFxuICAgICAgbGFiZWw6ICfgpK7gpYfgpLDgpYAg4KSG4KSm4KSk4KWH4KSCJyxcbiAgICAgIGljb246IExpc3RDaGVjayxcbiAgICAgIGJhZGdlOiBudWxsLFxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdwcm9ncmVzcycgYXMgTmF2VGFiLFxuICAgICAgbGFiZWw6ICfgpKrgpY3gpLDgpJfgpKTgpL8nLFxuICAgICAgaWNvbjogQmFyQ2hhcnQzLFxuICAgICAgYmFkZ2U6IG51bGwsXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ3NldHRpbmdzJyBhcyBOYXZUYWIsXG4gICAgICBsYWJlbDogJ+CkuOClh+Ckn+Ckv+CkguCkl+CljeCkuCcsXG4gICAgICBpY29uOiBTZXR0aW5ncyxcbiAgICAgIGJhZGdlOiBudWxsLFxuICAgIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8bmF2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS0wIGxlZnQtMCByaWdodC0wIHotNDAgYmctd2hpdGUvOTUgZGFyazpiZy1zdG9uZS05MDAvOTUgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXItdCBib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBzaGFkb3ctbGdcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgbXgtYXV0byBncmlkIGdyaWQtY29scy00IHB4LTIgcHktMS41XCI+XG4gICAgICAgIHt0YWJzLm1hcCgodGFiKSA9PiB7XG4gICAgICAgICAgY29uc3QgSWNvbiA9IHRhYi5pY29uO1xuICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gY3VycmVudFRhYiA9PT0gdGFiLmlkO1xuXG4gICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXt0YWIuaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlVGFiKHRhYi5pZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB5LTEuNSBweC0xIHJvdW5kZWQtMnhsIHJlbGF0aXZlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTE1MCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICA/ICd0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGQnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGhvdmVyOnRleHQtc3RvbmUtODAwIGRhcms6aG92ZXI6dGV4dC1zdG9uZS0yMDAgZm9udC1tZWRpdW0nXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0xIHJvdW5kZWQteGwgdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICBpc0FjdGl2ZSA/ICdiZy1lbWVyYWxkLTEwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzYwIHNjYWxlLTEwNScgOiAnJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEljb24gc2l6ZT17MjJ9IHN0cm9rZVdpZHRoPXtpc0FjdGl2ZSA/IDIuNCA6IDEuOX0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB7dGFiLmJhZGdlICE9PSBudWxsICYmIChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMSAtcmlnaHQtMS41IG1pbi13LVsxN3B4XSBoLVsxN3B4XSBweC0xIGJnLWFtYmVyLTUwMCB0ZXh0LXdoaXRlIHRleHQtWzEwcHhdIGZvbnQtYmxhY2sgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNoYWRvdy14c1wiPlxuICAgICAgICAgICAgICAgICAgICB7dGFiLmJhZGdlfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBtdC0wLjUgdHJhY2tpbmctdGlnaHQgJHtpc0FjdGl2ZSA/ICdmb250LWJvbGQnIDogJyd9YH0+XG4gICAgICAgICAgICAgICAge3RhYi5sYWJlbH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICB7aXNBY3RpdmUgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMS41IGgtMS41IGJnLWVtZXJhbGQtNjAwIGRhcms6YmctZW1lcmFsZC00MDAgcm91bmRlZC1mdWxsIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApO1xuICAgICAgICB9KX1cbiAgICAgIDwvZGl2PlxuICAgIDwvbmF2PlxuICApO1xufTtcbiJdfQ==