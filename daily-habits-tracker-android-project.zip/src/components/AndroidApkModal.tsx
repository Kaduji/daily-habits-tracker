const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { X, Smartphone, Download, Copy, Check, ShieldCheck, Laptop, Cloud, FileCode, FolderArchive } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { downloadAndroidProjectZip } from "/src/services/androidExportService.ts";
var _jsxFileName = "/app/applet/src/components/AndroidApkModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const AndroidApkModal = ({ isOpen, onClose }) => {
	const [activeTab, setActiveTab] = useState("steps");
	const [copiedText, setCopiedText] = useState(null);
	const [isDownloadingZip, setIsDownloadingZip] = useState(false);
	if (!isOpen) return null;
	const handleCopy = (text, id) => {
		navigator.clipboard.writeText(text);
		setCopiedText(id);
		setTimeout(() => setCopiedText(null), 2500);
	};
	const handleDownloadZip = async () => {
		try {
			setIsDownloadingZip(true);
			await downloadAndroidProjectZip();
		} catch (e) {
			console.error("ZIP download error:", e);
		} finally {
			setIsDownloadingZip(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-lg bg-white dark:bg-stone-900 rounded-3xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[90vh]",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 sm:p-5 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between bg-stone-50/70 dark:bg-stone-800/40",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-2xl bg-emerald-100 dark:bg-emerald-950/70 text-emerald-700 dark:text-emerald-300 flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(Smartphone, { size: 20 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "text-base font-black text-stone-900 dark:text-stone-100",
							children: "APK बनाने और डाउनलोड करने का तरीका"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-stone-500 dark:text-stone-400",
							children: "Android डिवाइस के लिए संपूर्ण गाइड"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-200 dark:hover:bg-stone-700 transition cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex border-b border-stone-200 dark:border-stone-800 bg-stone-50 dark:bg-stone-850 px-3 pt-2 gap-1 overflow-x-auto scrollbar-none",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("steps"),
							className: `px-3 py-2 text-xs font-bold rounded-t-xl transition whitespace-nowrap cursor-pointer ${activeTab === "steps" ? "bg-white dark:bg-stone-900 text-emerald-700 dark:text-emerald-400 border-t-2 border-emerald-600" : "text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200"}`,
							children: "१. कंप्यूटर में बनाएं"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("cloud"),
							className: `px-3 py-2 text-xs font-bold rounded-t-xl transition whitespace-nowrap cursor-pointer ${activeTab === "cloud" ? "bg-white dark:bg-stone-900 text-emerald-700 dark:text-emerald-400 border-t-2 border-emerald-600" : "text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200"}`,
							children: "२. मुफ्त क्लाउड बिल्ड (GitHub)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("install"),
							className: `px-3 py-2 text-xs font-bold rounded-t-xl transition whitespace-nowrap cursor-pointer ${activeTab === "install" ? "bg-white dark:bg-stone-900 text-emerald-700 dark:text-emerald-400 border-t-2 border-emerald-600" : "text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200"}`,
							children: "३. फोन में इनस्टॉल कैसे करें"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("files"),
							className: `px-3 py-2 text-xs font-bold rounded-t-xl transition whitespace-nowrap cursor-pointer ${activeTab === "files" ? "bg-white dark:bg-stone-900 text-emerald-700 dark:text-emerald-400 border-t-2 border-emerald-600" : "text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200"}`,
							children: "४. प्रोजेक्ट फाइल्स"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 sm:p-5 overflow-y-auto space-y-4 text-xs text-stone-700 dark:text-stone-300",
					children: [
						activeTab === "steps" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-start gap-2.5",
									children: [/* @__PURE__ */ _jsxDEV(Laptop, {
										size: 18,
										className: "text-emerald-700 dark:text-emerald-300 shrink-0 mt-0.5"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 127,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "leading-relaxed",
										children: [
											"यदि आपके पास लैपटॉप या डेस्कटॉप है, तो आप ",
											/* @__PURE__ */ _jsxDEV("strong", { children: "Android Studio" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 129,
												columnNumber: 61
											}, this),
											" के माध्यम से बहुत आसानी से वास्तविक डीबग APK तैयार कर सकते हैं।"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 126,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px]",
											children: "1"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 136,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-stone-900 dark:text-stone-100",
											children: "सॉफ्टवेयर आवश्यकताएं"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 139,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-stone-600 dark:text-stone-400 leading-relaxed pl-7",
										children: [
											"कंप्यूटर में ",
											/* @__PURE__ */ _jsxDEV("strong", { children: "Java JDK 17 या 21" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 144,
												columnNumber: 32
											}, this),
											" और ",
											/* @__PURE__ */ _jsxDEV("strong", { children: "Android Studio" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 144,
												columnNumber: 70
											}, this),
											" (Ladybug या Hedgehog) इनस्टॉल होना चाहिए।"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 143,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px]",
												children: "2"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 151,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("h4", {
												className: "font-bold text-stone-900 dark:text-stone-100",
												children: "प्रोजेक्ट तैयार करना"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 154,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 150,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-stone-600 dark:text-stone-400 leading-relaxed pl-7",
											children: "नीचे दिए गए बटन से प्रोजेक्ट ज़िप डाउनलोड करें और एक्सट्रेक्ट करें। फिर टर्मिनल में यह कमांड चलाएं:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "ml-7 p-2.5 rounded-xl bg-stone-900 text-emerald-400 font-mono text-[11px] flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("code", { children: "npm run build && npx cap sync android" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 162,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: () => handleCopy("npm run build && npx cap sync android", "cmd1"),
												className: "p-1 text-stone-400 hover:text-white transition",
												title: "कॉपी करें",
												children: copiedText === "cmd1" ? /* @__PURE__ */ _jsxDEV(Check, {
													size: 14,
													className: "text-emerald-400"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 168,
													columnNumber: 46
												}, this) : /* @__PURE__ */ _jsxDEV(Copy, { size: 14 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 168,
													columnNumber: 97
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 163,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 161,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 149,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px]",
												children: "3"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 176,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("h4", {
												className: "font-bold text-stone-900 dark:text-stone-100",
												children: "APK बिल्ड कमांड"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 179,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 175,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-stone-600 dark:text-stone-400 leading-relaxed pl-7",
											children: [
												"टर्मिनल में ",
												/* @__PURE__ */ _jsxDEV("code", { children: "android" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 184,
													columnNumber: 31
												}, this),
												" फोल्डर में जाकर यह कमांड दें:"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 183,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "ml-7 p-2.5 rounded-xl bg-stone-900 text-emerald-400 font-mono text-[11px] flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("code", { children: "./gradlew assembleDebug" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 187,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: () => handleCopy("./gradlew assembleDebug", "cmd2"),
												className: "p-1 text-stone-400 hover:text-white transition",
												title: "कॉपी करें",
												children: copiedText === "cmd2" ? /* @__PURE__ */ _jsxDEV(Check, {
													size: 14,
													className: "text-emerald-400"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 46
												}, this) : /* @__PURE__ */ _jsxDEV(Copy, { size: 14 }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 97
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 188,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 186,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-[11px] text-stone-500 pl-7",
											children: [
												"या Android Studio में ऊपर मेनू से: ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Build → Build Bundle(s) / APK(s) → Build APK(s)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 197,
													columnNumber: 54
												}, this),
												" पर क्लिक करें।"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 space-y-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px]",
												children: "4"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 204,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("h4", {
												className: "font-bold text-stone-900 dark:text-stone-100",
												children: "APK फ़ाइल का स्थान"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 207,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 203,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-stone-600 dark:text-stone-400 leading-relaxed pl-7",
											children: "तैयार APK इस पाथ पर मिलेगी:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 211,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "ml-7 p-2 rounded-xl bg-stone-100 dark:bg-stone-800 font-mono text-[11px] text-stone-800 dark:text-stone-200",
											children: "android/app/build/outputs/apk/debug/app-debug.apk"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 214,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this),
						activeTab === "cloud" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-2xl flex items-start gap-2.5",
								children: [/* @__PURE__ */ _jsxDEV(Cloud, {
									size: 18,
									className: "text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 225,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "leading-relaxed",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "कंप्यूटर नहीं है? कोई बात नहीं!" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 19
									}, this), " GitHub Actions की मदद से आप बिना कंप्यूटर के क्लाउड में सीधे APK फाइल जनरेट और डाउनलोड कर सकते हैं।"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 224,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5",
											children: "1"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 233,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-stone-900 dark:text-stone-100",
											children: "GitHub पर कोड अपलोड करें"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 237,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-stone-600 dark:text-stone-400 leading-relaxed mt-0.5",
											children: "GitHub.com पर एक नई रिपॉजिटरी बनाएं और इस प्रोजेक्ट के फाइल्स अपलोड करें।"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 240,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 236,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5",
											children: "2"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 247,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-stone-900 dark:text-stone-100",
											children: "स्वचालित वर्कफ़्लो फ़ाइल"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-stone-600 dark:text-stone-400 leading-relaxed mt-0.5",
											children: [
												"हमारे प्रोजेक्ट पैकेज में ",
												/* @__PURE__ */ _jsxDEV("code", { children: ".github/workflows/build-apk.yml" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 255,
													columnNumber: 49
												}, this),
												" पहले से मौजूद है।"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 254,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 250,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 246,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "w-5 h-5 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5",
											children: "3"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 261,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-bold text-stone-900 dark:text-stone-100",
											children: "APK डाउनलोड लिंक"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 265,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("p", {
											className: "text-stone-600 dark:text-stone-400 leading-relaxed mt-0.5",
											children: [
												"GitHub के ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Actions" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 269,
													columnNumber: 33
												}, this),
												" टैब में जाएं। 2-3 मिनट में बिल्ड सफल होने के बाद ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "DailyHabits-Hindi-Debug-APK" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 269,
													columnNumber: 107
												}, this),
												" पर क्लिक करके डाउनलोड करें।"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 268,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 264,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 260,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 223,
							columnNumber: 13
						}, this),
						activeTab === "install" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-stone-900 dark:text-stone-100 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Smartphone, {
										size: 16,
										className: "text-emerald-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 282,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "एंड्रॉइड फोन में इनस्टॉल करने के चरण:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 283,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("ol", {
									className: "list-decimal pl-5 space-y-1.5 text-stone-600 dark:text-stone-400",
									children: [
										/* @__PURE__ */ _jsxDEV("li", { children: [
											"तैयार ",
											/* @__PURE__ */ _jsxDEV("strong", { children: "app-debug.apk" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 287,
												columnNumber: 27
											}, this),
											" फ़ाइल को WhatsApp, Google Drive या USB द्वारा अपने फोन में भेजें।"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 286,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: "फोन के फ़ाइल मैनेजर (Files) में डाउनलोड फोल्डर खोलें और APK फ़ाइल पर टैप करें।" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 289,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [
											"यदि फोन चेतावनी दे कि सुरक्षा के कारण अज्ञात ऐप्स ब्लॉक हैं, तो ",
											/* @__PURE__ */ _jsxDEV("strong", { children: "Settings" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 293,
												columnNumber: 85
											}, this),
											" पर टैप करें।"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 292,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "\"Allow from this source\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 296,
											columnNumber: 21
										}, this), " (इस स्रोत से अनुमति दें) को चालू करें।"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 295,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Install (इनस्टॉल करें)" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 299,
											columnNumber: 21
										}, this), " बटन दबाएं। कुछ ही सेकंड में ऐप आपके फोन में इनस्टॉल हो जाएगा!"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 298,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "border border-stone-200 dark:border-stone-800 rounded-2xl p-3.5 space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-stone-900 dark:text-stone-100 flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
										size: 16,
										className: "text-emerald-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 307,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "सुरक्षा एवं अनुमतियां (Permissions):" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("ul", {
									className: "space-y-2 text-stone-600 dark:text-stone-400",
									children: [
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-emerald-600 dark:text-emerald-400",
												children: "• इंटरनेट (INTERNET):"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 312,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "केवल यदि आप प्रेरणादायक विचार या ऑनलाइन बैकअप सिंक करते हैं।" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 313,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-emerald-600 dark:text-emerald-400",
												children: "• नोटिफिकेशन (POST_NOTIFICATIONS):"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 316,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "आपकी निर्धारित आदतों के दैनिक रिमाइंडर समय पर बजने के लिए।" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 317,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-emerald-600 dark:text-emerald-400",
												children: "• वाइब्रेशन (VIBRATE):"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 320,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "रिमाइंडर अलार्म पर कंपन के लिए।" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 321,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 319,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-emerald-600 dark:text-emerald-400",
												children: "• गोपनीयता (100% Privacy):"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 324,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "कोई व्यक्तिगत डेटा किसी तीसरे पक्ष को नहीं भेजा जाता। सब कुछ आपके डिवाइस में सुरक्षित रहता है।" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 325,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 323,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 310,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 305,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 13
						}, this),
						activeTab === "files" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3.5 bg-stone-50 dark:bg-stone-800/60 border border-stone-200 dark:border-stone-700 rounded-2xl space-y-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 font-bold text-stone-900 dark:text-stone-100",
									children: [/* @__PURE__ */ _jsxDEV(FileCode, {
										size: 16,
										className: "text-emerald-600"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "शामिल कॉन्फ़िगरेशन फाइल्स:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 338,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("ul", {
									className: "space-y-1 text-stone-600 dark:text-stone-400 pl-4 list-disc text-[11px]",
									children: [
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("code", { children: "AndroidManifest.xml" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 341,
											columnNumber: 23
										}, this), " (सभी आवश्यक अनुमतियों के साथ)"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 341,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("code", { children: "capacitor.config.json" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 342,
											columnNumber: 23
										}, this), " (पैकेज आईडी: com.dailyhabits.hindi)"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 342,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [
											/* @__PURE__ */ _jsxDEV("code", { children: "build.gradle" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 343,
												columnNumber: 23
											}, this),
											" और ",
											/* @__PURE__ */ _jsxDEV("code", { children: "variables.gradle" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 343,
												columnNumber: 52
											}, this),
											" (SDK 34)"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 343,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("code", { children: ".github/workflows/build-apk.yml" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 23
										}, this), " (मुफ्त क्लाउड बिल्ड के लिए)"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("code", { children: "README-HINDI.md" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 23
										}, this), " (संपूर्ण हिंदी गाइडबुक)"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 340,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleDownloadZip,
								disabled: isDownloadingZip,
								className: "w-full py-3 px-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-md active:scale-95",
								children: [/* @__PURE__ */ _jsxDEV(FolderArchive, { size: 16 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 354,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDownloadingZip ? "ज़िप फ़ाइल तैयार हो रही है..." : "प्रोजेक्ट फाइल्स (ZIP) डाउनलोड करें" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 355,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 334,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-3 sm:p-4 border-t border-stone-100 dark:border-stone-800 bg-stone-50/70 dark:bg-stone-800/40 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleDownloadZip,
						disabled: isDownloadingZip,
						className: "py-2 px-3 rounded-xl bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer",
						children: [/* @__PURE__ */ _jsxDEV(Download, { size: 14 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 372,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "प्रोजेक्ट ZIP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 367,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "py-2 px-4 rounded-xl bg-stone-800 hover:bg-stone-900 dark:bg-stone-700 dark:hover:bg-stone-600 text-white font-bold text-xs transition cursor-pointer",
						children: "बंद करें"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 376,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 366,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLEdBQ0EsWUFDQSxVQUNBLE1BQ0EsT0FDQSxhQUNBLFFBQ0EsT0FHQSxVQUNBLHFCQUNLO0FBQ1AsU0FBUyxpQ0FBaUM7OztBQU8xQyxPQUFPLE1BQU0sbUJBQW1ELEVBQUUsUUFBUSxjQUFjO0NBQ3RGLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFrRCxPQUFPO0NBQzNGLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUF3QixJQUFJO0NBQ2hFLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUU5RCxJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sY0FBYyxNQUFjLE9BQWU7RUFDL0MsVUFBVSxVQUFVLFVBQVUsSUFBSTtFQUNsQyxjQUFjLEVBQUU7RUFDaEIsaUJBQWlCLGNBQWMsSUFBSSxHQUFHLElBQUk7Q0FDNUM7Q0FFQSxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLElBQUk7R0FDRixvQkFBb0IsSUFBSTtHQUN4QixNQUFNLDBCQUEwQjtFQUNsQyxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sdUJBQXVCLENBQUM7RUFDeEMsVUFBVTtHQUNSLG9CQUFvQixLQUFLO0VBQzNCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUNFLFdBQVU7R0FDVixVQUFVLE1BQU0sRUFBRSxnQkFBZ0I7YUFGcEM7SUFLRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7OztNQUNwQjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTBEO01BRXBFOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QztNQUV2RDs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBRUwsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0tBQ1I7Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsT0FBTztPQUNuQyxXQUFXLHdGQUNULGNBQWMsVUFDVixvR0FDQTtpQkFFUDtNQUVPOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsT0FBTztPQUNuQyxXQUFXLHdGQUNULGNBQWMsVUFDVixvR0FDQTtpQkFFUDtNQUVPOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsU0FBUztPQUNyQyxXQUFXLHdGQUNULGNBQWMsWUFDVixvR0FDQTtpQkFFUDtNQUVPOzs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsT0FBTztPQUNuQyxXQUFXLHdGQUNULGNBQWMsVUFDVixvR0FDQTtpQkFFUDtNQUVPOzs7OztLQUNMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUcsY0FBYyxXQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQVEsTUFBTTtVQUFJLFdBQVU7U0FBMEQ7Ozs7bUJBQ3RGLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUFiO1dBQStCO1dBQ2Esd0JBQUMsVUFBRCxZQUFRLGlCQUFzQjs7Ozs7V0FBQztVQUN4RTs7Ozs7aUJBQ0E7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBd0c7VUFFbEg7Ozs7b0JBQ04sd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQStDO1VBRXpEOzs7O2tCQUNEOzs7OzttQkFDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUF1RTtXQUN4RCx3QkFBQyxVQUFELFlBQVEsb0JBQXlCOzs7OztXQUFDO1dBQUksd0JBQUMsVUFBRCxZQUFRLGlCQUFzQjs7Ozs7V0FBQztVQUNqRjs7Ozs7aUJBQ0E7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBd0c7V0FFbEg7Ozs7cUJBQ04sd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQStDO1dBRXpEOzs7O21CQUNEOzs7Ozs7VUFDTCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBMEQ7VUFFcEU7Ozs7O1VBQ0gsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sd0NBQTJDOzs7O3FCQUNqRCx3QkFBQyxVQUFEO1lBQ0UsZUFBZSxXQUFXLHlDQUF5QyxNQUFNO1lBQ3pFLFdBQVU7WUFDVixPQUFNO3NCQUVMLGVBQWUsU0FBUyx3QkFBQyxPQUFEO2FBQU8sTUFBTTthQUFJLFdBQVU7WUFBb0I7Ozs7dUJBQUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7V0FDdkY7Ozs7bUJBQ0w7Ozs7OztTQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXdHO1dBRWxIOzs7O3FCQUNOLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUErQztXQUV6RDs7OzttQkFDRDs7Ozs7O1VBQ0wsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQWI7WUFBdUU7WUFDekQsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7O1lBQUM7V0FDL0I7Ozs7OztVQUNILHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztxQkFDbkMsd0JBQUMsVUFBRDtZQUNFLGVBQWUsV0FBVywyQkFBMkIsTUFBTTtZQUMzRCxXQUFVO1lBQ1YsT0FBTTtzQkFFTCxlQUFlLFNBQVMsd0JBQUMsT0FBRDthQUFPLE1BQU07YUFBSSxXQUFVO1lBQW9COzs7O3VCQUFJLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O1dBQ3ZGOzs7O21CQUNMOzs7Ozs7VUFDTCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUErQztZQUNWLHdCQUFDLFVBQUQsWUFBUSxrREFBdUQ7Ozs7O1lBQUM7V0FDbEc7Ozs7OztTQUNBOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXdHO1dBRWxIOzs7O3FCQUNOLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUErQztXQUV6RDs7OzttQkFDRDs7Ozs7O1VBQ0wsd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQTBEO1VBRXBFOzs7OztVQUNILHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE4RztVQUV4SDs7Ozs7U0FDRjs7Ozs7O09BQ0Y7Ozs7OztNQUlOLGNBQWMsV0FDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFPLE1BQU07U0FBSSxXQUFVO1FBQXdEOzs7O2tCQUNuRix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYixDQUNFLHdCQUFDLFVBQUQsWUFBUSxrQ0FBdUM7Ozs7bUJBQUMsc0dBQy9DOzs7OztnQkFDQTs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF1SDtVQUVqSTs7OztvQkFDTix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQStDO1VBRXpEOzs7O29CQUNKLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE0RDtVQUV0RTs7OztrQkFDQTs7OztrQkFDRjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBdUg7VUFFakk7Ozs7b0JBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUErQztVQUV6RDs7OztvQkFDSix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUF5RTtZQUM3Qyx3QkFBQyxRQUFELFlBQU0sa0NBQXFDOzs7OztZQUFDO1dBQ3JFOzs7OztrQkFDQTs7OztrQkFDRjs7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBdUg7VUFFakk7Ozs7b0JBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUErQztVQUV6RDs7OztvQkFDSix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUF5RTtZQUM3RCx3QkFBQyxVQUFELFlBQVEsVUFBZTs7Ozs7WUFBQztZQUFrRCx3QkFBQyxVQUFELFlBQVEsOEJBQW1DOzs7OztZQUFDO1dBQy9IOzs7OztrQkFDQTs7OztrQkFDRjs7Ozs7O1FBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUlOLGNBQWMsYUFDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxZQUFEO1VBQVksTUFBTTtVQUFJLFdBQVU7U0FBb0I7Ozs7bUJBQ3BELHdCQUFDLFFBQUQsWUFBTSx3Q0FBMkM7Ozs7aUJBQy9DOzs7OztrQkFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNFLHdCQUFDLE1BQUQ7V0FBSTtXQUNJLHdCQUFDLFVBQUQsWUFBUSxnQkFBcUI7Ozs7O1dBQUM7VUFDbEM7Ozs7O1VBQ0osd0JBQUMsTUFBRCxZQUFJLGlGQUVBOzs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSTtXQUM4RCx3QkFBQyxVQUFELFlBQVEsV0FBZ0I7Ozs7O1dBQUM7VUFDdkY7Ozs7O1VBQ0osd0JBQUMsTUFBRCxhQUNFLHdCQUFDLFVBQUQsWUFBUSw2QkFBZ0M7Ozs7b0JBQUMseUNBQ3ZDOzs7OztVQUNKLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxVQUFELFlBQVEseUJBQThCOzs7O29CQUFDLGdFQUNyQzs7Ozs7U0FDRjs7Ozs7Z0JBQ0Q7Ozs7O2lCQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxhQUFEO1VBQWEsTUFBTTtVQUFJLFdBQVU7U0FBb0I7Ozs7bUJBQ3JELHdCQUFDLFFBQUQsWUFBTSx1Q0FBMEM7Ozs7aUJBQzlDOzs7OztrQkFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZDtVQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFkLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW1EO1dBQTJCOzs7O3FCQUM5Rix3QkFBQyxRQUFELFlBQU0sK0RBQWtFOzs7O21CQUN0RTs7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUQ7V0FBd0M7Ozs7cUJBQzNHLHdCQUFDLFFBQUQsWUFBTSw2REFBZ0U7Ozs7bUJBQ3BFOzs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBZCxDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFtRDtXQUE0Qjs7OztxQkFDL0Ysd0JBQUMsUUFBRCxZQUFNLGtDQUFxQzs7OzttQkFDekM7Ozs7OztVQUNKLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFkLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW1EO1dBQWdDOzs7O3FCQUNuRyx3QkFBQyxRQUFELFlBQU0saUdBQW9HOzs7O21CQUN4Rzs7Ozs7O1NBQ0Y7Ozs7O2dCQUNEOzs7OztlQUNGOzs7Ozs7TUFJTixjQUFjLFdBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRDtVQUFVLE1BQU07VUFBSSxXQUFVO1NBQW9COzs7O21CQUNsRCx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2lCQUNuQzs7Ozs7a0JBQ0wsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQ7VUFDRSx3QkFBQyxNQUFELGFBQUksd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OztvQkFBQyxnQ0FBa0M7Ozs7O1VBQ3RFLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O29CQUFDLHNDQUF3Qzs7Ozs7VUFDOUUsd0JBQUMsTUFBRDtXQUFJLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7Ozs7V0FBQztXQUFJLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7O1dBQUM7VUFBYTs7Ozs7VUFDM0Usd0JBQUMsTUFBRCxhQUFJLHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7b0JBQUMsOEJBQWdDOzs7OztVQUNoRix3QkFBQyxNQUFELGFBQUksd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztvQkFBQywwQkFBNEI7Ozs7O1NBQzFEOzs7OztnQkFDRDs7Ozs7aUJBRUwsd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxVQUFVO1FBQ1YsV0FBVTtrQkFIWixDQUtFLHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7a0JBQzFCLHdCQUFDLFFBQUQsWUFDRyxtQkFDRyxrQ0FDQSxzQ0FDQTs7OztnQkFDQTs7Ozs7ZUFDTDs7Ozs7O0tBRUo7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFVBQVU7TUFDVixXQUFVO2dCQUhaLENBS0Usd0JBQUMsVUFBRCxFQUFVLE1BQU0sR0FBSzs7OztnQkFDckIsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OztjQUNuQjs7Ozs7ZUFFUix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQW5kcm9pZEFwa01vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgWCwgXG4gIFNtYXJ0cGhvbmUsIFxuICBEb3dubG9hZCwgXG4gIENvcHksIFxuICBDaGVjaywgXG4gIFNoaWVsZENoZWNrLCBcbiAgTGFwdG9wLCBcbiAgQ2xvdWQsIFxuICBUZXJtaW5hbCwgXG4gIEFsZXJ0Q2lyY2xlLFxuICBGaWxlQ29kZSxcbiAgRm9sZGVyQXJjaGl2ZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgZG93bmxvYWRBbmRyb2lkUHJvamVjdFppcCB9IGZyb20gJy4uL3NlcnZpY2VzL2FuZHJvaWRFeHBvcnRTZXJ2aWNlJztcblxuaW50ZXJmYWNlIEFuZHJvaWRBcGtNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgQW5kcm9pZEFwa01vZGFsOiBSZWFjdC5GQzxBbmRyb2lkQXBrTW9kYWxQcm9wcz4gPSAoeyBpc09wZW4sIG9uQ2xvc2UgfSkgPT4ge1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J3N0ZXBzJyB8ICdjbG91ZCcgfCAnaW5zdGFsbCcgfCAnZmlsZXMnPignc3RlcHMnKTtcbiAgY29uc3QgW2NvcGllZFRleHQsIHNldENvcGllZFRleHRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc0Rvd25sb2FkaW5nWmlwLCBzZXRJc0Rvd25sb2FkaW5nWmlwXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgaGFuZGxlQ29weSA9ICh0ZXh0OiBzdHJpbmcsIGlkOiBzdHJpbmcpID0+IHtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KTtcbiAgICBzZXRDb3BpZWRUZXh0KGlkKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZFRleHQobnVsbCksIDI1MDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBzZXRJc0Rvd25sb2FkaW5nWmlwKHRydWUpO1xuICAgICAgYXdhaXQgZG93bmxvYWRBbmRyb2lkUHJvamVjdFppcCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1pJUCBkb3dubG9hZCBlcnJvcjonLCBlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNEb3dubG9hZGluZ1ppcChmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC0zIHNtOnAtNCBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXhzIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgPGRpdiBcbiAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIG1heC13LWxnIGJnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIHJvdW5kZWQtM3hsIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtODAwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIG1heC1oLVs5MHZoXVwiXG4gICAgICAgIG9uQ2xpY2s9eyhlKSA9PiBlLnN0b3BQcm9wYWdhdGlvbigpfVxuICAgICAgPlxuICAgICAgICB7LyogTW9kYWwgSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzbTpwLTUgYm9yZGVyLWIgYm9yZGVyLXN0b25lLTEwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLXN0b25lLTUwLzcwIGRhcms6Ymctc3RvbmUtODAwLzQwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC0yeGwgYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTk1MC83MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8U21hcnRwaG9uZSBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJsYWNrIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgICAgICBBUEsg4KSs4KSo4KS+4KSo4KWHIOCklOCksCDgpKHgpL7gpIngpKjgpLLgpYvgpKEg4KSV4KSw4KSo4KWHIOCkleCkviDgpKTgpLDgpYDgpJXgpL5cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAgICAgICAgQW5kcm9pZCDgpKHgpL/gpLXgpL7gpIfgpLgg4KSV4KWHIOCksuCkv+CkjyDgpLjgpILgpKrgpYLgpLDgpY3gpKMg4KSX4KS+4KSH4KShXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc3RvbmUtNDAwIGhvdmVyOnRleHQtc3RvbmUtNzAwIGRhcms6aG92ZXI6dGV4dC1zdG9uZS0yMDAgaG92ZXI6Ymctc3RvbmUtMjAwIGRhcms6aG92ZXI6Ymctc3RvbmUtNzAwIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIHNpemU9ezE4fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGFiIFN3aXRjaGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYm9yZGVyLWIgYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgYmctc3RvbmUtNTAgZGFyazpiZy1zdG9uZS04NTAgcHgtMyBwdC0yIGdhcC0xIG92ZXJmbG93LXgtYXV0byBzY3JvbGxiYXItbm9uZVwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignc3RlcHMnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXQteGwgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdzdGVwcydcbiAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXItdC0yIGJvcmRlci1lbWVyYWxkLTYwMCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGhvdmVyOnRleHQtc3RvbmUtODAwIGRhcms6aG92ZXI6dGV4dC1zdG9uZS0yMDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDgpacuIOCkleCkguCkquCljeCkr+ClguCkn+CksCDgpK7gpYfgpIIg4KSs4KSo4KS+4KSP4KSCXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdjbG91ZCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0yIHRleHQteHMgZm9udC1ib2xkIHJvdW5kZWQtdC14bCB0cmFuc2l0aW9uIHdoaXRlc3BhY2Utbm93cmFwIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2Nsb3VkJ1xuICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlci10LTIgYm9yZGVyLWVtZXJhbGQtNjAwJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1zdG9uZS04MDAgZGFyazpob3Zlcjp0ZXh0LXN0b25lLTIwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOClqC4g4KSu4KWB4KSr4KWN4KSkIOCkleCljeCksuCkvuCkieCkoSDgpKzgpL/gpLLgpY3gpKEgKEdpdEh1YilcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2luc3RhbGwnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXQteGwgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdpbnN0YWxsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlci10LTIgYm9yZGVyLWVtZXJhbGQtNjAwJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC1zdG9uZS04MDAgZGFyazpob3Zlcjp0ZXh0LXN0b25lLTIwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOClqS4g4KSr4KWL4KSoIOCkruClh+CkgiDgpIfgpKjgpLjgpY3gpJ/gpYngpLIg4KSV4KWI4KS44KWHIOCkleCksOClh+CkglxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignZmlsZXMnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXQteGwgdHJhbnNpdGlvbiB3aGl0ZXNwYWNlLW5vd3JhcCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdmaWxlcydcbiAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBib3JkZXItdC0yIGJvcmRlci1lbWVyYWxkLTYwMCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGhvdmVyOnRleHQtc3RvbmUtODAwIGRhcms6aG92ZXI6dGV4dC1zdG9uZS0yMDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDgpaouIOCkquCljeCksOCli+CknOClh+CkleCljeCknyDgpKvgpL7gpIfgpLLgpY3gpLhcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRhYiBDb250ZW50ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzbTpwLTUgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNCB0ZXh0LXhzIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDBcIj5cbiAgICAgICAgICB7LyogVEFCIDE6IFNURVBTIE9OIFBDICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdzdGVwcycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAgZGFyazpib3JkZXItZW1lcmFsZC04MDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1zdGFydCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgPExhcHRvcCBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgIOCkr+CkpuCkvyDgpIbgpKrgpJXgpYcg4KSq4KS+4KS4IOCksuCliOCkquCkn+ClieCkqiDgpK/gpL4g4KSh4KWH4KS44KWN4KSV4KSf4KWJ4KSqIOCkueCliCwg4KSk4KWLIOCkhuCkqiA8c3Ryb25nPkFuZHJvaWQgU3R1ZGlvPC9zdHJvbmc+IOCkleClhyDgpK7gpL7gpKfgpY3gpK/gpK4g4KS44KWHIOCkrOCkueClgeCkpCDgpIbgpLjgpL7gpKjgpYAg4KS44KWHIOCkteCkvuCkuOCljeCkpOCkteCkv+CklSDgpKHgpYDgpKzgpJcgQVBLIOCkpOCliOCkr+CkvuCksCDgpJXgpLAg4KS44KSV4KSk4KWHIOCkueCliOCkguClpFxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFN0ZXAgMSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgcm91bmRlZC0yeGwgcC0zLjUgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIOCkuOClieCkq+CljeCkn+CkteClh+Ckr+CksCDgpIbgpLXgpLbgpY3gpK/gpJXgpKTgpL7gpI/gpIJcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTQwMCBsZWFkaW5nLXJlbGF4ZWQgcGwtN1wiPlxuICAgICAgICAgICAgICAgICAg4KSV4KSC4KSq4KWN4KSv4KWC4KSf4KSwIOCkruClh+CkgiA8c3Ryb25nPkphdmEgSkRLIDE3IOCkr+CkviAyMTwvc3Ryb25nPiDgpJTgpLAgPHN0cm9uZz5BbmRyb2lkIFN0dWRpbzwvc3Ryb25nPiAoTGFkeWJ1ZyDgpK/gpL4gSGVkZ2Vob2cpIOCkh+CkqOCkuOCljeCkn+ClieCksiDgpLngpYvgpKjgpL4g4KSa4KS+4KS54KS/4KSP4KWkXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU3RlcCAyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCByb3VuZGVkLTJ4bCBwLTMuNSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LVsxMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAg4KSq4KWN4KSw4KWL4KSc4KWH4KSV4KWN4KSfIOCkpOCliOCkr+CkvuCksCDgpJXgpLDgpKjgpL5cbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTQwMCBsZWFkaW5nLXJlbGF4ZWQgcGwtN1wiPlxuICAgICAgICAgICAgICAgICAg4KSo4KWA4KSa4KWHIOCkpuCkv+CkjyDgpJfgpI8g4KSs4KSf4KSoIOCkuOClhyDgpKrgpY3gpLDgpYvgpJzgpYfgpJXgpY3gpJ8g4KSc4KS84KS/4KSqIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpJXgpLDgpYfgpIIg4KSU4KSwIOCkj+CkleCljeCkuOCkn+CljeCksOClh+CkleCljeCknyDgpJXgpLDgpYfgpILgpaQg4KSr4KS/4KSwIOCkn+CksOCljeCkruCkv+CkqOCksiDgpK7gpYfgpIIg4KSv4KS5IOCkleCkruCkvuCkguCkoSDgpJrgpLLgpL7gpI/gpII6XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtNyBwLTIuNSByb3VuZGVkLXhsIGJnLXN0b25lLTkwMCB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxjb2RlPm5wbSBydW4gYnVpbGQgJiYgbnB4IGNhcCBzeW5jIGFuZHJvaWQ8L2NvZGU+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNvcHkoJ25wbSBydW4gYnVpbGQgJiYgbnB4IGNhcCBzeW5jIGFuZHJvaWQnLCAnY21kMScpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCLgpJXgpYngpKrgpYAg4KSV4KSw4KWH4KSCXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2NvcGllZFRleHQgPT09ICdjbWQxJyA/IDxDaGVjayBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENvcHkgc2l6ZT17MTR9IC8+fVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBTdGVwIDMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtODAwIHJvdW5kZWQtMnhsIHAtMy41IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtWzEwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIDNcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICBBUEsg4KSs4KS/4KSy4KWN4KShIOCkleCkruCkvuCkguCkoVxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGxlYWRpbmctcmVsYXhlZCBwbC03XCI+XG4gICAgICAgICAgICAgICAgICDgpJ/gpLDgpY3gpK7gpL/gpKjgpLIg4KSu4KWH4KSCIDxjb2RlPmFuZHJvaWQ8L2NvZGU+IOCkq+Cli+CksuCljeCkoeCksCDgpK7gpYfgpIIg4KSc4KS+4KSV4KSwIOCkr+CkuSDgpJXgpK7gpL7gpILgpKEg4KSm4KWH4KSCOlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTcgcC0yLjUgcm91bmRlZC14bCBiZy1zdG9uZS05MDAgdGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm8gdGV4dC1bMTFweF0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8Y29kZT4uL2dyYWRsZXcgYXNzZW1ibGVEZWJ1ZzwvY29kZT5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29weSgnLi9ncmFkbGV3IGFzc2VtYmxlRGVidWcnLCAnY21kMicpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zdG9uZS00MDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCLgpJXgpYngpKrgpYAg4KSV4KSw4KWH4KSCXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2NvcGllZFRleHQgPT09ICdjbWQyJyA/IDxDaGVjayBzaXplPXsxNH0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENvcHkgc2l6ZT17MTR9IC8+fVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgcGwtN1wiPlxuICAgICAgICAgICAgICAgICAg4KSv4KS+IEFuZHJvaWQgU3R1ZGlvIOCkruClh+CkgiDgpIrgpKrgpLAg4KSu4KWH4KSo4KWCIOCkuOClhzogPHN0cm9uZz5CdWlsZCDihpIgQnVpbGQgQnVuZGxlKHMpIC8gQVBLKHMpIOKGkiBCdWlsZCBBUEsocyk8L3N0cm9uZz4g4KSq4KSwIOCkleCljeCksuCkv+CklSDgpJXgpLDgpYfgpILgpaRcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBTdGVwIDQgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtODAwIHJvdW5kZWQtMnhsIHAtMy41IHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy01IGgtNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgNFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIEFQSyDgpKvgpLzgpL7gpIfgpLIg4KSV4KS+IOCkuOCljeCkpeCkvuCkqFxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGxlYWRpbmctcmVsYXhlZCBwbC03XCI+XG4gICAgICAgICAgICAgICAgICDgpKTgpYjgpK/gpL7gpLAgQVBLIOCkh+CkuCDgpKrgpL7gpKUg4KSq4KSwIOCkruCkv+CksuClh+Ckl+ClgDpcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC03IHAtMiByb3VuZGVkLXhsIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCBmb250LW1vbm8gdGV4dC1bMTFweF0gdGV4dC1zdG9uZS04MDAgZGFyazp0ZXh0LXN0b25lLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgYW5kcm9pZC9hcHAvYnVpbGQvb3V0cHV0cy9hcGsvZGVidWcvYXBwLWRlYnVnLmFwa1xuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDI6IENMT1VEIEJVSUxEIChHSVRIVUIgQUNUSU9OUykgKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2Nsb3VkJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1pbmRpZ28tNTAgZGFyazpiZy1pbmRpZ28tOTUwLzQwIGJvcmRlciBib3JkZXItaW5kaWdvLTIwMCBkYXJrOmJvcmRlci1pbmRpZ28tODAwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNVwiPlxuICAgICAgICAgICAgICAgIDxDbG91ZCBzaXplPXsxOH0gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNjAwIGRhcms6dGV4dC1pbmRpZ28tNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPuCkleCkguCkquCljeCkr+ClguCkn+CksCDgpKjgpLngpYDgpIIg4KS54KWIPyDgpJXgpYvgpIgg4KSs4KS+4KSkIOCkqOCkueClgOCkgiE8L3N0cm9uZz4gR2l0SHViIEFjdGlvbnMg4KSV4KWAIOCkruCkpuCkpiDgpLjgpYcg4KSG4KSqIOCkrOCkv+CkqOCkviDgpJXgpILgpKrgpY3gpK/gpYLgpJ/gpLAg4KSV4KWHIOCkleCljeCksuCkvuCkieCkoSDgpK7gpYfgpIIg4KS44KWA4KSn4KWHIEFQSyDgpKvgpL7gpIfgpLIg4KSc4KSo4KSw4KWH4KSfIOCklOCksCDgpKHgpL7gpIngpKjgpLLgpYvgpKEg4KSV4KSwIOCkuOCkleCkpOClhyDgpLngpYjgpILgpaRcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTUgaC01IHJvdW5kZWQtZnVsbCBiZy1pbmRpZ28tNjAwIHRleHQtd2hpdGUgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtWzEwcHhdIHNocmluay0wIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAxXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBHaXRIdWIg4KSq4KSwIOCkleCli+CkoSDgpIXgpKrgpLLgpYvgpKEg4KSV4KSw4KWH4KSCXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgbGVhZGluZy1yZWxheGVkIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIEdpdEh1Yi5jb20g4KSq4KSwIOCkj+CklSDgpKjgpIgg4KSw4KS/4KSq4KWJ4KSc4KS/4KSf4KSw4KWAIOCkrOCkqOCkvuCkj+CkgiDgpJTgpLAg4KSH4KS4IOCkquCljeCksOCli+CknOClh+CkleCljeCknyDgpJXgpYcg4KSr4KS+4KSH4KSy4KWN4KS4IOCkheCkquCksuCli+CkoSDgpJXgpLDgpYfgpILgpaRcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGJnLWluZGlnby02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTBweF0gc2hyaW5rLTAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIDJcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIOCkuOCljeCkteCkmuCkvuCksuCkv+CkpCDgpLXgpLDgpY3gpJXgpKvgpLzgpY3gpLLgpYsg4KSr4KS84KS+4KSH4KSyXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgbGVhZGluZy1yZWxheGVkIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIOCkueCkruCkvuCksOClhyDgpKrgpY3gpLDgpYvgpJzgpYfgpJXgpY3gpJ8g4KSq4KWI4KSV4KWH4KScIOCkruClh+CkgiA8Y29kZT4uZ2l0aHViL3dvcmtmbG93cy9idWlsZC1hcGsueW1sPC9jb2RlPiDgpKrgpLngpLLgpYcg4KS44KWHIOCkruCljOCknOClguCkpiDgpLngpYjgpaRcbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctNSBoLTUgcm91bmRlZC1mdWxsIGJnLWluZGlnby02MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1bMTBweF0gc2hyaW5rLTAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgIDNcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIEFQSyDgpKHgpL7gpIngpKjgpLLgpYvgpKEg4KSy4KS/4KSC4KSVXG4gICAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgbGVhZGluZy1yZWxheGVkIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIEdpdEh1YiDgpJXgpYcgPHN0cm9uZz5BY3Rpb25zPC9zdHJvbmc+IOCkn+CliOCkrCDgpK7gpYfgpIIg4KSc4KS+4KSP4KSC4KWkIDItMyDgpK7gpL/gpKjgpJ8g4KSu4KWH4KSCIOCkrOCkv+CksuCljeCkoSDgpLjgpKvgpLIg4KS54KWL4KSo4KWHIOCkleClhyDgpKzgpL7gpKYgPHN0cm9uZz5EYWlseUhhYml0cy1IaW5kaS1EZWJ1Zy1BUEs8L3N0cm9uZz4g4KSq4KSwIOCkleCljeCksuCkv+CklSDgpJXgpLDgpJXgpYcg4KSh4KS+4KSJ4KSo4KSy4KWL4KShIOCkleCksOClh+CkguClpFxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFRBQiAzOiBJTlNUQUxMICYgUEVSTUlTU0lPTlMgKi99XG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2luc3RhbGwnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtODAwIHJvdW5kZWQtMnhsIHAtMy41IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICA8U21hcnRwaG9uZSBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj7gpI/gpILgpKHgpY3gpLDgpYngpIfgpKEg4KSr4KWL4KSoIOCkruClh+CkgiDgpIfgpKjgpLjgpY3gpJ/gpYngpLIg4KSV4KSw4KSo4KWHIOCkleClhyDgpJrgpLDgpKM6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPG9sIGNsYXNzTmFtZT1cImxpc3QtZGVjaW1hbCBwbC01IHNwYWNlLXktMS41IHRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAg4KSk4KWI4KSv4KS+4KSwIDxzdHJvbmc+YXBwLWRlYnVnLmFwazwvc3Ryb25nPiDgpKvgpLzgpL7gpIfgpLIg4KSV4KWLIFdoYXRzQXBwLCBHb29nbGUgRHJpdmUg4KSv4KS+IFVTQiDgpKbgpY3gpLXgpL7gpLDgpL4g4KSF4KSq4KSo4KWHIOCkq+Cli+CkqCDgpK7gpYfgpIIg4KSt4KWH4KSc4KWH4KSC4KWkXG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPlxuICAgICAgICAgICAgICAgICAgICDgpKvgpYvgpKgg4KSV4KWHIOCkq+CkvOCkvuCkh+CksiDgpK7gpYjgpKjgpYfgpJzgpLAgKEZpbGVzKSDgpK7gpYfgpIIg4KSh4KS+4KSJ4KSo4KSy4KWL4KShIOCkq+Cli+CksuCljeCkoeCksCDgpJbgpYvgpLLgpYfgpIIg4KSU4KSwIEFQSyDgpKvgpLzgpL7gpIfgpLIg4KSq4KSwIOCkn+CliOCkqiDgpJXgpLDgpYfgpILgpaRcbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgIOCkr+CkpuCkvyDgpKvgpYvgpKgg4KSa4KWH4KSk4KS+4KS14KSo4KWAIOCkpuClhyDgpJXgpL8g4KS44KWB4KSw4KSV4KWN4KS34KS+IOCkleClhyDgpJXgpL7gpLDgpKMg4KSF4KSc4KWN4KSe4KS+4KSkIOCkkOCkquCljeCkuCDgpKzgpY3gpLLgpYngpJUg4KS54KWI4KSCLCDgpKTgpYsgPHN0cm9uZz5TZXR0aW5nczwvc3Ryb25nPiDgpKrgpLAg4KSf4KWI4KSqIOCkleCksOClh+CkguClpFxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5cIkFsbG93IGZyb20gdGhpcyBzb3VyY2VcIjwvc3Ryb25nPiAo4KSH4KS4IOCkuOCljeCksOCli+CkpCDgpLjgpYcg4KSF4KSo4KWB4KSu4KSk4KS/IOCkpuClh+Ckgikg4KSV4KWLIOCkmuCkvuCksuClgiDgpJXgpLDgpYfgpILgpaRcbiAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+SW5zdGFsbCAo4KSH4KSo4KS44KWN4KSf4KWJ4KSyIOCkleCksOClh+Ckgik8L3N0cm9uZz4g4KSs4KSf4KSoIOCkpuCkrOCkvuCkj+CkguClpCDgpJXgpYHgpJsg4KS54KWAIOCkuOClh+CkleCkguCkoSDgpK7gpYfgpIIg4KSQ4KSqIOCkhuCkquCkleClhyDgpKvgpYvgpKgg4KSu4KWH4KSCIOCkh+CkqOCkuOCljeCkn+ClieCksiDgpLngpYsg4KSc4KS+4KSP4KSX4KS+IVxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICA8L29sPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2FmZXR5ICYgUGVybWlzc2lvbnMgVHJhbnNwYXJlbmN5ICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCByb3VuZGVkLTJ4bCBwLTMuNSBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPFNoaWVsZENoZWNrIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPuCkuOClgeCksOCkleCljeCkt+CkviDgpI/gpLXgpIIg4KSF4KSo4KWB4KSu4KSk4KS/4KSv4KS+4KSCIChQZXJtaXNzaW9ucyk6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDBcIj7igKIg4KSH4KSC4KSf4KSw4KSo4KWH4KSfIChJTlRFUk5FVCk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7gpJXgpYfgpLXgpLIg4KSv4KSm4KS/IOCkhuCkqiDgpKrgpY3gpLDgpYfgpLDgpKPgpL7gpKbgpL7gpK/gpJUg4KS14KS/4KSa4KS+4KSwIOCkr+CkviDgpJHgpKjgpLLgpL7gpIfgpKgg4KSs4KWI4KSV4KSF4KSqIOCkuOCkv+CkguCklSDgpJXgpLDgpKTgpYcg4KS54KWI4KSC4KWkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPuKAoiDgpKjgpYvgpJ/gpL/gpKvgpL/gpJXgpYfgpLbgpKggKFBPU1RfTk9USUZJQ0FUSU9OUyk6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7gpIbgpKrgpJXgpYAg4KSo4KS/4KSw4KWN4KSn4KS+4KSw4KS/4KSkIOCkhuCkpuCkpOCli+CkgiDgpJXgpYcg4KSm4KWI4KSo4KS/4KSVIOCksOCkv+CkruCkvuCkh+CkguCkoeCksCDgpLjgpK7gpK8g4KSq4KSwIOCkrOCknOCkqOClhyDgpJXgpYcg4KSy4KS/4KSP4KWkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMFwiPuKAoiDgpLXgpL7gpIfgpKzgpY3gpLDgpYfgpLbgpKggKFZJQlJBVEUpOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4KSw4KS/4KSu4KS+4KSH4KSC4KSh4KSwIOCkheCksuCkvuCksOCljeCkriDgpKrgpLAg4KSV4KSC4KSq4KSoIOCkleClhyDgpLLgpL/gpI/gpaQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+4oCiIOCkl+Cli+CkquCkqOClgOCkr+CkpOCkviAoMTAwJSBQcml2YWN5KTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPuCkleCli+CkiCDgpLXgpY3gpK/gpJXgpY3gpKTgpL/gpJfgpKQg4KSh4KWH4KSf4KS+IOCkleCkv+CkuOClgCDgpKTgpYDgpLjgpLDgpYcg4KSq4KSV4KWN4KS3IOCkleCliyDgpKjgpLngpYDgpIIg4KSt4KWH4KSc4KS+IOCknOCkvuCkpOCkvuClpCDgpLjgpKwg4KSV4KWB4KSbIOCkhuCkquCkleClhyDgpKHgpL/gpLXgpL7gpIfgpLgg4KSu4KWH4KSCIOCkuOClgeCksOCkleCljeCkt+Ckv+CkpCDgpLDgpLngpKTgpL4g4KS54KWI4KWkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDQ6IFBST0pFQ1QgRklMRVMgWklQICovfVxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdmaWxlcycgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSBiZy1zdG9uZS01MCBkYXJrOmJnLXN0b25lLTgwMC82MCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgcm91bmRlZC0yeGwgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgPEZpbGVDb2RlIHNpemU9ezE2fSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPuCktuCkvuCkruCkv+CksiDgpJXgpYngpKjgpY3gpKvgpLzgpL/gpJfgpLDgpYfgpLbgpKgg4KSr4KS+4KSH4KSy4KWN4KS4Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8dWwgY2xhc3NOYW1lPVwic3BhY2UteS0xIHRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS00MDAgcGwtNCBsaXN0LWRpc2MgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgIDxsaT48Y29kZT5BbmRyb2lkTWFuaWZlc3QueG1sPC9jb2RlPiAo4KS44KSt4KWAIOCkhuCkteCktuCljeCkr+CklSDgpIXgpKjgpYHgpK7gpKTgpL/gpK/gpYvgpIIg4KSV4KWHIOCkuOCkvuCkpSk8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPjxjb2RlPmNhcGFjaXRvci5jb25maWcuanNvbjwvY29kZT4gKOCkquCliOCkleClh+CknCDgpIbgpIjgpKHgpYA6IGNvbS5kYWlseWhhYml0cy5oaW5kaSk8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPjxjb2RlPmJ1aWxkLmdyYWRsZTwvY29kZT4g4KSU4KSwIDxjb2RlPnZhcmlhYmxlcy5ncmFkbGU8L2NvZGU+IChTREsgMzQpPC9saT5cbiAgICAgICAgICAgICAgICAgIDxsaT48Y29kZT4uZ2l0aHViL3dvcmtmbG93cy9idWlsZC1hcGsueW1sPC9jb2RlPiAo4KSu4KWB4KSr4KWN4KSkIOCkleCljeCksuCkvuCkieCkoSDgpKzgpL/gpLLgpY3gpKEg4KSV4KWHIOCksuCkv+Ckjyk8L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPjxjb2RlPlJFQURNRS1ISU5ESS5tZDwvY29kZT4gKOCkuOCkguCkquClguCksOCljeCkoyDgpLngpL/gpILgpKbgpYAg4KSX4KS+4KSH4KSh4KSs4KWB4KSVKTwvbGk+XG4gICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkWmlwfVxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0Rvd25sb2FkaW5nWmlwfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIHB4LTQgcm91bmRlZC0yeGwgYmctZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC04MDAgZGlzYWJsZWQ6b3BhY2l0eS01MCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Rm9sZGVyQXJjaGl2ZSBzaXplPXsxNn0gLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpc0Rvd25sb2FkaW5nWmlwXG4gICAgICAgICAgICAgICAgICAgID8gJ+CknOCkvOCkv+CkqiDgpKvgpLzgpL7gpIfgpLIg4KSk4KWI4KSv4KS+4KSwIOCkueCliyDgpLDgpLngpYAg4KS54KWILi4uJ1xuICAgICAgICAgICAgICAgICAgICA6ICfgpKrgpY3gpLDgpYvgpJzgpYfgpJXgpY3gpJ8g4KSr4KS+4KSH4KSy4KWN4KS4IChaSVApIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpJXgpLDgpYfgpIInfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTW9kYWwgRm9vdGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBzbTpwLTQgYm9yZGVyLXQgYm9yZGVyLXN0b25lLTEwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgYmctc3RvbmUtNTAvNzAgZGFyazpiZy1zdG9uZS04MDAvNDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRaaXB9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNEb3dubG9hZGluZ1ppcH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTIgcHgtMyByb3VuZGVkLXhsIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCBob3ZlcjpiZy1zdG9uZS0yMDAgZGFyazpob3ZlcjpiZy1zdG9uZS03MDAgdGV4dC1zdG9uZS04MDAgZGFyazp0ZXh0LXN0b25lLTIwMCBmb250LWJvbGQgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBzaXplPXsxNH0gLz5cbiAgICAgICAgICAgIDxzcGFuPuCkquCljeCksOCli+CknOClh+CkleCljeCknyBaSVA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMiBweC00IHJvdW5kZWQteGwgYmctc3RvbmUtODAwIGhvdmVyOmJnLXN0b25lLTkwMCBkYXJrOmJnLXN0b25lLTcwMCBkYXJrOmhvdmVyOmJnLXN0b25lLTYwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOCkrOCkguCkpiDgpJXgpLDgpYfgpIJcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=