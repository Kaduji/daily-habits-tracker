const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Droplets, BookOpen, Activity, Sunrise, Heart, Dumbbell, Sparkles, Sun, Moon, Footprints, Apple, Wallet, PenTool, GraduationCap, Music, CheckCircle2, Clock } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
var _jsxFileName = "/app/applet/src/components/HabitIcon.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const AVAILABLE_ICONS = [
	{
		id: "Droplet",
		label: "पानी",
		icon: Droplets
	},
	{
		id: "BookOpen",
		label: "किताब / पढ़ाई",
		icon: BookOpen
	},
	{
		id: "Activity",
		label: "व्यायाम / फिटनेस",
		icon: Activity
	},
	{
		id: "Sunrise",
		label: "सुबह / उठना",
		icon: Sunrise
	},
	{
		id: "Heart",
		label: "ध्यान / दिल",
		icon: Heart
	},
	{
		id: "Dumbbell",
		label: "जिम / कसरत",
		icon: Dumbbell
	},
	{
		id: "Sparkles",
		label: "प्रेरणा / चमक",
		icon: Sparkles
	},
	{
		id: "Sun",
		label: "धूप / दिनचर्या",
		icon: Sun
	},
	{
		id: "Moon",
		label: "नींद / विश्राम",
		icon: Moon
	},
	{
		id: "Footprints",
		label: "टहलना / कदम",
		icon: Footprints
	},
	{
		id: "Apple",
		label: "स्वस्थ भोजन",
		icon: Apple
	},
	{
		id: "Wallet",
		label: "बचत / वित्त",
		icon: Wallet
	},
	{
		id: "PenTool",
		label: "डायरी / लेखन",
		icon: PenTool
	},
	{
		id: "GraduationCap",
		label: "सीखना",
		icon: GraduationCap
	},
	{
		id: "Music",
		label: "संगीत / शौक",
		icon: Music
	},
	{
		id: "Clock",
		label: "समय प्रबंधन",
		icon: Clock
	}
];
export const HABIT_COLORS = [
	{
		id: "emerald",
		name: "गहरा हरा",
		bg: "bg-emerald-500/15",
		text: "text-emerald-700 dark:text-emerald-400",
		border: "border-emerald-500/30",
		accent: "bg-emerald-600"
	},
	{
		id: "sky",
		name: "आसमानी",
		bg: "bg-sky-500/15",
		text: "text-sky-700 dark:text-sky-400",
		border: "border-sky-500/30",
		accent: "bg-sky-600"
	},
	{
		id: "amber",
		name: "सुनहरा",
		bg: "bg-amber-500/15",
		text: "text-amber-700 dark:text-amber-400",
		border: "border-amber-500/30",
		accent: "bg-amber-600"
	},
	{
		id: "rose",
		name: "गुलाबी",
		bg: "bg-rose-500/15",
		text: "text-rose-700 dark:text-rose-400",
		border: "border-rose-500/30",
		accent: "bg-rose-600"
	},
	{
		id: "purple",
		name: "बैंगनी",
		bg: "bg-purple-500/15",
		text: "text-purple-700 dark:text-purple-400",
		border: "border-purple-500/30",
		accent: "bg-purple-600"
	},
	{
		id: "orange",
		name: "नारंगी",
		bg: "bg-orange-500/15",
		text: "text-orange-700 dark:text-orange-400",
		border: "border-orange-500/30",
		accent: "bg-orange-600"
	},
	{
		id: "teal",
		name: "टील",
		bg: "bg-teal-500/15",
		text: "text-teal-700 dark:text-teal-400",
		border: "border-teal-500/30",
		accent: "bg-teal-600"
	}
];
export function getColorScheme(colorId) {
	return HABIT_COLORS.find((c) => c.id === colorId) || HABIT_COLORS[0];
}
export const HabitIcon = ({ name, className = "", size = 20 }) => {
	switch (name) {
		case "Droplet": return /* @__PURE__ */ _jsxDEV(Droplets, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 14
		}, this);
		case "BookOpen": return /* @__PURE__ */ _jsxDEV(BookOpen, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 14
		}, this);
		case "Activity": return /* @__PURE__ */ _jsxDEV(Activity, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 14
		}, this);
		case "Sunrise": return /* @__PURE__ */ _jsxDEV(Sunrise, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 14
		}, this);
		case "Heart": return /* @__PURE__ */ _jsxDEV(Heart, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 14
		}, this);
		case "Dumbbell": return /* @__PURE__ */ _jsxDEV(Dumbbell, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 14
		}, this);
		case "Sparkles": return /* @__PURE__ */ _jsxDEV(Sparkles, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 14
		}, this);
		case "Sun": return /* @__PURE__ */ _jsxDEV(Sun, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 14
		}, this);
		case "Moon": return /* @__PURE__ */ _jsxDEV(Moon, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 14
		}, this);
		case "Footprints": return /* @__PURE__ */ _jsxDEV(Footprints, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 14
		}, this);
		case "Apple": return /* @__PURE__ */ _jsxDEV(Apple, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 14
		}, this);
		case "Wallet": return /* @__PURE__ */ _jsxDEV(Wallet, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 14
		}, this);
		case "PenTool": return /* @__PURE__ */ _jsxDEV(PenTool, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 14
		}, this);
		case "GraduationCap": return /* @__PURE__ */ _jsxDEV(GraduationCap, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 14
		}, this);
		case "Music": return /* @__PURE__ */ _jsxDEV(Music, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 14
		}, this);
		case "Clock": return /* @__PURE__ */ _jsxDEV(Clock, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 14
		}, this);
		default: return /* @__PURE__ */ _jsxDEV(CheckCircle2, {
			size,
			className
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 14
		}, this);
	}
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsVUFDQSxVQUNBLFVBQ0EsU0FDQSxPQUNBLFVBQ0EsVUFDQSxLQUNBLE1BQ0EsWUFDQSxPQUNBLFFBQ0EsU0FDQSxlQUNBLE9BQ0EsY0FDQSxhQUVLOzs7QUFRUCxPQUFPLE1BQU0sa0JBQWtCO0NBQzdCO0VBQUUsSUFBSTtFQUFXLE9BQU87RUFBUSxNQUFNO0NBQVM7Q0FDL0M7RUFBRSxJQUFJO0VBQVksT0FBTztFQUFpQixNQUFNO0NBQVM7Q0FDekQ7RUFBRSxJQUFJO0VBQVksT0FBTztFQUFvQixNQUFNO0NBQVM7Q0FDNUQ7RUFBRSxJQUFJO0VBQVcsT0FBTztFQUFlLE1BQU07Q0FBUTtDQUNyRDtFQUFFLElBQUk7RUFBUyxPQUFPO0VBQWUsTUFBTTtDQUFNO0NBQ2pEO0VBQUUsSUFBSTtFQUFZLE9BQU87RUFBYyxNQUFNO0NBQVM7Q0FDdEQ7RUFBRSxJQUFJO0VBQVksT0FBTztFQUFpQixNQUFNO0NBQVM7Q0FDekQ7RUFBRSxJQUFJO0VBQU8sT0FBTztFQUFrQixNQUFNO0NBQUk7Q0FDaEQ7RUFBRSxJQUFJO0VBQVEsT0FBTztFQUFrQixNQUFNO0NBQUs7Q0FDbEQ7RUFBRSxJQUFJO0VBQWMsT0FBTztFQUFlLE1BQU07Q0FBVztDQUMzRDtFQUFFLElBQUk7RUFBUyxPQUFPO0VBQWUsTUFBTTtDQUFNO0NBQ2pEO0VBQUUsSUFBSTtFQUFVLE9BQU87RUFBZSxNQUFNO0NBQU87Q0FDbkQ7RUFBRSxJQUFJO0VBQVcsT0FBTztFQUFnQixNQUFNO0NBQVE7Q0FDdEQ7RUFBRSxJQUFJO0VBQWlCLE9BQU87RUFBUyxNQUFNO0NBQWM7Q0FDM0Q7RUFBRSxJQUFJO0VBQVMsT0FBTztFQUFlLE1BQU07Q0FBTTtDQUNqRDtFQUFFLElBQUk7RUFBUyxPQUFPO0VBQWUsTUFBTTtDQUFNO0FBQ25EO0FBRUEsT0FBTyxNQUFNLGVBQWU7Q0FDMUI7RUFBRSxJQUFJO0VBQVcsTUFBTTtFQUFZLElBQUk7RUFBcUIsTUFBTTtFQUEwQyxRQUFRO0VBQXlCLFFBQVE7Q0FBaUI7Q0FDdEs7RUFBRSxJQUFJO0VBQU8sTUFBTTtFQUFVLElBQUk7RUFBaUIsTUFBTTtFQUFrQyxRQUFRO0VBQXFCLFFBQVE7Q0FBYTtDQUM1STtFQUFFLElBQUk7RUFBUyxNQUFNO0VBQVUsSUFBSTtFQUFtQixNQUFNO0VBQXNDLFFBQVE7RUFBdUIsUUFBUTtDQUFlO0NBQ3hKO0VBQUUsSUFBSTtFQUFRLE1BQU07RUFBVSxJQUFJO0VBQWtCLE1BQU07RUFBb0MsUUFBUTtFQUFzQixRQUFRO0NBQWM7Q0FDbEo7RUFBRSxJQUFJO0VBQVUsTUFBTTtFQUFVLElBQUk7RUFBb0IsTUFBTTtFQUF3QyxRQUFRO0VBQXdCLFFBQVE7Q0FBZ0I7Q0FDOUo7RUFBRSxJQUFJO0VBQVUsTUFBTTtFQUFVLElBQUk7RUFBb0IsTUFBTTtFQUF3QyxRQUFRO0VBQXdCLFFBQVE7Q0FBZ0I7Q0FDOUo7RUFBRSxJQUFJO0VBQVEsTUFBTTtFQUFPLElBQUk7RUFBa0IsTUFBTTtFQUFvQyxRQUFRO0VBQXNCLFFBQVE7Q0FBYztBQUNqSjtBQUVBLE9BQU8sU0FBUyxlQUFlLFNBQWlCO0NBQzlDLE9BQU8sYUFBYSxNQUFNLE1BQU0sRUFBRSxPQUFPLE9BQU8sS0FBSyxhQUFhO0FBQ3BFO0FBRUEsT0FBTyxNQUFNLGFBQXVDLEVBQUUsTUFBTSxZQUFZLElBQUksT0FBTyxTQUFTO0NBQzFGLFFBQVEsTUFBUjtFQUNFLEtBQUssV0FDSCxPQUFPLHdCQUFDLFVBQUQ7R0FBZ0I7R0FBaUI7RUFBWTs7Ozs7RUFDdEQsS0FBSyxZQUNILE9BQU8sd0JBQUMsVUFBRDtHQUFnQjtHQUFpQjtFQUFZOzs7OztFQUN0RCxLQUFLLFlBQ0gsT0FBTyx3QkFBQyxVQUFEO0dBQWdCO0dBQWlCO0VBQVk7Ozs7O0VBQ3RELEtBQUssV0FDSCxPQUFPLHdCQUFDLFNBQUQ7R0FBZTtHQUFpQjtFQUFZOzs7OztFQUNyRCxLQUFLLFNBQ0gsT0FBTyx3QkFBQyxPQUFEO0dBQWE7R0FBaUI7RUFBWTs7Ozs7RUFDbkQsS0FBSyxZQUNILE9BQU8sd0JBQUMsVUFBRDtHQUFnQjtHQUFpQjtFQUFZOzs7OztFQUN0RCxLQUFLLFlBQ0gsT0FBTyx3QkFBQyxVQUFEO0dBQWdCO0dBQWlCO0VBQVk7Ozs7O0VBQ3RELEtBQUssT0FDSCxPQUFPLHdCQUFDLEtBQUQ7R0FBVztHQUFpQjtFQUFZOzs7OztFQUNqRCxLQUFLLFFBQ0gsT0FBTyx3QkFBQyxNQUFEO0dBQVk7R0FBaUI7RUFBWTs7Ozs7RUFDbEQsS0FBSyxjQUNILE9BQU8sd0JBQUMsWUFBRDtHQUFrQjtHQUFpQjtFQUFZOzs7OztFQUN4RCxLQUFLLFNBQ0gsT0FBTyx3QkFBQyxPQUFEO0dBQWE7R0FBaUI7RUFBWTs7Ozs7RUFDbkQsS0FBSyxVQUNILE9BQU8sd0JBQUMsUUFBRDtHQUFjO0dBQWlCO0VBQVk7Ozs7O0VBQ3BELEtBQUssV0FDSCxPQUFPLHdCQUFDLFNBQUQ7R0FBZTtHQUFpQjtFQUFZOzs7OztFQUNyRCxLQUFLLGlCQUNILE9BQU8sd0JBQUMsZUFBRDtHQUFxQjtHQUFpQjtFQUFZOzs7OztFQUMzRCxLQUFLLFNBQ0gsT0FBTyx3QkFBQyxPQUFEO0dBQWE7R0FBaUI7RUFBWTs7Ozs7RUFDbkQsS0FBSyxTQUNILE9BQU8sd0JBQUMsT0FBRDtHQUFhO0dBQWlCO0VBQVk7Ozs7O0VBQ25ELFNBQ0UsT0FBTyx3QkFBQyxjQUFEO0dBQW9CO0dBQWlCO0VBQVk7Ozs7O0NBQzVEO0FBQ0YiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGFiaXRJY29uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgRHJvcGxldHMsXG4gIEJvb2tPcGVuLFxuICBBY3Rpdml0eSxcbiAgU3VucmlzZSxcbiAgSGVhcnQsXG4gIER1bWJiZWxsLFxuICBTcGFya2xlcyxcbiAgU3VuLFxuICBNb29uLFxuICBGb290cHJpbnRzLFxuICBBcHBsZSxcbiAgV2FsbGV0LFxuICBQZW5Ub29sLFxuICBHcmFkdWF0aW9uQ2FwLFxuICBNdXNpYyxcbiAgQ2hlY2tDaXJjbGUyLFxuICBDbG9jayxcbiAgQ2hlY2ssXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBIYWJpdEljb25Qcm9wcyB7XG4gIG5hbWU6IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzaXplPzogbnVtYmVyO1xufVxuXG5leHBvcnQgY29uc3QgQVZBSUxBQkxFX0lDT05TID0gW1xuICB7IGlkOiAnRHJvcGxldCcsIGxhYmVsOiAn4KSq4KS+4KSo4KWAJywgaWNvbjogRHJvcGxldHMgfSxcbiAgeyBpZDogJ0Jvb2tPcGVuJywgbGFiZWw6ICfgpJXgpL/gpKTgpL7gpKwgLyDgpKrgpKLgpLzgpL7gpIgnLCBpY29uOiBCb29rT3BlbiB9LFxuICB7IGlkOiAnQWN0aXZpdHknLCBsYWJlbDogJ+CkteCljeCkr+CkvuCkr+CkvuCkriAvIOCkq+Ckv+Ckn+CkqOClh+CkuCcsIGljb246IEFjdGl2aXR5IH0sXG4gIHsgaWQ6ICdTdW5yaXNlJywgbGFiZWw6ICfgpLjgpYHgpKzgpLkgLyDgpIngpKDgpKjgpL4nLCBpY29uOiBTdW5yaXNlIH0sXG4gIHsgaWQ6ICdIZWFydCcsIGxhYmVsOiAn4KSn4KWN4KSv4KS+4KSoIC8g4KSm4KS/4KSyJywgaWNvbjogSGVhcnQgfSxcbiAgeyBpZDogJ0R1bWJiZWxsJywgbGFiZWw6ICfgpJzgpL/gpK4gLyDgpJXgpLjgpLDgpKQnLCBpY29uOiBEdW1iYmVsbCB9LFxuICB7IGlkOiAnU3BhcmtsZXMnLCBsYWJlbDogJ+CkquCljeCksOClh+CksOCko+CkviAvIOCkmuCkruCklScsIGljb246IFNwYXJrbGVzIH0sXG4gIHsgaWQ6ICdTdW4nLCBsYWJlbDogJ+Ckp+ClguCkqiAvIOCkpuCkv+CkqOCkmuCksOCljeCkr+CkvicsIGljb246IFN1biB9LFxuICB7IGlkOiAnTW9vbicsIGxhYmVsOiAn4KSo4KWA4KSC4KSmIC8g4KS14KS/4KS24KWN4KSw4KS+4KSuJywgaWNvbjogTW9vbiB9LFxuICB7IGlkOiAnRm9vdHByaW50cycsIGxhYmVsOiAn4KSf4KS54KSy4KSo4KS+IC8g4KSV4KSm4KSuJywgaWNvbjogRm9vdHByaW50cyB9LFxuICB7IGlkOiAnQXBwbGUnLCBsYWJlbDogJ+CkuOCljeCkteCkuOCljeCkpSDgpK3gpYvgpJzgpKgnLCBpY29uOiBBcHBsZSB9LFxuICB7IGlkOiAnV2FsbGV0JywgbGFiZWw6ICfgpKzgpJrgpKQgLyDgpLXgpL/gpKTgpY3gpKQnLCBpY29uOiBXYWxsZXQgfSxcbiAgeyBpZDogJ1BlblRvb2wnLCBsYWJlbDogJ+CkoeCkvuCkr+CksOClgCAvIOCksuClh+CkluCkqCcsIGljb246IFBlblRvb2wgfSxcbiAgeyBpZDogJ0dyYWR1YXRpb25DYXAnLCBsYWJlbDogJ+CkuOClgOCkluCkqOCkvicsIGljb246IEdyYWR1YXRpb25DYXAgfSxcbiAgeyBpZDogJ011c2ljJywgbGFiZWw6ICfgpLjgpILgpJfgpYDgpKQgLyDgpLbgpYzgpJUnLCBpY29uOiBNdXNpYyB9LFxuICB7IGlkOiAnQ2xvY2snLCBsYWJlbDogJ+CkuOCkruCkryDgpKrgpY3gpLDgpKzgpILgpKfgpKgnLCBpY29uOiBDbG9jayB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IEhBQklUX0NPTE9SUyA9IFtcbiAgeyBpZDogJ2VtZXJhbGQnLCBuYW1lOiAn4KSX4KS54KSw4KS+IOCkueCksOCkvicsIGJnOiAnYmctZW1lcmFsZC01MDAvMTUnLCB0ZXh0OiAndGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAnLCBib3JkZXI6ICdib3JkZXItZW1lcmFsZC01MDAvMzAnLCBhY2NlbnQ6ICdiZy1lbWVyYWxkLTYwMCcgfSxcbiAgeyBpZDogJ3NreScsIG5hbWU6ICfgpIbgpLjgpK7gpL7gpKjgpYAnLCBiZzogJ2JnLXNreS01MDAvMTUnLCB0ZXh0OiAndGV4dC1za3ktNzAwIGRhcms6dGV4dC1za3ktNDAwJywgYm9yZGVyOiAnYm9yZGVyLXNreS01MDAvMzAnLCBhY2NlbnQ6ICdiZy1za3ktNjAwJyB9LFxuICB7IGlkOiAnYW1iZXInLCBuYW1lOiAn4KS44KWB4KSo4KS54KSw4KS+JywgYmc6ICdiZy1hbWJlci01MDAvMTUnLCB0ZXh0OiAndGV4dC1hbWJlci03MDAgZGFyazp0ZXh0LWFtYmVyLTQwMCcsIGJvcmRlcjogJ2JvcmRlci1hbWJlci01MDAvMzAnLCBhY2NlbnQ6ICdiZy1hbWJlci02MDAnIH0sXG4gIHsgaWQ6ICdyb3NlJywgbmFtZTogJ+Ckl+ClgeCksuCkvuCkrOClgCcsIGJnOiAnYmctcm9zZS01MDAvMTUnLCB0ZXh0OiAndGV4dC1yb3NlLTcwMCBkYXJrOnRleHQtcm9zZS00MDAnLCBib3JkZXI6ICdib3JkZXItcm9zZS01MDAvMzAnLCBhY2NlbnQ6ICdiZy1yb3NlLTYwMCcgfSxcbiAgeyBpZDogJ3B1cnBsZScsIG5hbWU6ICfgpKzgpYjgpILgpJfgpKjgpYAnLCBiZzogJ2JnLXB1cnBsZS01MDAvMTUnLCB0ZXh0OiAndGV4dC1wdXJwbGUtNzAwIGRhcms6dGV4dC1wdXJwbGUtNDAwJywgYm9yZGVyOiAnYm9yZGVyLXB1cnBsZS01MDAvMzAnLCBhY2NlbnQ6ICdiZy1wdXJwbGUtNjAwJyB9LFxuICB7IGlkOiAnb3JhbmdlJywgbmFtZTogJ+CkqOCkvuCksOCkguCkl+ClgCcsIGJnOiAnYmctb3JhbmdlLTUwMC8xNScsIHRleHQ6ICd0ZXh0LW9yYW5nZS03MDAgZGFyazp0ZXh0LW9yYW5nZS00MDAnLCBib3JkZXI6ICdib3JkZXItb3JhbmdlLTUwMC8zMCcsIGFjY2VudDogJ2JnLW9yYW5nZS02MDAnIH0sXG4gIHsgaWQ6ICd0ZWFsJywgbmFtZTogJ+Ckn+ClgOCksicsIGJnOiAnYmctdGVhbC01MDAvMTUnLCB0ZXh0OiAndGV4dC10ZWFsLTcwMCBkYXJrOnRleHQtdGVhbC00MDAnLCBib3JkZXI6ICdib3JkZXItdGVhbC01MDAvMzAnLCBhY2NlbnQ6ICdiZy10ZWFsLTYwMCcgfSxcbl07XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRDb2xvclNjaGVtZShjb2xvcklkOiBzdHJpbmcpIHtcbiAgcmV0dXJuIEhBQklUX0NPTE9SUy5maW5kKChjKSA9PiBjLmlkID09PSBjb2xvcklkKSB8fCBIQUJJVF9DT0xPUlNbMF07XG59XG5cbmV4cG9ydCBjb25zdCBIYWJpdEljb246IFJlYWN0LkZDPEhhYml0SWNvblByb3BzPiA9ICh7IG5hbWUsIGNsYXNzTmFtZSA9ICcnLCBzaXplID0gMjAgfSkgPT4ge1xuICBzd2l0Y2ggKG5hbWUpIHtcbiAgICBjYXNlICdEcm9wbGV0JzpcbiAgICAgIHJldHVybiA8RHJvcGxldHMgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGNhc2UgJ0Jvb2tPcGVuJzpcbiAgICAgIHJldHVybiA8Qm9va09wZW4gc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGNhc2UgJ0FjdGl2aXR5JzpcbiAgICAgIHJldHVybiA8QWN0aXZpdHkgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGNhc2UgJ1N1bnJpc2UnOlxuICAgICAgcmV0dXJuIDxTdW5yaXNlIHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbiAgICBjYXNlICdIZWFydCc6XG4gICAgICByZXR1cm4gPEhlYXJ0IHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbiAgICBjYXNlICdEdW1iYmVsbCc6XG4gICAgICByZXR1cm4gPER1bWJiZWxsIHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbiAgICBjYXNlICdTcGFya2xlcyc6XG4gICAgICByZXR1cm4gPFNwYXJrbGVzIHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbiAgICBjYXNlICdTdW4nOlxuICAgICAgcmV0dXJuIDxTdW4gc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGNhc2UgJ01vb24nOlxuICAgICAgcmV0dXJuIDxNb29uIHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbiAgICBjYXNlICdGb290cHJpbnRzJzpcbiAgICAgIHJldHVybiA8Rm9vdHByaW50cyBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG4gICAgY2FzZSAnQXBwbGUnOlxuICAgICAgcmV0dXJuIDxBcHBsZSBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG4gICAgY2FzZSAnV2FsbGV0JzpcbiAgICAgIHJldHVybiA8V2FsbGV0IHNpemU9e3NpemV9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSAvPjtcbiAgICBjYXNlICdQZW5Ub29sJzpcbiAgICAgIHJldHVybiA8UGVuVG9vbCBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG4gICAgY2FzZSAnR3JhZHVhdGlvbkNhcCc6XG4gICAgICByZXR1cm4gPEdyYWR1YXRpb25DYXAgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGNhc2UgJ011c2ljJzpcbiAgICAgIHJldHVybiA8TXVzaWMgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGNhc2UgJ0Nsb2NrJzpcbiAgICAgIHJldHVybiA8Q2xvY2sgc2l6ZT17c2l6ZX0gY2xhc3NOYW1lPXtjbGFzc05hbWV9IC8+O1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gPENoZWNrQ2lyY2xlMiBzaXplPXtzaXplfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gLz47XG4gIH1cbn07XG4iXX0=