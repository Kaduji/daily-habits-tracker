const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { X, Check, Clock, Calendar, Tag, Palette } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { AVAILABLE_ICONS, HABIT_COLORS, HabitIcon } from "/src/components/HabitIcon.tsx";
var _jsxFileName = "/app/applet/src/components/HabitFormModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
const CATEGORIES = [
	"स्वास्थ्य",
	"पढ़ाई",
	"इबादत",
	"व्यक्तिगत विकास",
	"अन्य"
];
const DAYS_OF_WEEK = [
	{
		day: 1,
		label: "सोम"
	},
	{
		day: 2,
		label: "मंगल"
	},
	{
		day: 3,
		label: "बुध"
	},
	{
		day: 4,
		label: "गुरु"
	},
	{
		day: 5,
		label: "शुक्र"
	},
	{
		day: 6,
		label: "शनि"
	},
	{
		day: 0,
		label: "रवि"
	}
];
export const HabitFormModal = ({ isOpen, onClose, onSave, initialHabit }) => {
	const [name, setName] = useState("");
	const [category, setCategory] = useState("स्वास्थ्य");
	const [icon, setIcon] = useState("Droplet");
	const [targetType, setTargetType] = useState("numeric");
	const [targetValue, setTargetValue] = useState(1);
	const [unit, setUnit] = useState("बार");
	const [frequencyType, setFrequencyType] = useState("daily");
	const [scheduledDays, setScheduledDays] = useState([
		0,
		1,
		2,
		3,
		4,
		5,
		6
	]);
	const [reminderTime, setReminderTime] = useState("");
	const [color, setColor] = useState("emerald");
	const [error, setError] = useState("");
	useEffect(() => {
		if (initialHabit) {
			setName(initialHabit.name);
			setCategory(initialHabit.category);
			setIcon(initialHabit.icon);
			setTargetType(initialHabit.targetType);
			setTargetValue(initialHabit.targetValue);
			setUnit(initialHabit.unit || (initialHabit.targetType === "boolean" ? "बार" : "गिलास"));
			setFrequencyType(initialHabit.frequencyType);
			setScheduledDays(initialHabit.scheduledDays || [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			]);
			setReminderTime(initialHabit.reminderTime || "");
			setColor(initialHabit.color || "emerald");
		} else {
			setName("");
			setCategory("स्वास्थ्य");
			setIcon("Droplet");
			setTargetType("numeric");
			setTargetValue(8);
			setUnit("गिलास");
			setFrequencyType("daily");
			setScheduledDays([
				0,
				1,
				2,
				3,
				4,
				5,
				6
			]);
			setReminderTime("08:00");
			setColor("emerald");
		}
		setError("");
	}, [initialHabit, isOpen]);
	if (!isOpen) return null;
	const toggleDay = (day) => {
		if (scheduledDays.includes(day)) {
			if (scheduledDays.length === 1) {
				setError("कम से कम एक दिन चुनना अनिवार्य है।");
				return;
			}
			setScheduledDays(scheduledDays.filter((d) => d !== day));
		} else {
			setScheduledDays([...scheduledDays, day]);
		}
	};
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!name.trim()) {
			setError("कृपया आदत का नाम दर्ज करें।");
			return;
		}
		if (targetType === "numeric" && (!targetValue || targetValue <= 0)) {
			setError("कृपया 1 या अधिक का वैध लक्ष्य दर्ज करें।");
			return;
		}
		if (frequencyType === "custom_days" && scheduledDays.length === 0) {
			setError("कम से कम एक दिन का चयन करें।");
			return;
		}
		onSave({
			name: name.trim(),
			category,
			icon,
			targetType,
			targetValue: targetType === "boolean" ? 1 : Number(targetValue),
			unit: targetType === "boolean" ? "बार" : unit.trim() || "इकाई",
			frequencyType,
			scheduledDays: frequencyType === "daily" ? [
				0,
				1,
				2,
				3,
				4,
				5,
				6
			] : scheduledDays,
			reminderTime: reminderTime.trim() || undefined,
			color
		});
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full sm:max-w-lg max-h-[92vh] flex flex-col bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden",
			role: "dialog",
			"aria-modal": "true",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-5 py-4 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between bg-stone-50/50 dark:bg-stone-900/50",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-xl font-bold text-stone-900 dark:text-stone-100",
					children: initialHabit ? "आदत संपादित करें" : "नई आदत जोड़ें"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-stone-500 dark:text-stone-400",
					children: "अपनी दैनिक दिनचर्या में एक सकारात्मक कदम जोड़ें"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 127,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "p-2 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 rounded-full hover:bg-stone-100 dark:hover:bg-stone-800 transition",
					children: /* @__PURE__ */ _jsxDEV(X, { size: 20 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 131,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				className: "flex-1 overflow-y-auto p-5 space-y-5",
				children: [
					error && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 rounded-xl text-sm font-medium",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5",
						children: "आदत का नाम *"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 149,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: name,
						onChange: (e) => {
							setName(e.target.value);
							setError("");
						},
						placeholder: "उदा. 8 गिलास पानी पीना, 20 मिनट किताब पढ़ना...",
						className: "w-full px-4 py-2.5 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-emerald-600 text-sm",
						autoFocus: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 152,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Tag, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 17
							}, this), " श्रेणी चुनें"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap gap-2",
						children: CATEGORIES.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setCategory(cat),
							className: `px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${category === cat ? "bg-emerald-700 text-white shadow-xs" : "bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700"}`,
							children: cat
						}, cat, false, {
							fileName: _jsxFileName,
							lineNumber: 174,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5",
						children: "आइकन चुनें"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-4 sm:grid-cols-8 gap-2",
						children: AVAILABLE_ICONS.map((item) => /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							title: item.label,
							onClick: () => setIcon(item.id),
							className: `p-2.5 rounded-xl flex flex-col items-center justify-center gap-1 transition cursor-pointer ${icon === item.id ? "bg-emerald-700 text-white ring-2 ring-emerald-500 shadow-xs" : "bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700"}`,
							children: [/* @__PURE__ */ _jsxDEV(HabitIcon, {
								name: item.id,
								size: 20
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] truncate max-w-full",
								children: item.label.split(" ")[0]
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 19
							}, this)]
						}, item.id, true, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "inline-flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(Palette, { size: 14 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 17
							}, this), " कार्ड का रंग"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap gap-2.5",
						children: HABIT_COLORS.map((c) => /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setColor(c.id),
							className: `w-7 h-7 rounded-full flex items-center justify-center transition cursor-pointer ${c.accent} ${color === c.id ? "ring-3 ring-offset-2 ring-emerald-600 dark:ring-offset-stone-900 scale-110" : "opacity-80 hover:opacity-100"}`,
							children: color === c.id && /* @__PURE__ */ _jsxDEV(Check, {
								size: 14,
								className: "text-white"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 38
							}, this)
						}, c.id, false, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 222,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 216,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-stone-50 dark:bg-stone-800/50 rounded-2xl border border-stone-200/80 dark:border-stone-800 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider",
								children: "लक्ष्य का प्रकार"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 241,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex bg-stone-200 dark:bg-stone-700 rounded-lg p-0.5 text-xs font-medium",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										setTargetType("boolean");
										setTargetValue(1);
									},
									className: `px-3 py-1 rounded-md transition ${targetType === "boolean" ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs font-bold" : "text-stone-600 dark:text-stone-400"}`,
									children: "हाँ / ना"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 245,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setTargetType("numeric"),
									className: `px-3 py-1 rounded-md transition ${targetType === "numeric" ? "bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs font-bold" : "text-stone-600 dark:text-stone-400"}`,
									children: "मात्रात्मक"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 244,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 13
						}, this), targetType === "numeric" ? /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-3 pt-1",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[11px] text-stone-500 dark:text-stone-400 mb-1",
								children: "दैनिक लक्ष्य संख्या"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "number",
								min: "1",
								max: "100000",
								value: targetValue,
								onChange: (e) => setTargetValue(Number(e.target.value)),
								className: "w-full px-3 py-2 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 text-sm font-semibold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-[11px] text-stone-500 dark:text-stone-400 mb-1",
								children: "इकाई (Unit)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								value: unit,
								onChange: (e) => setUnit(e.target.value),
								placeholder: "उदा. गिलास, मिनट, पेज",
								className: "w-full px-3 py-2 rounded-xl border border-stone-300 dark:border-stone-700 bg-white dark:bg-stone-800 text-stone-900 dark:text-stone-100 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 274,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-stone-500 dark:text-stone-400",
							children: "प्रतिदिन केवल एक बार पूरा/अधूरा चिह्नित करना होगा (उदा. सुबह उठना, दवा लेना)।"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 239,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 312,
									columnNumber: 17
								}, this), " आवृत्ति (दिन)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 311,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 310,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-2 mb-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									setFrequencyType("daily");
									setScheduledDays([
										0,
										1,
										2,
										3,
										4,
										5,
										6
									]);
								},
								className: `py-2 px-3 rounded-xl text-xs font-medium border text-center transition cursor-pointer ${frequencyType === "daily" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold" : "border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/50 text-stone-600 dark:text-stone-400"}`,
								children: "हर दिन (दैनिक)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 316,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setFrequencyType("custom_days"),
								className: `py-2 px-3 rounded-xl text-xs font-medium border text-center transition cursor-pointer ${frequencyType === "custom_days" ? "border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold" : "border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/50 text-stone-600 dark:text-stone-400"}`,
								children: "सप्ताह के चुने हुए दिन"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 315,
							columnNumber: 13
						}, this),
						frequencyType === "custom_days" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between gap-1 p-2 bg-stone-50 dark:bg-stone-800/50 rounded-xl border border-stone-200 dark:border-stone-700",
							children: DAYS_OF_WEEK.map((item) => {
								const isSelected = scheduledDays.includes(item.day);
								return /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => toggleDay(item.day),
									className: `flex-1 py-1.5 rounded-lg text-xs font-bold transition ${isSelected ? "bg-emerald-700 text-white shadow-xs" : "bg-stone-200 dark:bg-stone-700 text-stone-600 dark:text-stone-400 hover:bg-stone-300"}`,
									children: item.label
								}, item.day, false, {
									fileName: _jsxFileName,
									lineNumber: 348,
									columnNumber: 21
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 309,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold text-stone-700 dark:text-stone-300 uppercase tracking-wider mb-1.5",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "inline-flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { size: 14 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 17
								}, this), " दैनिक रिमाइंडर समय (वैकल्पिक)"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 369,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 368,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex gap-2 items-center",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "time",
								value: reminderTime,
								onChange: (e) => setReminderTime(e.target.value),
								className: "flex-1 px-4 py-2 rounded-xl border border-stone-300 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/80 text-stone-900 dark:text-stone-100 text-sm font-semibold"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 15
							}, this), reminderTime && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setReminderTime(""),
								className: "px-3 py-2 text-xs text-stone-500 hover:text-stone-700 dark:hover:text-stone-300 rounded-lg border border-stone-300 dark:border-stone-700",
								children: "हटाएं"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 381,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "mt-1 text-[11px] text-stone-500 dark:text-stone-400",
							children: "यह समय होने पर ऐप में रिमाइंडर संकेत प्राप्त होगा।"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 390,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 367,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-2 flex gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "flex-1 py-3 px-4 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 font-semibold text-sm hover:bg-stone-100 dark:hover:bg-stone-800 transition active:scale-95",
							children: "रद्द करें"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 397,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "flex-1 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md transition active:scale-95 flex items-center justify-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Check, { size: 18 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 408,
								columnNumber: 15
							}, this), initialHabit ? "बदलाव सहेजें" : "आदत जोड़ें"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 396,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 140,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 116,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 115,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsR0FBRyxPQUFPLE9BQU8sVUFBZ0IsS0FBSyxlQUFlO0FBRTlELFNBQVMsaUJBQWlCLGNBQWMsaUJBQWlCOzs7QUFTekQsTUFBTSxhQUE4QjtDQUFDO0NBQWE7Q0FBUztDQUFTO0NBQW1CO0FBQU07QUFFN0YsTUFBTSxlQUFvRDtDQUN4RDtFQUFFLEtBQUs7RUFBRyxPQUFPO0NBQU07Q0FDdkI7RUFBRSxLQUFLO0VBQUcsT0FBTztDQUFPO0NBQ3hCO0VBQUUsS0FBSztFQUFHLE9BQU87Q0FBTTtDQUN2QjtFQUFFLEtBQUs7RUFBRyxPQUFPO0NBQU87Q0FDeEI7RUFBRSxLQUFLO0VBQUcsT0FBTztDQUFRO0NBQ3pCO0VBQUUsS0FBSztFQUFHLE9BQU87Q0FBTTtDQUN2QjtFQUFFLEtBQUs7RUFBRyxPQUFPO0NBQU07QUFDekI7QUFFQSxPQUFPLE1BQU0sa0JBQWlELEVBQzVELFFBQ0EsU0FDQSxRQUNBLG1CQUNJO0NBQ0osTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEVBQUU7Q0FDbkMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF3QixXQUFXO0NBQ25FLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxTQUFTO0NBQzFDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFxQixTQUFTO0NBQ2xFLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFpQixDQUFDO0NBQ3hELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxLQUFLO0NBQ3RDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUF3QixPQUFPO0NBQ3pFLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFzQjtFQUFDO0VBQUc7RUFBRztFQUFHO0VBQUc7RUFBRztFQUFHO0NBQUMsQ0FBQztDQUNyRixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxTQUFTO0NBQzVDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLGdCQUFnQjtFQUNkLElBQUksY0FBYztHQUNoQixRQUFRLGFBQWEsSUFBSTtHQUN6QixZQUFZLGFBQWEsUUFBUTtHQUNqQyxRQUFRLGFBQWEsSUFBSTtHQUN6QixjQUFjLGFBQWEsVUFBVTtHQUNyQyxlQUFlLGFBQWEsV0FBVztHQUN2QyxRQUFRLGFBQWEsU0FBUyxhQUFhLGVBQWUsWUFBWSxRQUFRLFFBQVE7R0FDdEYsaUJBQWlCLGFBQWEsYUFBYTtHQUMzQyxpQkFBaUIsYUFBYSxpQkFBaUI7SUFBQztJQUFHO0lBQUc7SUFBRztJQUFHO0lBQUc7SUFBRztHQUFDLENBQUM7R0FDcEUsZ0JBQWdCLGFBQWEsZ0JBQWdCLEVBQUU7R0FDL0MsU0FBUyxhQUFhLFNBQVMsU0FBUztFQUMxQyxPQUFPO0dBQ0wsUUFBUSxFQUFFO0dBQ1YsWUFBWSxXQUFXO0dBQ3ZCLFFBQVEsU0FBUztHQUNqQixjQUFjLFNBQVM7R0FDdkIsZUFBZSxDQUFDO0dBQ2hCLFFBQVEsT0FBTztHQUNmLGlCQUFpQixPQUFPO0dBQ3hCLGlCQUFpQjtJQUFDO0lBQUc7SUFBRztJQUFHO0lBQUc7SUFBRztJQUFHO0dBQUMsQ0FBQztHQUN0QyxnQkFBZ0IsT0FBTztHQUN2QixTQUFTLFNBQVM7RUFDcEI7RUFDQSxTQUFTLEVBQUU7Q0FDYixHQUFHLENBQUMsY0FBYyxNQUFNLENBQUM7Q0FFekIsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixNQUFNLGFBQWEsUUFBbUI7RUFDcEMsSUFBSSxjQUFjLFNBQVMsR0FBRyxHQUFHO0dBQy9CLElBQUksY0FBYyxXQUFXLEdBQUc7SUFDOUIsU0FBUyxvQ0FBb0M7SUFDN0M7R0FDRjtHQUNBLGlCQUFpQixjQUFjLFFBQVEsTUFBTSxNQUFNLEdBQUcsQ0FBQztFQUN6RCxPQUFPO0dBQ0wsaUJBQWlCLENBQUMsR0FBRyxlQUFlLEdBQUcsQ0FBQztFQUMxQztDQUNGO0NBRUEsTUFBTSxnQkFBZ0IsTUFBdUI7RUFDM0MsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRztHQUNoQixTQUFTLDZCQUE2QjtHQUN0QztFQUNGO0VBQ0EsSUFBSSxlQUFlLGNBQWMsQ0FBQyxlQUFlLGVBQWUsSUFBSTtHQUNsRSxTQUFTLDBDQUEwQztHQUNuRDtFQUNGO0VBQ0EsSUFBSSxrQkFBa0IsaUJBQWlCLGNBQWMsV0FBVyxHQUFHO0dBQ2pFLFNBQVMsOEJBQThCO0dBQ3ZDO0VBQ0Y7RUFFQSxPQUFPO0dBQ0wsTUFBTSxLQUFLLEtBQUs7R0FDaEI7R0FDQTtHQUNBO0dBQ0EsYUFBYSxlQUFlLFlBQVksSUFBSSxPQUFPLFdBQVc7R0FDOUQsTUFBTSxlQUFlLFlBQVksUUFBUyxLQUFLLEtBQUssS0FBSztHQUN6RDtHQUNBLGVBQWUsa0JBQWtCLFVBQVU7SUFBQztJQUFHO0lBQUc7SUFBRztJQUFHO0lBQUc7SUFBRztHQUFDLElBQUk7R0FDbkUsY0FBYyxhQUFhLEtBQUssS0FBSztHQUNyQztFQUNGLENBQUM7RUFDRCxRQUFRO0NBQ1Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUNFLFdBQVU7R0FDVixNQUFLO0dBQ0wsY0FBVzthQUhiLENBTUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLGVBQWUscUJBQXFCO0lBQ25DOzs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBNkM7SUFFdkQ7Ozs7WUFDQTs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUVWLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0lBQ1I7Ozs7WUFDTDs7Ozs7YUFHTCx3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFjLFdBQVU7Y0FBeEM7S0FDRyxTQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaO0tBQ0U7Ozs7O0tBSVAsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUE2RjtLQUV2Rzs7OztlQUNQLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsTUFBTTtPQUNmLFFBQVEsRUFBRSxPQUFPLEtBQUs7T0FDdEIsU0FBUyxFQUFFO01BQ2I7TUFDQSxhQUFZO01BQ1osV0FBVTtNQUNWO0tBQ0Q7Ozs7YUFDRTs7Ozs7S0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQ2Ysd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsS0FBRCxFQUFLLE1BQU0sR0FBSzs7OztpQkFBQyxlQUNiOzs7Ozs7S0FDRDs7OztlQUNQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFdBQVcsS0FBSyxRQUNmLHdCQUFDLFVBQUQ7T0FFRSxNQUFLO09BQ0wsZUFBZSxZQUFZLEdBQUc7T0FDOUIsV0FBVywwRUFDVCxhQUFhLE1BQ1Qsd0NBQ0E7aUJBR0w7TUFDSyxHQVZEOzs7O2FBVUMsQ0FDVDtLQUNFOzs7O2FBQ0Y7Ozs7O0tBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUE2RjtLQUV2Rzs7OztlQUNQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGdCQUFnQixLQUFLLFNBQ3BCLHdCQUFDLFVBQUQ7T0FFRSxNQUFLO09BQ0wsT0FBTyxLQUFLO09BQ1osZUFBZSxRQUFRLEtBQUssRUFBRTtPQUM5QixXQUFXLDhGQUNULFNBQVMsS0FBSyxLQUNWLGdFQUNBO2lCQVJSLENBV0Usd0JBQUMsV0FBRDtRQUFXLE1BQU0sS0FBSztRQUFJLE1BQU07T0FBSzs7OztpQkFDckMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1DLEtBQUssTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDO09BQVM7Ozs7ZUFDNUU7U0FaRCxLQUFLOzs7O2FBWUosQ0FDVDtLQUNFOzs7O2FBQ0Y7Ozs7O0tBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUNmLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxNQUFNLEdBQUs7Ozs7aUJBQUMsZUFDakI7Ozs7OztLQUNEOzs7O2VBQ1Asd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osYUFBYSxLQUFLLE1BQ2pCLHdCQUFDLFVBQUQ7T0FFRSxNQUFLO09BQ0wsZUFBZSxTQUFTLEVBQUUsRUFBRTtPQUM1QixXQUFXLG1GQUFtRixFQUFFLE9BQU8sR0FDckcsVUFBVSxFQUFFLEtBQUssK0VBQStFO2lCQUdqRyxVQUFVLEVBQUUsTUFBTSx3QkFBQyxPQUFEO1FBQU8sTUFBTTtRQUFJLFdBQVU7T0FBYzs7Ozs7TUFDdEQsR0FSRCxFQUFFOzs7O2FBUUQsQ0FDVDtLQUNFOzs7O2FBQ0Y7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFnRjtPQUUxRjs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZTtVQUNiLGNBQWMsU0FBUztVQUN2QixlQUFlLENBQUM7U0FDbEI7U0FDQSxXQUFXLG1DQUNULGVBQWUsWUFDWCxzRkFDQTttQkFFUDtRQUVPOzs7O2tCQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxjQUFjLFNBQVM7U0FDdEMsV0FBVyxtQ0FDVCxlQUFlLFlBQ1gsc0ZBQ0E7bUJBRVA7UUFFTzs7OztnQkFDTDs7Ozs7ZUFDRjs7Ozs7Z0JBRUosZUFBZSxZQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUE0RDtPQUV0RTs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLEtBQUk7UUFDSixLQUFJO1FBQ0osT0FBTztRQUNQLFdBQVcsTUFBTSxlQUFlLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztRQUN0RCxXQUFVO09BQ1g7Ozs7ZUFDRTs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQTREO09BRXRFOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0wsT0FBTztRQUNQLFdBQVcsTUFBTSxRQUFRLEVBQUUsT0FBTyxLQUFLO1FBQ3ZDLGFBQVk7UUFDWixXQUFVO09BQ1g7Ozs7ZUFDRTs7OztlQUNGOzs7OztpQkFFTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBNkM7TUFFdkQ7Ozs7Y0FFRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUNmLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7a0JBQUMsZ0JBQ2xCOzs7Ozs7TUFDRDs7Ozs7TUFDUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZTtTQUNiLGlCQUFpQixPQUFPO1NBQ3hCLGlCQUFpQjtVQUFDO1VBQUc7VUFBRztVQUFHO1VBQUc7VUFBRztVQUFHO1NBQUMsQ0FBQztRQUN4QztRQUNBLFdBQVcseUZBQ1Qsa0JBQWtCLFVBQ2QsNkdBQ0E7a0JBRVA7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsaUJBQWlCLGFBQWE7UUFDN0MsV0FBVyx5RkFDVCxrQkFBa0IsZ0JBQ2QsNkdBQ0E7a0JBRVA7T0FFTzs7OztlQUNMOzs7Ozs7TUFFSixrQkFBa0IsaUJBQ2pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGFBQWEsS0FBSyxTQUFTO1FBQzFCLE1BQU0sYUFBYSxjQUFjLFNBQVMsS0FBSyxHQUFHO1FBQ2xELE9BQ0Usd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxlQUFlLFVBQVUsS0FBSyxHQUFHO1NBQ2pDLFdBQVcseURBQ1QsYUFDSSx3Q0FDQTttQkFHTCxLQUFLO1FBQ0EsR0FWRCxLQUFLOzs7O2VBVUo7T0FFWixDQUFDO01BQ0U7Ozs7O0tBRUo7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUNmLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7a0JBQUMsZ0NBQ2Y7Ozs7OztNQUNEOzs7OztNQUNQLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxPQUFPO1FBQ1AsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sS0FBSztRQUMvQyxXQUFVO09BQ1g7Ozs7aUJBQ0EsZ0JBQ0Msd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLGdCQUFnQixFQUFFO1FBQ2pDLFdBQVU7a0JBQ1g7T0FFTzs7OztlQUVQOzs7Ozs7TUFDTCx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBc0Q7TUFFaEU7Ozs7O0tBQ0E7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsTUFBSztPQUNMLFNBQVM7T0FDVCxXQUFVO2lCQUNYO01BRU87Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxXQUFVO2lCQUZaLENBSUUsd0JBQUMsT0FBRCxFQUFPLE1BQU0sR0FBSzs7OztpQkFDakIsZUFBZSxpQkFBaUIsWUFDM0I7Ozs7O2NBQ0w7Ozs7OztJQUNEOzs7OztXQUNIOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIYWJpdEZvcm1Nb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBYLCBDaGVjaywgQ2xvY2ssIENhbGVuZGFyLCBIYXNoLCBUYWcsIFBhbGV0dGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgSGFiaXQsIEhhYml0Q2F0ZWdvcnksIFRhcmdldFR5cGUsIEZyZXF1ZW5jeVR5cGUsIERheU9mV2VlayB9IGZyb20gJy4uL3R5cGVzL2hhYml0JztcbmltcG9ydCB7IEFWQUlMQUJMRV9JQ09OUywgSEFCSVRfQ09MT1JTLCBIYWJpdEljb24gfSBmcm9tICcuL0hhYml0SWNvbic7XG5cbmludGVyZmFjZSBIYWJpdEZvcm1Nb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblNhdmU6IChoYWJpdERhdGE6IFBhcnRpYWw8SGFiaXQ+KSA9PiB2b2lkO1xuICBpbml0aWFsSGFiaXQ/OiBIYWJpdCB8IG51bGw7XG59XG5cbmNvbnN0IENBVEVHT1JJRVM6IEhhYml0Q2F0ZWdvcnlbXSA9IFsn4KS44KWN4KS14KS+4KS44KWN4KSl4KWN4KSvJywgJ+CkquCkouCkvOCkvuCkiCcsICfgpIfgpKzgpL7gpKbgpKQnLCAn4KS14KWN4KSv4KSV4KWN4KSk4KS/4KSX4KSkIOCkteCkv+CkleCkvuCkuCcsICfgpIXgpKjgpY3gpK8nXTtcblxuY29uc3QgREFZU19PRl9XRUVLOiB7IGRheTogRGF5T2ZXZWVrOyBsYWJlbDogc3RyaW5nIH1bXSA9IFtcbiAgeyBkYXk6IDEsIGxhYmVsOiAn4KS44KWL4KSuJyB9LFxuICB7IGRheTogMiwgbGFiZWw6ICfgpK7gpILgpJfgpLInIH0sXG4gIHsgZGF5OiAzLCBsYWJlbDogJ+CkrOClgeCkpycgfSxcbiAgeyBkYXk6IDQsIGxhYmVsOiAn4KSX4KWB4KSw4KWBJyB9LFxuICB7IGRheTogNSwgbGFiZWw6ICfgpLbgpYHgpJXgpY3gpLAnIH0sXG4gIHsgZGF5OiA2LCBsYWJlbDogJ+CktuCkqOCkvycgfSxcbiAgeyBkYXk6IDAsIGxhYmVsOiAn4KSw4KS14KS/JyB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IEhhYml0Rm9ybU1vZGFsOiBSZWFjdC5GQzxIYWJpdEZvcm1Nb2RhbFByb3BzPiA9ICh7XG4gIGlzT3BlbixcbiAgb25DbG9zZSxcbiAgb25TYXZlLFxuICBpbml0aWFsSGFiaXQsXG59KSA9PiB7XG4gIGNvbnN0IFtuYW1lLCBzZXROYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NhdGVnb3J5LCBzZXRDYXRlZ29yeV0gPSB1c2VTdGF0ZTxIYWJpdENhdGVnb3J5Pign4KS44KWN4KS14KS+4KS44KWN4KSl4KWN4KSvJyk7XG4gIGNvbnN0IFtpY29uLCBzZXRJY29uXSA9IHVzZVN0YXRlKCdEcm9wbGV0Jyk7XG4gIGNvbnN0IFt0YXJnZXRUeXBlLCBzZXRUYXJnZXRUeXBlXSA9IHVzZVN0YXRlPFRhcmdldFR5cGU+KCdudW1lcmljJyk7XG4gIGNvbnN0IFt0YXJnZXRWYWx1ZSwgc2V0VGFyZ2V0VmFsdWVdID0gdXNlU3RhdGU8bnVtYmVyPigxKTtcbiAgY29uc3QgW3VuaXQsIHNldFVuaXRdID0gdXNlU3RhdGUoJ+CkrOCkvuCksCcpO1xuICBjb25zdCBbZnJlcXVlbmN5VHlwZSwgc2V0RnJlcXVlbmN5VHlwZV0gPSB1c2VTdGF0ZTxGcmVxdWVuY3lUeXBlPignZGFpbHknKTtcbiAgY29uc3QgW3NjaGVkdWxlZERheXMsIHNldFNjaGVkdWxlZERheXNdID0gdXNlU3RhdGU8RGF5T2ZXZWVrW10+KFswLCAxLCAyLCAzLCA0LCA1LCA2XSk7XG4gIGNvbnN0IFtyZW1pbmRlclRpbWUsIHNldFJlbWluZGVyVGltZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjb2xvciwgc2V0Q29sb3JdID0gdXNlU3RhdGUoJ2VtZXJhbGQnKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaW5pdGlhbEhhYml0KSB7XG4gICAgICBzZXROYW1lKGluaXRpYWxIYWJpdC5uYW1lKTtcbiAgICAgIHNldENhdGVnb3J5KGluaXRpYWxIYWJpdC5jYXRlZ29yeSk7XG4gICAgICBzZXRJY29uKGluaXRpYWxIYWJpdC5pY29uKTtcbiAgICAgIHNldFRhcmdldFR5cGUoaW5pdGlhbEhhYml0LnRhcmdldFR5cGUpO1xuICAgICAgc2V0VGFyZ2V0VmFsdWUoaW5pdGlhbEhhYml0LnRhcmdldFZhbHVlKTtcbiAgICAgIHNldFVuaXQoaW5pdGlhbEhhYml0LnVuaXQgfHwgKGluaXRpYWxIYWJpdC50YXJnZXRUeXBlID09PSAnYm9vbGVhbicgPyAn4KSs4KS+4KSwJyA6ICfgpJfgpL/gpLLgpL7gpLgnKSk7XG4gICAgICBzZXRGcmVxdWVuY3lUeXBlKGluaXRpYWxIYWJpdC5mcmVxdWVuY3lUeXBlKTtcbiAgICAgIHNldFNjaGVkdWxlZERheXMoaW5pdGlhbEhhYml0LnNjaGVkdWxlZERheXMgfHwgWzAsIDEsIDIsIDMsIDQsIDUsIDZdKTtcbiAgICAgIHNldFJlbWluZGVyVGltZShpbml0aWFsSGFiaXQucmVtaW5kZXJUaW1lIHx8ICcnKTtcbiAgICAgIHNldENvbG9yKGluaXRpYWxIYWJpdC5jb2xvciB8fCAnZW1lcmFsZCcpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXROYW1lKCcnKTtcbiAgICAgIHNldENhdGVnb3J5KCfgpLjgpY3gpLXgpL7gpLjgpY3gpKXgpY3gpK8nKTtcbiAgICAgIHNldEljb24oJ0Ryb3BsZXQnKTtcbiAgICAgIHNldFRhcmdldFR5cGUoJ251bWVyaWMnKTtcbiAgICAgIHNldFRhcmdldFZhbHVlKDgpO1xuICAgICAgc2V0VW5pdCgn4KSX4KS/4KSy4KS+4KS4Jyk7XG4gICAgICBzZXRGcmVxdWVuY3lUeXBlKCdkYWlseScpO1xuICAgICAgc2V0U2NoZWR1bGVkRGF5cyhbMCwgMSwgMiwgMywgNCwgNSwgNl0pO1xuICAgICAgc2V0UmVtaW5kZXJUaW1lKCcwODowMCcpO1xuICAgICAgc2V0Q29sb3IoJ2VtZXJhbGQnKTtcbiAgICB9XG4gICAgc2V0RXJyb3IoJycpO1xuICB9LCBbaW5pdGlhbEhhYml0LCBpc09wZW5dKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdG9nZ2xlRGF5ID0gKGRheTogRGF5T2ZXZWVrKSA9PiB7XG4gICAgaWYgKHNjaGVkdWxlZERheXMuaW5jbHVkZXMoZGF5KSkge1xuICAgICAgaWYgKHNjaGVkdWxlZERheXMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHNldEVycm9yKCfgpJXgpK4g4KS44KWHIOCkleCkriDgpI/gpJUg4KSm4KS/4KSoIOCkmuClgeCkqOCkqOCkviDgpIXgpKjgpL/gpLXgpL7gpLDgpY3gpK8g4KS54KWI4KWkJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHNldFNjaGVkdWxlZERheXMoc2NoZWR1bGVkRGF5cy5maWx0ZXIoKGQpID0+IGQgIT09IGRheSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRTY2hlZHVsZWREYXlzKFsuLi5zY2hlZHVsZWREYXlzLCBkYXldKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIW5hbWUudHJpbSgpKSB7XG4gICAgICBzZXRFcnJvcign4KSV4KWD4KSq4KSv4KS+IOCkhuCkpuCkpCDgpJXgpL4g4KSo4KS+4KSuIOCkpuCksOCljeCknCDgpJXgpLDgpYfgpILgpaQnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRhcmdldFR5cGUgPT09ICdudW1lcmljJyAmJiAoIXRhcmdldFZhbHVlIHx8IHRhcmdldFZhbHVlIDw9IDApKSB7XG4gICAgICBzZXRFcnJvcign4KSV4KWD4KSq4KSv4KS+IDEg4KSv4KS+IOCkheCkp+Ckv+CklSDgpJXgpL4g4KS14KWI4KSnIOCksuCkleCljeCkt+CljeCkryDgpKbgpLDgpY3gpJwg4KSV4KSw4KWH4KSC4KWkJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChmcmVxdWVuY3lUeXBlID09PSAnY3VzdG9tX2RheXMnICYmIHNjaGVkdWxlZERheXMubGVuZ3RoID09PSAwKSB7XG4gICAgICBzZXRFcnJvcign4KSV4KSuIOCkuOClhyDgpJXgpK4g4KSP4KSVIOCkpuCkv+CkqCDgpJXgpL4g4KSa4KSv4KSoIOCkleCksOClh+CkguClpCcpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIG9uU2F2ZSh7XG4gICAgICBuYW1lOiBuYW1lLnRyaW0oKSxcbiAgICAgIGNhdGVnb3J5LFxuICAgICAgaWNvbixcbiAgICAgIHRhcmdldFR5cGUsXG4gICAgICB0YXJnZXRWYWx1ZTogdGFyZ2V0VHlwZSA9PT0gJ2Jvb2xlYW4nID8gMSA6IE51bWJlcih0YXJnZXRWYWx1ZSksXG4gICAgICB1bml0OiB0YXJnZXRUeXBlID09PSAnYm9vbGVhbicgPyAn4KSs4KS+4KSwJyA6ICh1bml0LnRyaW0oKSB8fCAn4KSH4KSV4KS+4KSIJyksXG4gICAgICBmcmVxdWVuY3lUeXBlLFxuICAgICAgc2NoZWR1bGVkRGF5czogZnJlcXVlbmN5VHlwZSA9PT0gJ2RhaWx5JyA/IFswLCAxLCAyLCAzLCA0LCA1LCA2XSA6IHNjaGVkdWxlZERheXMsXG4gICAgICByZW1pbmRlclRpbWU6IHJlbWluZGVyVGltZS50cmltKCkgfHwgdW5kZWZpbmVkLFxuICAgICAgY29sb3IsXG4gICAgfSk7XG4gICAgb25DbG9zZSgpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1lbmQgc206aXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMCBzbTpwLTQgYmctYmxhY2svNjAgYmFja2Ryb3AtYmx1ci14cyBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMTUwXCI+XG4gICAgICA8ZGl2IFxuICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206bWF4LXctbGcgbWF4LWgtWzkydmhdIGZsZXggZmxleC1jb2wgYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAgZGFyazpib3JkZXItc3RvbmUtODAwIHJvdW5kZWQtdC0zeGwgc206cm91bmRlZC0zeGwgc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW5cIlxuICAgICAgICByb2xlPVwiZGlhbG9nXCJcbiAgICAgICAgYXJpYS1tb2RhbD1cInRydWVcIlxuICAgICAgPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTUgcHktNCBib3JkZXItYiBib3JkZXItc3RvbmUtMTAwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctc3RvbmUtNTAvNTAgZGFyazpiZy1zdG9uZS05MDAvNTBcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgICAge2luaXRpYWxIYWJpdCA/ICfgpIbgpKbgpKQg4KS44KSC4KSq4KS+4KSm4KS/4KSkIOCkleCksOClh+CkgicgOiAn4KSo4KSIIOCkhuCkpuCkpCDgpJzgpYvgpKHgpLzgpYfgpIInfVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAgICDgpIXgpKrgpKjgpYAg4KSm4KWI4KSo4KS/4KSVIOCkpuCkv+CkqOCkmuCksOCljeCkr+CkviDgpK7gpYfgpIIg4KSP4KSVIOCkuOCkleCkvuCksOCkvuCkpOCljeCkruCklSDgpJXgpKbgpK4g4KSc4KWL4KSh4KS84KWH4KSCXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXN0b25lLTQwMCBob3Zlcjp0ZXh0LXN0b25lLTYwMCBkYXJrOmhvdmVyOnRleHQtc3RvbmUtMjAwIHJvdW5kZWQtZnVsbCBob3ZlcjpiZy1zdG9uZS0xMDAgZGFyazpob3ZlcjpiZy1zdG9uZS04MDAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFggc2l6ZT17MjB9IC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBGb3JtIEJvZHkgKi99XG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC01IHNwYWNlLXktNVwiPlxuICAgICAgICAgIHtlcnJvciAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1yZWQtNTAgZGFyazpiZy1yZWQtOTUwLzQwIGJvcmRlciBib3JkZXItcmVkLTIwMCBkYXJrOmJvcmRlci1yZWQtODAwIHRleHQtcmVkLTcwMCBkYXJrOnRleHQtcmVkLTMwMCByb3VuZGVkLXhsIHRleHQtc20gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBIYWJpdCBOYW1lICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XG4gICAgICAgICAgICAgIOCkhuCkpuCkpCDgpJXgpL4g4KSo4KS+4KSuICpcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICB2YWx1ZT17bmFtZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0TmFtZShlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgc2V0RXJyb3IoJycpO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuCkieCkpuCkvi4gOCDgpJfgpL/gpLLgpL7gpLgg4KSq4KS+4KSo4KWAIOCkquClgOCkqOCkviwgMjAg4KSu4KS/4KSo4KSfIOCkleCkv+CkpOCkvuCkrCDgpKrgpKLgpLzgpKjgpL4uLi5cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtNCBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN0b25lLTMwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgYmctc3RvbmUtNTAgZGFyazpiZy1zdG9uZS04MDAvODAgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCBwbGFjZWhvbGRlci1zdG9uZS00MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWVtZXJhbGQtNjAwIHRleHQtc21cIlxuICAgICAgICAgICAgICBhdXRvRm9jdXNcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2F0ZWdvcnkgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTcwMCBkYXJrOnRleHQtc3RvbmUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8VGFnIHNpemU9ezE0fSAvPiDgpLbgpY3gpLDgpYfgpKPgpYAg4KSa4KWB4KSo4KWH4KSCXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgIHtDQVRFR09SSUVTLm1hcCgoY2F0KSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtjYXR9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhdGVnb3J5KGNhdCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5ID09PSBjYXRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTcwMCB0ZXh0LXdoaXRlIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zdG9uZS0xMDAgZGFyazpiZy1zdG9uZS04MDAgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBob3ZlcjpiZy1zdG9uZS0yMDAgZGFyazpob3ZlcjpiZy1zdG9uZS03MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Y2F0fVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEljb24gU2VsZWN0aW9uICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMS41XCI+XG4gICAgICAgICAgICAgIOCkhuCkh+CkleCkqCDgpJrgpYHgpKjgpYfgpIJcbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgc206Z3JpZC1jb2xzLTggZ2FwLTJcIj5cbiAgICAgICAgICAgICAge0FWQUlMQUJMRV9JQ09OUy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPXtpdGVtLmxhYmVsfVxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SWNvbihpdGVtLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMi41IHJvdW5kZWQteGwgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgICBpY29uID09PSBpdGVtLmlkXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC03MDAgdGV4dC13aGl0ZSByaW5nLTIgcmluZy1lbWVyYWxkLTUwMCBzaGFkb3cteHMnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDAgaG92ZXI6Ymctc3RvbmUtMjAwIGRhcms6aG92ZXI6Ymctc3RvbmUtNzAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEhhYml0SWNvbiBuYW1lPXtpdGVtLmlkfSBzaXplPXsyMH0gLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRydW5jYXRlIG1heC13LWZ1bGxcIj57aXRlbS5sYWJlbC5zcGxpdCgnICcpWzBdfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBUaGVtZSBDb2xvciAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxQYWxldHRlIHNpemU9ezE0fSAvPiDgpJXgpL7gpLDgpY3gpKEg4KSV4KS+IOCksOCkguCkl1xuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMi41XCI+XG4gICAgICAgICAgICAgIHtIQUJJVF9DT0xPUlMubWFwKChjKSA9PiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXtjLmlkfVxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb2xvcihjLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctNyBoLTcgcm91bmRlZC1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtjLmFjY2VudH0gJHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3IgPT09IGMuaWQgPyAncmluZy0zIHJpbmctb2Zmc2V0LTIgcmluZy1lbWVyYWxkLTYwMCBkYXJrOnJpbmctb2Zmc2V0LXN0b25lLTkwMCBzY2FsZS0xMTAnIDogJ29wYWNpdHktODAgaG92ZXI6b3BhY2l0eS0xMDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Y29sb3IgPT09IGMuaWQgJiYgPENoZWNrIHNpemU9ezE0fSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCIgLz59XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGFyZ2V0IFR5cGUgJiBWYWx1ZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IGJnLXN0b25lLTUwIGRhcms6Ymctc3RvbmUtODAwLzUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc3RvbmUtMjAwLzgwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTcwMCBkYXJrOnRleHQtc3RvbmUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIOCksuCkleCljeCkt+CljeCkryDgpJXgpL4g4KSq4KWN4KSw4KSV4KS+4KSwXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1zdG9uZS0yMDAgZGFyazpiZy1zdG9uZS03MDAgcm91bmRlZC1sZyBwLTAuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldFRhcmdldFR5cGUoJ2Jvb2xlYW4nKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGFyZ2V0VmFsdWUoMSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHJvdW5kZWQtbWQgdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXRUeXBlID09PSAnYm9vbGVhbidcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwIHNoYWRvdy14cyBmb250LWJvbGQnXG4gICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTQwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIOCkueCkvuCkgSAvIOCkqOCkvlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VGFyZ2V0VHlwZSgnbnVtZXJpYycpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHJvdW5kZWQtbWQgdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICB0YXJnZXRUeXBlID09PSAnbnVtZXJpYydcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwIHNoYWRvdy14cyBmb250LWJvbGQnXG4gICAgICAgICAgICAgICAgICAgICAgOiAndGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTQwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIOCkruCkvuCkpOCljeCksOCkvuCkpOCljeCkruCklVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7dGFyZ2V0VHlwZSA9PT0gJ251bWVyaWMnID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTMgcHQtMVwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIOCkpuCliOCkqOCkv+CklSDgpLLgpJXgpY3gpLfgpY3gpK8g4KS44KSC4KSW4KWN4KSv4KS+XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICBtaW49XCIxXCJcbiAgICAgICAgICAgICAgICAgICAgbWF4PVwiMTAwMDAwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3RhcmdldFZhbHVlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRhcmdldFZhbHVlKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zdG9uZS0zMDAgZGFyazpib3JkZXItc3RvbmUtNzAwIGJnLXdoaXRlIGRhcms6Ymctc3RvbmUtODAwIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgdGV4dC1zbSBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMXB4XSB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAg4KSH4KSV4KS+4KSIIChVbml0KVxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXt1bml0fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVuaXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIuCkieCkpuCkvi4g4KSX4KS/4KSy4KS+4KS4LCDgpK7gpL/gpKjgpJ8sIOCkquClh+CknFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN0b25lLTMwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgYmctd2hpdGUgZGFyazpiZy1zdG9uZS04MDAgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCB0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAgICAgICAg4KSq4KWN4KSw4KSk4KS/4KSm4KS/4KSoIOCkleClh+CkteCksiDgpI/gpJUg4KSs4KS+4KSwIOCkquClguCksOCkvi/gpIXgpKfgpYLgpLDgpL4g4KSa4KS/4KS54KWN4KSo4KS/4KSkIOCkleCksOCkqOCkviDgpLngpYvgpJfgpL4gKOCkieCkpuCkvi4g4KS44KWB4KSs4KS5IOCkieCkoOCkqOCkviwg4KSm4KS14KS+IOCksuClh+CkqOCkvingpaRcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBGcmVxdWVuY3kgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTcwMCBkYXJrOnRleHQtc3RvbmUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgc2l6ZT17MTR9IC8+IOCkhuCkteClg+CkpOCljeCkpOCkvyAo4KSm4KS/4KSoKVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yIG1iLTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIHNldEZyZXF1ZW5jeVR5cGUoJ2RhaWx5Jyk7XG4gICAgICAgICAgICAgICAgICBzZXRTY2hlZHVsZWREYXlzKFswLCAxLCAyLCAzLCA0LCA1LCA2XSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTMgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJvcmRlciB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICBmcmVxdWVuY3lUeXBlID09PSAnZGFpbHknXG4gICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1lbWVyYWxkLTYwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvNDAgdGV4dC1lbWVyYWxkLTgwMCBkYXJrOnRleHQtZW1lcmFsZC0zMDAgZm9udC1ib2xkJ1xuICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTcwMCBiZy1zdG9uZS01MCBkYXJrOmJnLXN0b25lLTgwMC81MCB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtNDAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg4KS54KSwIOCkpuCkv+CkqCAo4KSm4KWI4KSo4KS/4KSVKVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZyZXF1ZW5jeVR5cGUoJ2N1c3RvbV9kYXlzJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC0zIHJvdW5kZWQteGwgdGV4dC14cyBmb250LW1lZGl1bSBib3JkZXIgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgZnJlcXVlbmN5VHlwZSA9PT0gJ2N1c3RvbV9kYXlzJ1xuICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItZW1lcmFsZC02MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwLzQwIHRleHQtZW1lcmFsZC04MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwIGZvbnQtYm9sZCdcbiAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgYmctc3RvbmUtNTAgZGFyazpiZy1zdG9uZS04MDAvNTAgdGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTQwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIOCkuOCkquCljeCkpOCkvuCkuSDgpJXgpYcg4KSa4KWB4KSo4KWHIOCkueClgeCkjyDgpKbgpL/gpKhcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2ZyZXF1ZW5jeVR5cGUgPT09ICdjdXN0b21fZGF5cycgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGdhcC0xIHAtMiBiZy1zdG9uZS01MCBkYXJrOmJnLXN0b25lLTgwMC81MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTcwMFwiPlxuICAgICAgICAgICAgICAgIHtEQVlTX09GX1dFRUsubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2NoZWR1bGVkRGF5cy5pbmNsdWRlcyhpdGVtLmRheSk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLmRheX1cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVEYXkoaXRlbS5kYXkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXgtMSBweS0xLjUgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgc2hhZG93LXhzJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zdG9uZS0yMDAgZGFyazpiZy1zdG9uZS03MDAgdGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTQwMCBob3ZlcjpiZy1zdG9uZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sYWJlbH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmVtaW5kZXIgVGltZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTEuNVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxDbG9jayBzaXplPXsxNH0gLz4g4KSm4KWI4KSo4KS/4KSVIOCksOCkv+CkruCkvuCkh+CkguCkoeCksCDgpLjgpK7gpK8gKOCkteCliOCkleCksuCljeCkquCkv+CklSlcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBnYXAtMiBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRpbWVcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtyZW1pbmRlclRpbWV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSZW1pbmRlclRpbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweC00IHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN0b25lLTMwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgYmctc3RvbmUtNTAgZGFyazpiZy1zdG9uZS04MDAvODAgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICB7cmVtaW5kZXJUaW1lICYmIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlbWluZGVyVGltZSgnJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXN0b25lLTUwMCBob3Zlcjp0ZXh0LXN0b25lLTcwMCBkYXJrOmhvdmVyOnRleHQtc3RvbmUtMzAwIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zdG9uZS0zMDAgZGFyazpib3JkZXItc3RvbmUtNzAwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDgpLngpJ/gpL7gpI/gpIJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LVsxMXB4XSB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+XG4gICAgICAgICAgICAgIOCkr+CkuSDgpLjgpK7gpK8g4KS54KWL4KSo4KWHIOCkquCksCDgpJDgpKog4KSu4KWH4KSCIOCksOCkv+CkruCkvuCkh+CkguCkoeCksCDgpLjgpILgpJXgpYfgpKQg4KSq4KWN4KSw4KS+4KSq4KWN4KSkIOCkueCli+Ckl+CkvuClpFxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFN1Ym1pdCBCdXR0b25zICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGdhcC0zXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMyBweC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zdG9uZS0zMDAgZGFyazpib3JkZXItc3RvbmUtNzAwIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDAgZm9udC1zZW1pYm9sZCB0ZXh0LXNtIGhvdmVyOmJnLXN0b25lLTEwMCBkYXJrOmhvdmVyOmJnLXN0b25lLTgwMCB0cmFuc2l0aW9uIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIOCksOCkpuCljeCkpiDgpJXgpLDgpYfgpIJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTMgcHgtNCByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNzAwIGhvdmVyOmJnLWVtZXJhbGQtODAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtc20gc2hhZG93LW1kIHRyYW5zaXRpb24gYWN0aXZlOnNjYWxlLTk1IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENoZWNrIHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICB7aW5pdGlhbEhhYml0ID8gJ+CkrOCkpuCksuCkvuCktSDgpLjgpLngpYfgpJzgpYfgpIInIDogJ+CkhuCkpuCkpCDgpJzgpYvgpKHgpLzgpYfgpIInfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==