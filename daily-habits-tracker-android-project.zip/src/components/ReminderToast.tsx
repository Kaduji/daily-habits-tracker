const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Bell, X, Check } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { HabitIcon } from "/src/components/HabitIcon.tsx";
var _jsxFileName = "/app/applet/src/components/ReminderToast.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const ReminderToast = ({ habit, onClose, onComplete }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed top-16 left-4 right-4 z-50 max-w-md mx-auto animate-in slide-in-from-top duration-200",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "p-4 rounded-2xl bg-white dark:bg-stone-900 border-2 border-emerald-500 shadow-2xl flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-3 min-w-0",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ _jsxDEV(HabitIcon, {
						name: habit.icon,
						size: 20
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 21,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-400",
						children: [/* @__PURE__ */ _jsxDEV(Bell, { size: 12 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"रिमाइंडर समय! (",
							habit.reminderTime,
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h4", {
						className: "text-sm font-black text-stone-900 dark:text-stone-100 truncate",
						children: habit.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1.5 shrink-0",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: onComplete,
					className: "p-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1 transition cursor-pointer",
					title: "पूरा करें",
					children: [/* @__PURE__ */ _jsxDEV(Check, { size: 14 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hidden xs:inline",
						children: "पूरा"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "p-2 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition",
					title: "बंद करें",
					children: /* @__PURE__ */ _jsxDEV(X, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsTUFBTSxHQUFHLGFBQWE7QUFFL0IsU0FBUyxpQkFBaUI7OztBQVExQixPQUFPLE1BQU0saUJBQStDLEVBQzFELE9BQ0EsU0FDQSxpQkFDSTtDQUNKLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsV0FBRDtNQUFXLE1BQU0sTUFBTTtNQUFNLE1BQU07S0FBSzs7Ozs7SUFDckM7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sTUFBTSxHQUFLOzs7O2dCQUNqQix3QkFBQyxRQUFEO09BQU07T0FBZ0IsTUFBTTtPQUFhO01BQU87Ozs7Y0FDN0M7Ozs7O2VBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsTUFBTTtLQUNMOzs7O2FBQ0Q7Ozs7O1lBQ0Y7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLE9BQU07ZUFIUixDQUtFLHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7ZUFDbEIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1CO0tBQVU7Ozs7YUFDdkM7Ozs7O2NBQ1Isd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO0tBQ1YsT0FBTTtlQUVOLHdCQUFDLEdBQUQsRUFBRyxNQUFNLEdBQUs7Ozs7O0lBQ1I7Ozs7WUFDTDs7Ozs7V0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUmVtaW5kZXJUb2FzdC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEJlbGwsIFgsIENoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IEhhYml0IH0gZnJvbSAnLi4vdHlwZXMvaGFiaXQnO1xuaW1wb3J0IHsgSGFiaXRJY29uIH0gZnJvbSAnLi9IYWJpdEljb24nO1xuXG5pbnRlcmZhY2UgUmVtaW5kZXJUb2FzdFByb3BzIHtcbiAgaGFiaXQ6IEhhYml0O1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvbkNvbXBsZXRlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgUmVtaW5kZXJUb2FzdDogUmVhY3QuRkM8UmVtaW5kZXJUb2FzdFByb3BzPiA9ICh7XG4gIGhhYml0LFxuICBvbkNsb3NlLFxuICBvbkNvbXBsZXRlLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgdG9wLTE2IGxlZnQtNCByaWdodC00IHotNTAgbWF4LXctbWQgbXgtYXV0byBhbmltYXRlLWluIHNsaWRlLWluLWZyb20tdG9wIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0yeGwgYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgYm9yZGVyLTIgYm9yZGVyLWVtZXJhbGQtNTAwIHNoYWRvdy0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgbWluLXctMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCB0ZXh0LWVtZXJhbGQtNzAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMFwiPlxuICAgICAgICAgICAgPEhhYml0SWNvbiBuYW1lPXtoYWJpdC5pY29ufSBzaXplPXsyMH0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgIDxCZWxsIHNpemU9ezEyfSAvPlxuICAgICAgICAgICAgICA8c3Bhbj7gpLDgpL/gpK7gpL7gpIfgpILgpKHgpLAg4KS44KSu4KSvISAoe2hhYml0LnJlbWluZGVyVGltZX0pPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJsYWNrIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAge2hhYml0Lm5hbWV9XG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNvbXBsZXRlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctZW1lcmFsZC03MDAgaG92ZXI6YmctZW1lcmFsZC04MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwi4KSq4KWC4KSw4KS+IOCkleCksOClh+CkglwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENoZWNrIHNpemU9ezE0fSAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHhzOmlubGluZVwiPuCkquClguCksOCkvjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtc3RvbmUtNDAwIGhvdmVyOnRleHQtc3RvbmUtNjAwIGRhcms6aG92ZXI6dGV4dC1zdG9uZS0yMDAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICB0aXRsZT1cIuCkrOCkguCkpiDgpJXgpLDgpYfgpIJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIHNpemU9ezE2fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==