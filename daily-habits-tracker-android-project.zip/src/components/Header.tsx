const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Plus, Sun, Moon, Sparkles, ChevronLeft, ChevronRight, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { formatDateToHindi, getTodayDateString } from "/src/services/storageService.ts";
var _jsxFileName = "/app/applet/src/components/Header.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const Header = ({ currentDate, onDateChange, onOpenAddModal, theme, onToggleTheme }) => {
	const todayStr = getTodayDateString();
	const isToday = currentDate === todayStr;
	const navigateDate = (deltaDays) => {
		const [y, m, d] = currentDate.split("-").map(Number);
		const date = new Date(y, m - 1, d);
		date.setDate(date.getDate() + deltaDays);
		// Don't allow navigating into future dates
		const today = new Date();
		today.setHours(0, 0, 0, 0);
		if (date > today) return;
		const newYear = date.getFullYear();
		const newMonth = String(date.getMonth() + 1).padStart(2, "0");
		const newDay = String(date.getDate()).padStart(2, "0");
		onDateChange(`${newYear}-${newMonth}-${newDay}`);
	};
	const goToToday = () => {
		onDateChange(todayStr);
	};
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "sticky top-0 z-30 bg-emerald-900 text-white shadow-md border-b border-emerald-800",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-md mx-auto px-4 pt-3.5 pb-2.5 flex items-center justify-between",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "w-9 h-9 rounded-2xl bg-emerald-800/80 border border-emerald-700/60 flex items-center justify-center text-emerald-300 shadow-inner",
					children: /* @__PURE__ */ _jsxDEV(Sparkles, {
						size: 20,
						className: "animate-pulse"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-base font-extrabold tracking-tight leading-tight flex items-center gap-1.5 text-white",
					children: "मेरी अच्छी आदतें"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-[11px] font-medium text-emerald-200/90 leading-none",
					children: "Daily Habits Tracker"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1.5",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: onToggleTheme,
					className: "w-8 h-8 rounded-full bg-emerald-800/60 hover:bg-emerald-800 border border-emerald-700/50 flex items-center justify-center text-emerald-100 transition active:scale-95",
					title: theme === "dark" ? "लाइट मोड" : "डार्क मोड",
					"aria-label": "थीम बदलें",
					children: theme === "dark" ? /* @__PURE__ */ _jsxDEV(Sun, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 33
					}, this) : /* @__PURE__ */ _jsxDEV(Moon, { size: 16 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 53
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onOpenAddModal,
					className: "h-8 px-2.5 rounded-full bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-xs flex items-center gap-1 shadow-sm transition active:scale-95 cursor-pointer",
					children: [/* @__PURE__ */ _jsxDEV(Plus, {
						size: 15,
						strokeWidth: 3
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 77,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hidden xs:inline",
						children: "नई आदत"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-emerald-950/50 border-t border-emerald-800/50 px-4 py-2",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-md mx-auto flex items-center justify-between text-xs",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigateDate(-1),
						className: "p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800/60 transition active:scale-90 flex items-center",
						title: "पिछला दिन",
						children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 91,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold text-emerald-50",
							children: formatDateToHindi(currentDate)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 13
						}, this), !isToday && /* @__PURE__ */ _jsxDEV("button", {
							onClick: goToToday,
							className: "px-2 py-0.5 rounded-md bg-emerald-800 text-[10px] font-bold text-emerald-200 hover:text-white flex items-center gap-1",
							title: "आज पर जाएं",
							children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { size: 10 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 17
							}, this), " आज"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => navigateDate(1),
						disabled: isToday,
						className: `p-1 rounded-lg transition flex items-center ${isToday ? "text-emerald-700 cursor-not-allowed opacity-30" : "text-emerald-200 hover:text-white hover:bg-emerald-800/60 active:scale-90"}`,
						title: "अगला दिन",
						children: /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 44,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVSxhQUFhLGNBQWMsaUJBQWlCO0FBQ2hGLFNBQVMsbUJBQW1CLDBCQUEwQjs7O0FBVXRELE9BQU8sTUFBTSxVQUFpQyxFQUM1QyxhQUNBLGNBQ0EsZ0JBQ0EsT0FDQSxvQkFDSTtDQUNKLE1BQU0sV0FBVyxtQkFBbUI7Q0FDcEMsTUFBTSxVQUFVLGdCQUFnQjtDQUVoQyxNQUFNLGdCQUFnQixjQUFzQjtFQUMxQyxNQUFNLENBQUMsR0FBRyxHQUFHLEtBQUssWUFBWSxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksTUFBTTtFQUNuRCxNQUFNLE9BQU8sSUFBSSxLQUFLLEdBQUcsSUFBSSxHQUFHLENBQUM7RUFDakMsS0FBSyxRQUFRLEtBQUssUUFBUSxJQUFJLFNBQVM7O0VBR3ZDLE1BQU0sUUFBUSxJQUFJLEtBQUs7RUFDdkIsTUFBTSxTQUFTLEdBQUcsR0FBRyxHQUFHLENBQUM7RUFDekIsSUFBSSxPQUFPLE9BQU87RUFFbEIsTUFBTSxVQUFVLEtBQUssWUFBWTtFQUNqQyxNQUFNLFdBQVcsT0FBTyxLQUFLLFNBQVMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztFQUM1RCxNQUFNLFNBQVMsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7RUFDckQsYUFBYSxHQUFHLFFBQVEsR0FBRyxTQUFTLEdBQUcsUUFBUTtDQUNqRDtDQUVBLE1BQU0sa0JBQWtCO0VBQ3RCLGFBQWEsUUFBUTtDQUN2QjtDQUVBLE9BQ0Usd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFBbEIsQ0FFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUFVLE1BQU07TUFBSSxXQUFVO0tBQWlCOzs7OztJQUM1Qzs7OztjQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUE2RjtJQUV2Rzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTJEO0lBRXJFOzs7O1lBQ0E7Ozs7WUFDRjs7Ozs7YUFFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO0tBQ1YsT0FBTyxVQUFVLFNBQVMsYUFBYTtLQUN2QyxjQUFXO2VBRVYsVUFBVSxTQUFTLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7Z0JBQUksd0JBQUMsTUFBRCxFQUFNLE1BQU0sR0FBSzs7Ozs7SUFDbkQ7Ozs7Y0FHUix3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFGWixDQUlFLHdCQUFDLE1BQUQ7TUFBTSxNQUFNO01BQUksYUFBYTtLQUFJOzs7O2VBQ2pDLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFtQjtLQUFZOzs7O2FBQ3pDOzs7OztZQUNMOzs7OztXQUNGOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGFBQWEsQ0FBQyxDQUFDO01BQzlCLFdBQVU7TUFDVixPQUFNO2dCQUVOLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O0tBQ2xCOzs7OztLQUVSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2Isa0JBQWtCLFdBQVc7TUFDMUI7Ozs7Z0JBQ0wsQ0FBQyxXQUNBLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxXQUFELEVBQVcsTUFBTSxHQUFLOzs7O2lCQUFDLEtBQ2pCOzs7OztjQUVQOzs7Ozs7S0FFTCx3QkFBQyxVQUFEO01BQ0UsZUFBZSxhQUFhLENBQUM7TUFDN0IsVUFBVTtNQUNWLFdBQVcsK0NBQ1QsVUFDSSxtREFDQTtNQUVOLE9BQU07Z0JBRU4sd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7S0FDbkI7Ozs7O0lBQ0w7Ozs7OztFQUNGOzs7O1VBQ0M7Ozs7OztBQUVaIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhlYWRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFBsdXMsIFN1biwgTW9vbiwgU3BhcmtsZXMsIENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQsIFJvdGF0ZUNjdyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBmb3JtYXREYXRlVG9IaW5kaSwgZ2V0VG9kYXlEYXRlU3RyaW5nIH0gZnJvbSAnLi4vc2VydmljZXMvc3RvcmFnZVNlcnZpY2UnO1xuXG5pbnRlcmZhY2UgSGVhZGVyUHJvcHMge1xuICBjdXJyZW50RGF0ZTogc3RyaW5nO1xuICBvbkRhdGVDaGFuZ2U6IChuZXdEYXRlOiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uT3BlbkFkZE1vZGFsOiAoKSA9PiB2b2lkO1xuICB0aGVtZTogJ2xpZ2h0JyB8ICdkYXJrJztcbiAgb25Ub2dnbGVUaGVtZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEhlYWRlcjogUmVhY3QuRkM8SGVhZGVyUHJvcHM+ID0gKHtcbiAgY3VycmVudERhdGUsXG4gIG9uRGF0ZUNoYW5nZSxcbiAgb25PcGVuQWRkTW9kYWwsXG4gIHRoZW1lLFxuICBvblRvZ2dsZVRoZW1lLFxufSkgPT4ge1xuICBjb25zdCB0b2RheVN0ciA9IGdldFRvZGF5RGF0ZVN0cmluZygpO1xuICBjb25zdCBpc1RvZGF5ID0gY3VycmVudERhdGUgPT09IHRvZGF5U3RyO1xuXG4gIGNvbnN0IG5hdmlnYXRlRGF0ZSA9IChkZWx0YURheXM6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IFt5LCBtLCBkXSA9IGN1cnJlbnREYXRlLnNwbGl0KCctJykubWFwKE51bWJlcik7XG4gICAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKHksIG0gLSAxLCBkKTtcbiAgICBkYXRlLnNldERhdGUoZGF0ZS5nZXREYXRlKCkgKyBkZWx0YURheXMpO1xuICAgIFxuICAgIC8vIERvbid0IGFsbG93IG5hdmlnYXRpbmcgaW50byBmdXR1cmUgZGF0ZXNcbiAgICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XG4gICAgdG9kYXkuc2V0SG91cnMoMCwgMCwgMCwgMCk7XG4gICAgaWYgKGRhdGUgPiB0b2RheSkgcmV0dXJuO1xuXG4gICAgY29uc3QgbmV3WWVhciA9IGRhdGUuZ2V0RnVsbFllYXIoKTtcbiAgICBjb25zdCBuZXdNb250aCA9IFN0cmluZyhkYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCAnMCcpO1xuICAgIGNvbnN0IG5ld0RheSA9IFN0cmluZyhkYXRlLmdldERhdGUoKSkucGFkU3RhcnQoMiwgJzAnKTtcbiAgICBvbkRhdGVDaGFuZ2UoYCR7bmV3WWVhcn0tJHtuZXdNb250aH0tJHtuZXdEYXl9YCk7XG4gIH07XG5cbiAgY29uc3QgZ29Ub1RvZGF5ID0gKCkgPT4ge1xuICAgIG9uRGF0ZUNoYW5nZSh0b2RheVN0cik7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cInN0aWNreSB0b3AtMCB6LTMwIGJnLWVtZXJhbGQtOTAwIHRleHQtd2hpdGUgc2hhZG93LW1kIGJvcmRlci1iIGJvcmRlci1lbWVyYWxkLTgwMFwiPlxuICAgICAgey8qIFRvcCBCYXIgd2l0aCBCcmFuZCBhbmQgUXVpY2sgQWN0aW9ucyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgbXgtYXV0byBweC00IHB0LTMuNSBwYi0yLjUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy05IGgtOSByb3VuZGVkLTJ4bCBiZy1lbWVyYWxkLTgwMC84MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNzAwLzYwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC0zMDAgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICA8U3BhcmtsZXMgc2l6ZT17MjB9IGNsYXNzTmFtZT1cImFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IGxlYWRpbmctdGlnaHQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgIOCkruClh+CksOClgCDgpIXgpJrgpY3gpJvgpYAg4KSG4KSm4KSk4KWH4KSCXG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1lbWVyYWxkLTIwMC85MCBsZWFkaW5nLW5vbmVcIj5cbiAgICAgICAgICAgICAgRGFpbHkgSGFiaXRzIFRyYWNrZXJcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgey8qIFRoZW1lIHN3aXRjaCAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvblRvZ2dsZVRoZW1lfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC04MDAvNjAgaG92ZXI6YmctZW1lcmFsZC04MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTcwMC81MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWVtZXJhbGQtMTAwIHRyYW5zaXRpb24gYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICAgIHRpdGxlPXt0aGVtZSA9PT0gJ2RhcmsnID8gJ+CksuCkvuCkh+CknyDgpK7gpYvgpKEnIDogJ+CkoeCkvuCksOCljeCklSDgpK7gpYvgpKEnfVxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIuCkpeClgOCkriDgpKzgpKbgpLLgpYfgpIJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0aGVtZSA9PT0gJ2RhcmsnID8gPFN1biBzaXplPXsxNn0gLz4gOiA8TW9vbiBzaXplPXsxNn0gLz59XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogUXVpY2sgQWRkIEhhYml0ICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlbkFkZE1vZGFsfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHB4LTIuNSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDAgaG92ZXI6YmctZW1lcmFsZC00MDAgdGV4dC1lbWVyYWxkLTk1MCBmb250LWJvbGQgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBzaGFkb3ctc20gdHJhbnNpdGlvbiBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQbHVzIHNpemU9ezE1fSBzdHJva2VXaWR0aD17M30gLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiB4czppbmxpbmVcIj7gpKjgpIgg4KSG4KSm4KSkPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogRGF0ZSBOYXZpZ2F0aW9uIEJhciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC05NTAvNTAgYm9yZGVyLXQgYm9yZGVyLWVtZXJhbGQtODAwLzUwIHB4LTQgcHktMlwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LW1kIG14LWF1dG8gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZURhdGUoLTEpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQtbGcgdGV4dC1lbWVyYWxkLTIwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLWVtZXJhbGQtODAwLzYwIHRyYW5zaXRpb24gYWN0aXZlOnNjYWxlLTkwIGZsZXggaXRlbXMtY2VudGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwi4KSq4KS/4KSb4KSy4KS+IOCkpuCkv+CkqFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPENoZXZyb25MZWZ0IHNpemU9ezE4fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWVtZXJhbGQtNTBcIj5cbiAgICAgICAgICAgICAge2Zvcm1hdERhdGVUb0hpbmRpKGN1cnJlbnREYXRlKX1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIHshaXNUb2RheSAmJiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtnb1RvVG9kYXl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZC1tZCBiZy1lbWVyYWxkLTgwMCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTIwMCBob3Zlcjp0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIuCkhuCknCDgpKrgpLAg4KSc4KS+4KSP4KSCXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgc2l6ZT17MTB9IC8+IOCkhuCknFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZURhdGUoMSl9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNUb2RheX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMSByb3VuZGVkLWxnIHRyYW5zaXRpb24gZmxleCBpdGVtcy1jZW50ZXIgJHtcbiAgICAgICAgICAgICAgaXNUb2RheVxuICAgICAgICAgICAgICAgID8gJ3RleHQtZW1lcmFsZC03MDAgY3Vyc29yLW5vdC1hbGxvd2VkIG9wYWNpdHktMzAnXG4gICAgICAgICAgICAgICAgOiAndGV4dC1lbWVyYWxkLTIwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLWVtZXJhbGQtODAwLzYwIGFjdGl2ZTpzY2FsZS05MCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgdGl0bGU9XCLgpIXgpJfgpLLgpL4g4KSm4KS/4KSoXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHNpemU9ezE4fSAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufTtcbiJdfQ==