const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { AlertTriangle } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
var _jsxFileName = "/app/applet/src/components/ConfirmModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const ConfirmModal = ({ isOpen, title, message, confirmLabel = "हाँ, जारी रखें", cancelLabel = "रद्द करें", isDestructive = false, onConfirm, onCancel }) => {
	if (!isOpen) return null;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "w-full max-w-sm bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-6 shadow-2xl space-y-4",
			role: "dialog",
			"aria-modal": "true",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: `p-2.5 rounded-2xl shrink-0 ${isDestructive ? "bg-red-100 text-red-600 dark:bg-red-950/60 dark:text-red-400" : "bg-amber-100 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400"}`,
					children: /* @__PURE__ */ _jsxDEV(AlertTriangle, { size: 24 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "text-lg font-bold text-stone-900 dark:text-stone-100",
						children: title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "mt-1 text-sm text-stone-600 dark:text-stone-400 leading-relaxed",
						children: message
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "flex gap-2.5 pt-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onCancel,
					className: "flex-1 py-2.5 px-4 rounded-xl border border-stone-300 dark:border-stone-700 text-stone-700 dark:text-stone-300 font-medium text-sm hover:bg-stone-100 dark:hover:bg-stone-800 transition active:scale-95 cursor-pointer",
					children: cancelLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: onConfirm,
					className: `flex-1 py-2.5 px-4 rounded-xl font-medium text-sm text-white shadow-sm transition active:scale-95 cursor-pointer ${isDestructive ? "bg-red-600 hover:bg-red-700" : "bg-emerald-700 hover:bg-emerald-800"}`,
					children: confirmLabel
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMscUJBQXdCOzs7QUFhakMsT0FBTyxNQUFNLGdCQUE2QyxFQUN4RCxRQUNBLE9BQ0EsU0FDQSxlQUFlLGtCQUNmLGNBQWMsYUFDZCxnQkFBZ0IsT0FDaEIsV0FDQSxlQUNJO0NBQ0osSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUNFLFdBQVU7R0FDVixNQUFLO0dBQ0wsY0FBVzthQUhiLENBS0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLDhCQUE4QixnQkFBZ0IsaUVBQWlFO2VBQzdILHdCQUFDLGVBQUQsRUFBZSxNQUFNLEdBQUs7Ozs7O0lBQ3ZCOzs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUNYO0tBQ0M7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFDVjtLQUNBOzs7O2FBQ0E7Ozs7O1lBQ0Y7Ozs7O2FBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsU0FBUztLQUNULFdBQVU7ZUFFVDtJQUNLOzs7O2NBQ1Isd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxTQUFTO0tBQ1QsV0FBVyxvSEFDVCxnQkFDSSxnQ0FDQTtlQUdMO0lBQ0s7Ozs7WUFDTDs7Ozs7V0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ29uZmlybU1vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQWxlcnRUcmlhbmdsZSwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBDb25maXJtTW9kYWxQcm9wcyB7XG4gIGlzT3BlbjogYm9vbGVhbjtcbiAgdGl0bGU6IHN0cmluZztcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBjb25maXJtTGFiZWw/OiBzdHJpbmc7XG4gIGNhbmNlbExhYmVsPzogc3RyaW5nO1xuICBpc0Rlc3RydWN0aXZlPzogYm9vbGVhbjtcbiAgb25Db25maXJtOiAoKSA9PiB2b2lkO1xuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IENvbmZpcm1Nb2RhbDogUmVhY3QuRkM8Q29uZmlybU1vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICB0aXRsZSxcbiAgbWVzc2FnZSxcbiAgY29uZmlybUxhYmVsID0gJ+CkueCkvuCkgSwg4KSc4KS+4KSw4KWAIOCksOCkluClh+CkgicsXG4gIGNhbmNlbExhYmVsID0gJ+CksOCkpuCljeCkpiDgpJXgpLDgpYfgpIInLFxuICBpc0Rlc3RydWN0aXZlID0gZmFsc2UsXG4gIG9uQ29uZmlybSxcbiAgb25DYW5jZWwsXG59KSA9PiB7XG4gIGlmICghaXNPcGVuKSByZXR1cm4gbnVsbDtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay82MCBiYWNrZHJvcC1ibHVyLXhzIGFuaW1hdGUtaW4gZmFkZS1pbiBkdXJhdGlvbi0xNTBcIj5cbiAgICAgIDxkaXYgXG4gICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1zbSBiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMCBkYXJrOmJvcmRlci1zdG9uZS04MDAgcm91bmRlZC0zeGwgcC02IHNoYWRvdy0yeGwgc3BhY2UteS00XCJcbiAgICAgICAgcm9sZT1cImRpYWxvZ1wiXG4gICAgICAgIGFyaWEtbW9kYWw9XCJ0cnVlXCJcbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTIuNSByb3VuZGVkLTJ4bCBzaHJpbmstMCAke2lzRGVzdHJ1Y3RpdmUgPyAnYmctcmVkLTEwMCB0ZXh0LXJlZC02MDAgZGFyazpiZy1yZWQtOTUwLzYwIGRhcms6dGV4dC1yZWQtNDAwJyA6ICdiZy1hbWJlci0xMDAgdGV4dC1hbWJlci02MDAgZGFyazpiZy1hbWJlci05NTAvNjAgZGFyazp0ZXh0LWFtYmVyLTQwMCd9YH0+XG4gICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXsyNH0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgICAge3RpdGxlfVxuICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTEgdGV4dC1zbSB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICB7bWVzc2FnZX1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yLjUgcHQtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25DYW5jZWx9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4LTEgcHktMi41IHB4LTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXN0b25lLTMwMCBkYXJrOmJvcmRlci1zdG9uZS03MDAgdGV4dC1zdG9uZS03MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBmb250LW1lZGl1bSB0ZXh0LXNtIGhvdmVyOmJnLXN0b25lLTEwMCBkYXJrOmhvdmVyOmJnLXN0b25lLTgwMCB0cmFuc2l0aW9uIGFjdGl2ZTpzY2FsZS05NSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2NhbmNlbExhYmVsfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgb25DbGljaz17b25Db25maXJtfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleC0xIHB5LTIuNSBweC00IHJvdW5kZWQteGwgZm9udC1tZWRpdW0gdGV4dC1zbSB0ZXh0LXdoaXRlIHNoYWRvdy1zbSB0cmFuc2l0aW9uIGFjdGl2ZTpzY2FsZS05NSBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICBpc0Rlc3RydWN0aXZlXG4gICAgICAgICAgICAgICAgPyAnYmctcmVkLTYwMCBob3ZlcjpiZy1yZWQtNzAwJ1xuICAgICAgICAgICAgICAgIDogJ2JnLWVtZXJhbGQtNzAwIGhvdmVyOmJnLWVtZXJhbGQtODAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge2NvbmZpcm1MYWJlbH1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=