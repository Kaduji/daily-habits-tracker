const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=768266e3";
import { Flame, Trophy, TrendingUp, Calendar as CalendarIcon, ChevronLeft, ChevronRight, CheckCircle2, Award, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=768266e3";
import { HabitIcon, getColorScheme } from "/src/components/HabitIcon.tsx";
import { calculateOverallMetrics, getWeeklyActivity, getMonthHeatmap, calculateHabitStreak } from "/src/services/streakService.ts";
import { formatDateToHindi, getTodayDateString } from "/src/services/storageService.ts";
var _jsxFileName = "/app/applet/src/components/ProgressTab.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=768266e3";
export const ProgressTab = ({ habits, history }) => {
	const today = new Date();
	const [selectedYear, setSelectedYear] = useState(today.getFullYear());
	const [selectedMonth, setSelectedMonth] = useState(today.getMonth());
	const [selectedHeatmapDay, setSelectedHeatmapDay] = useState(getTodayDateString());
	const activeHabits = habits.filter((h) => !h.isPaused);
	const metrics = calculateOverallMetrics(habits, history);
	const weeklyActivity = getWeeklyActivity(habits, history);
	const heatmapDays = getMonthHeatmap(selectedYear, selectedMonth, habits, history);
	const hindiMonths = [
		"जनवरी",
		"फ़रवरी",
		"मार्च",
		"अप्रैल",
		"मई",
		"जून",
		"जुलाई",
		"अगस्त",
		"सितंबर",
		"अक्टूबर",
		"नवंबर",
		"दिसंबर"
	];
	const changeMonth = (delta) => {
		let nextMonth = selectedMonth + delta;
		let nextYear = selectedYear;
		if (nextMonth < 0) {
			nextMonth = 11;
			nextYear--;
		} else if (nextMonth > 11) {
			nextMonth = 0;
			nextYear++;
		}
		setSelectedMonth(nextMonth);
		setSelectedYear(nextYear);
	};
	const getIntensityClass = (level) => {
		switch (level) {
			case 4: return "bg-emerald-600 text-white font-bold ring-1 ring-emerald-500";
			case 3: return "bg-emerald-500/80 text-white font-medium";
			case 2: return "bg-emerald-400/60 text-stone-900 dark:text-stone-100 font-medium";
			case 1: return "bg-emerald-200 dark:bg-emerald-950/70 text-stone-800 dark:text-stone-300";
			default: return "bg-stone-100 dark:bg-stone-800/60 text-stone-400 dark:text-stone-500";
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "pb-24 pt-4 px-4 max-w-md mx-auto space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
				className: "text-xl font-black text-stone-900 dark:text-stone-100",
				children: "प्रगति और स्ट्रीक रिपोर्ट"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs text-stone-500 dark:text-stone-400",
				children: "अपनी निरंतरता और आदतों का समग्र विश्लेषण"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 9
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-emerald-600 dark:text-emerald-400",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-stone-500 dark:text-stone-400",
									children: "आज की दर"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(CheckCircle2, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 91,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-stone-900 dark:text-stone-100",
								children: [metrics.todayPercentage, "%"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-stone-500 dark:text-stone-400",
								children: [
									metrics.todayCompletedCount,
									" / ",
									metrics.todayTotalCount,
									" पूर्ण"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-blue-600 dark:text-blue-400",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-stone-500 dark:text-stone-400",
									children: "साप्ताहिक दर"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(TrendingUp, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-stone-900 dark:text-stone-100",
								children: [metrics.weeklyRate, "%"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-stone-500 dark:text-stone-400",
								children: "पिछले 7 दिनों में"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-purple-600 dark:text-purple-400",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-stone-500 dark:text-stone-400",
									children: "मासिक दर"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(CalendarIcon, { size: 18 }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-stone-900 dark:text-stone-100",
								children: [metrics.monthlyRate, "%"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-stone-500 dark:text-stone-400",
								children: "पिछले 30 दिनों में"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 126,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between text-amber-500",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-stone-500 dark:text-stone-400",
									children: "सर्वश्रेष्ठ स्ट्रीक"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(Flame, {
									size: 18,
									className: "fill-amber-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 133,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-stone-900 dark:text-stone-100",
								children: [
									metrics.bestOverallStreak,
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-semibold text-stone-500",
										children: "दिन"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 138,
										columnNumber: 41
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 137,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-stone-500 dark:text-stone-400",
								children: ["कुल पूर्ण: ", metrics.totalCompletionsAllTime]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-stone-900 dark:text-stone-100 text-sm",
							children: "7-दिवसीय गतिविधि चार्ट"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 150,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-stone-500 dark:text-stone-400",
							children: "दैनिक पूर्णता प्रतिशत"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-2 py-0.5 rounded-lg border border-emerald-200/50 dark:border-emerald-800/50",
							children: [
								"औसत ",
								metrics.weeklyRate,
								"%"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 157,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-7 gap-2 pt-4 pb-1 items-end h-36 border-b border-stone-100 dark:border-stone-800",
						children: weeklyActivity.map((dayStat) => {
							const barHeight = Math.max(8, dayStat.percentage);
							return /* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col items-center h-full justify-end group",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-bold text-stone-600 dark:text-stone-300 opacity-80 mb-1",
										children: [dayStat.percentage, "%"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-full max-w-[28px] bg-stone-100 dark:bg-stone-800 rounded-xl overflow-hidden h-24 flex items-end",
										children: /* @__PURE__ */ _jsxDEV("div", {
											className: `w-full rounded-xl transition-all duration-500 ${dayStat.isToday ? "bg-gradient-to-t from-emerald-700 to-emerald-500 ring-2 ring-emerald-400" : dayStat.percentage === 100 ? "bg-emerald-600" : dayStat.percentage > 0 ? "bg-emerald-500/70" : "bg-stone-200 dark:bg-stone-700"}`,
											style: { height: `${barHeight}%` }
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 176,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: `text-[11px] mt-2 font-bold ${dayStat.isToday ? "text-emerald-700 dark:text-emerald-400" : "text-stone-500 dark:text-stone-400"}`,
										children: dayStat.dayName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 17
									}, this)
								]
							}, dayStat.date, true, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 15
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between text-[11px] text-stone-500 dark:text-stone-400 pt-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "0%" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-emerald-600 dark:text-emerald-400 font-semibold",
								children: "● आज का दिन हाइलाइटेड है"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "100%" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 210,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-4 rounded-3xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 border border-emerald-200/80 dark:border-emerald-800/60 flex items-start gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-2.5 rounded-2xl bg-emerald-600 text-white shrink-0 shadow-xs",
					children: /* @__PURE__ */ _jsxDEV(Zap, { size: 20 }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 216,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "text-xs",
					children: [/* @__PURE__ */ _jsxDEV("h4", {
						className: "font-bold text-emerald-900 dark:text-emerald-200 text-sm",
						children: "साप्ताहिक निरंतरता समीक्षा"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 220,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-emerald-800/90 dark:text-emerald-300/90 mt-1 leading-relaxed",
						children: metrics.weeklyRate >= 80 ? `उत्कृष्ट निरंतरता! आपने पिछले सप्ताह ${metrics.weeklyRate}% लक्ष्य पूरे किए हैं। आप अपने लक्ष्य के बेहद पक्के हैं!` : metrics.weeklyRate >= 50 ? `अच्छी प्रगति! आपने पिछले सप्ताह ${metrics.weeklyRate}% कार्य पूरा किया। कुछ और नियमितता से आप शीर्ष स्तर पर पहुंचेंगे।` : "एक नई शुरुआत करें! रोज़ाना कम से कम 1 या 2 आदतों को पूरा करने का लक्ष्य रखें और अपनी स्ट्रीक बनाएं।"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 223,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 219,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-stone-900 dark:text-stone-100 text-sm flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV(CalendarIcon, {
								size: 16,
								className: "text-emerald-600"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 239,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "कैलेंडर हीटमैप" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 240,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-stone-500 dark:text-stone-400",
							children: [
								hindiMonths[selectedMonth],
								" ",
								selectedYear
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 242,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1 bg-stone-100 dark:bg-stone-800 p-0.5 rounded-xl",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => changeMonth(-1),
									className: "p-1 rounded-lg text-stone-600 dark:text-stone-300 hover:bg-white dark:hover:bg-stone-700 transition",
									title: "पिछला माह",
									children: /* @__PURE__ */ _jsxDEV(ChevronLeft, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 253,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setSelectedYear(today.getFullYear());
										setSelectedMonth(today.getMonth());
									},
									className: "px-2 py-0.5 text-[10px] font-bold text-stone-700 dark:text-stone-300",
									children: "चालू माह"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 255,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => changeMonth(1),
									className: "p-1 rounded-lg text-stone-600 dark:text-stone-300 hover:bg-white dark:hover:bg-stone-700 transition",
									title: "अगला माह",
									children: /* @__PURE__ */ _jsxDEV(ChevronRight, { size: 16 }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 269,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 236,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-7 gap-1.5 text-center text-[10px] font-bold text-stone-400 dark:text-stone-500 py-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "रवि" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "सोम" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 277,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "मंगल" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 278,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "बुध" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "गुरु" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "शुक्र" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 281,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "शनि" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 282,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 275,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-7 gap-1.5",
						children: heatmapDays.map((item, idx) => {
							const isSelected = selectedHeatmapDay === item.date;
							return /* @__PURE__ */ _jsxDEV("button", {
								disabled: !item.isInMonth,
								onClick: () => setSelectedHeatmapDay(item.date),
								className: `aspect-square rounded-xl flex flex-col items-center justify-center relative transition-all duration-150 cursor-pointer ${!item.isInMonth ? "opacity-20 cursor-default bg-transparent" : getIntensityClass(item.level)} ${item.isToday ? "ring-2 ring-emerald-500 ring-offset-1 dark:ring-offset-stone-900" : ""} ${isSelected && item.isInMonth ? "scale-105 shadow-md ring-2 ring-stone-900 dark:ring-stone-100" : ""}`,
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] leading-none",
									children: item.dayNumber
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 309,
									columnNumber: 17
								}, this), item.level === 4 && /* @__PURE__ */ _jsxDEV("span", { className: "w-1 h-1 rounded-full bg-white mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 313,
									columnNumber: 19
								}, this)]
							}, `${item.date}-${idx}`, true, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 15
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between pt-2 border-t border-stone-100 dark:border-stone-800 text-[10px] text-stone-500 dark:text-stone-400",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "कम (0%)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-md bg-stone-100 dark:bg-stone-800" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-md bg-emerald-200 dark:bg-emerald-950/70" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 325,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-md bg-emerald-400/60" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 326,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-md bg-emerald-500/80" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 327,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { className: "w-3 h-3 rounded-md bg-emerald-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 328,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "अधिक (100%)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 330,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 9
					}, this),
					selectedHeatmapDay && /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-2 p-3 rounded-2xl bg-stone-50 dark:bg-stone-800/50 border border-stone-200 dark:border-stone-700/60 text-xs",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "font-bold text-stone-800 dark:text-stone-200 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: formatDateToHindi(selectedHeatmapDay) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 15
							}, this), history[selectedHeatmapDay] ? /* @__PURE__ */ _jsxDEV("span", {
								className: "text-emerald-700 dark:text-emerald-400 font-semibold",
								children: "रिकॉर्ड मौजूद"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 339,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "text-stone-400",
								children: "कोई डेटा नहीं"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 343,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 336,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 335,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 234,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-5 rounded-3xl bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 shadow-xs space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "font-bold text-stone-900 dark:text-stone-100 text-sm flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV(Award, {
						size: 16,
						className: "text-amber-500"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 353,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "प्रत्येक आदत की स्ट्रीक स्थिति" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 354,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 352,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2.5",
					children: activeHabits.map((habit) => {
						const streak = calculateHabitStreak(habit, history);
						const colorScheme = getColorScheme(habit.color);
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 rounded-2xl bg-stone-50 dark:bg-stone-800/60 border border-stone-200/70 dark:border-stone-800 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2.5 min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${colorScheme.bg} ${colorScheme.border} ${colorScheme.text}`,
									children: /* @__PURE__ */ _jsxDEV(HabitIcon, {
										name: habit.icon,
										size: 18
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 371,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 368,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ _jsxDEV("h5", {
										className: "text-xs font-bold text-stone-900 dark:text-stone-100 truncate",
										children: habit.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[10px] text-stone-500 dark:text-stone-400",
										children: [
											"कुल पूर्ण: ",
											streak.totalCompletions,
											" बार"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 377,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 373,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "px-2.5 py-1 rounded-xl bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20 text-center",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] font-semibold flex items-center justify-center gap-0.5",
										children: [/* @__PURE__ */ _jsxDEV(Flame, {
											size: 12,
											className: "fill-amber-500 text-amber-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 387,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "वर्तमान" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 388,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 386,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-black",
										children: [streak.currentStreak, " दिन"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 390,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 385,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20 text-center",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] font-semibold flex items-center justify-center gap-0.5",
										children: [/* @__PURE__ */ _jsxDEV(Trophy, {
											size: 11,
											className: "text-emerald-600"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 396,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "सर्वश्रेष्ठ" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 397,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 395,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-black",
										children: [streak.longestStreak, " दिन"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 399,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 394,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 17
							}, this)]
						}, habit.id, true, {
							fileName: _jsxFileName,
							lineNumber: 363,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 357,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 351,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLE9BQ0EsUUFDQSxZQUNBLFlBQVksY0FDWixhQUNBLGNBQ0EsY0FDQSxPQUNBLFdBR0s7QUFFUCxTQUFTLFdBQVcsc0JBQXNCO0FBQzFDLFNBQ0UseUJBQ0EsbUJBQ0EsaUJBQ0EsNEJBQ0s7QUFDUCxTQUFTLG1CQUFtQiwwQkFBMEI7OztBQU90RCxPQUFPLE1BQU0sZUFBMkMsRUFBRSxRQUFRLGNBQWM7Q0FDOUUsTUFBTSxRQUFRLElBQUksS0FBSztDQUN2QixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsTUFBTSxZQUFZLENBQUM7Q0FDNUUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWlCLE1BQU0sU0FBUyxDQUFDO0NBQzNFLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQXdCLG1CQUFtQixDQUFDO0NBRWhHLE1BQU0sZUFBZSxPQUFPLFFBQVEsTUFBTSxDQUFDLEVBQUUsUUFBUTtDQUNyRCxNQUFNLFVBQVUsd0JBQXdCLFFBQVEsT0FBTztDQUN2RCxNQUFNLGlCQUFpQixrQkFBa0IsUUFBUSxPQUFPO0NBQ3hELE1BQU0sY0FBYyxnQkFBZ0IsY0FBYyxlQUFlLFFBQVEsT0FBTztDQUVoRixNQUFNLGNBQWM7RUFDbEI7RUFBUztFQUFVO0VBQVM7RUFBVTtFQUFNO0VBQzVDO0VBQVM7RUFBUztFQUFVO0VBQVc7RUFBUztDQUNsRDtDQUVBLE1BQU0sZUFBZSxVQUFrQjtFQUNyQyxJQUFJLFlBQVksZ0JBQWdCO0VBQ2hDLElBQUksV0FBVztFQUNmLElBQUksWUFBWSxHQUFHO0dBQ2pCLFlBQVk7R0FDWjtFQUNGLE9BQU8sSUFBSSxZQUFZLElBQUk7R0FDekIsWUFBWTtHQUNaO0VBQ0Y7RUFDQSxpQkFBaUIsU0FBUztFQUMxQixnQkFBZ0IsUUFBUTtDQUMxQjtDQUVBLE1BQU0scUJBQXFCLFVBQWtCO0VBQzNDLFFBQVEsT0FBUjtHQUNFLEtBQUssR0FDSCxPQUFPO0dBQ1QsS0FBSyxHQUNILE9BQU87R0FDVCxLQUFLLEdBQ0gsT0FBTztHQUNULEtBQUssR0FDSCxPQUFPO0dBQ1QsU0FDRSxPQUFPO0VBQ1g7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF3RDtHQUVsRTs7OzthQUNKLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQTZDO0dBRXZEOzs7O1dBQ0E7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBdUQ7UUFBYzs7OztrQkFDckYsd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7OztnQkFDdEI7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0csUUFBUSxpQkFBZ0IsR0FDdEI7Ozs7OztPQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQ0csUUFBUTtTQUFvQjtTQUFJLFFBQVE7U0FBZ0I7UUFDeEQ7Ozs7OztNQUNBOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXVEO1FBQWtCOzs7O2tCQUN6Rix3QkFBQyxZQUFELEVBQVksTUFBTSxHQUFLOzs7O2dCQUNwQjs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRyxRQUFRLFlBQVcsR0FDakI7Ozs7OztPQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFpRDtPQUUzRDs7Ozs7TUFDQTs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1RDtRQUFjOzs7O2tCQUNyRix3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7O2dCQUN0Qjs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRyxRQUFRLGFBQVksR0FDbEI7Ozs7OztPQUNMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFpRDtPQUUzRDs7Ozs7TUFDQTs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1RDtRQUF5Qjs7OztrQkFDaEcsd0JBQUMsT0FBRDtTQUFPLE1BQU07U0FBSSxXQUFVO1FBQWtCOzs7O2dCQUMxQzs7Ozs7O09BQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRyxRQUFRO1NBQWtCO1NBQUMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVDO1NBQVM7Ozs7O1FBQ3pGOzs7Ozs7T0FDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYixDQUE4RCxlQUNoRCxRQUFRLHVCQUNuQjs7Ozs7O01BQ0E7Ozs7OztJQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXVEO01BRWpFOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFpRDtNQUUzRDs7OztjQUNBOzs7O2dCQUNMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQjtRQUErTDtRQUN4TCxRQUFRO1FBQVc7T0FDcEI7Ozs7O2NBQ0g7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGVBQWUsS0FBSyxZQUFZO09BQy9CLE1BQU0sWUFBWSxLQUFLLElBQUksR0FBRyxRQUFRLFVBQVU7T0FFaEQsT0FDRSx3QkFBQyxPQUFEO1FBQXdCLFdBQVU7a0JBQWxDO1NBRUUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0csUUFBUSxZQUFXLEdBQ2hCOzs7Ozs7U0FHTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxPQUFEO1dBQ0UsV0FBVyxpREFDVCxRQUFRLFVBQ0osNkVBQ0EsUUFBUSxlQUFlLE1BQ3ZCLG1CQUNBLFFBQVEsYUFBYSxJQUNyQixzQkFDQTtXQUVOLE9BQU8sRUFBRSxRQUFRLEdBQUcsVUFBVSxHQUFHO1VBQ2xDOzs7OztTQUNFOzs7OztTQUdMLHdCQUFDLFFBQUQ7VUFDRSxXQUFXLDhCQUNULFFBQVEsVUFDSiwyQ0FDQTtvQkFHTCxRQUFRO1NBQ0w7Ozs7O1FBQ0g7VUFoQ0ssUUFBUTs7OztjQWdDYjtNQUVULENBQUM7S0FDRTs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztPQUNkLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF1RDtPQUVqRTs7Ozs7T0FDTix3QkFBQyxRQUFELFlBQU0sT0FBVTs7Ozs7TUFDYjs7Ozs7O0lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLEtBQUQsRUFBSyxNQUFNLEdBQUs7Ozs7O0lBQ2I7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQTJEO0tBRXJFOzs7O2VBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsUUFBUSxjQUFjLEtBQ25CLHdDQUF3QyxRQUFRLFdBQVcsNERBQzNELFFBQVEsY0FBYyxLQUN0QixtQ0FBbUMsUUFBUSxXQUFXLHFFQUN0RDtLQUNIOzs7O2FBQ0E7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLGNBQUQ7UUFBYyxNQUFNO1FBQUksV0FBVTtPQUFvQjs7OztpQkFDdEQsd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7OztlQUN4Qjs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFDRyxZQUFZO1FBQWU7UUFBRTtPQUM3Qjs7Ozs7Y0FDQTs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLFlBQVksQ0FBQyxDQUFDO1NBQzdCLFdBQVU7U0FDVixPQUFNO21CQUVOLHdCQUFDLGFBQUQsRUFBYSxNQUFNLEdBQUs7Ozs7O1FBQ2xCOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlO1VBQ2IsZ0JBQWdCLE1BQU0sWUFBWSxDQUFDO1VBQ25DLGlCQUFpQixNQUFNLFNBQVMsQ0FBQztTQUNuQztTQUNBLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxZQUFZLENBQUM7U0FDNUIsV0FBVTtTQUNWLE9BQU07bUJBRU4sd0JBQUMsY0FBRCxFQUFjLE1BQU0sR0FBSzs7Ozs7UUFDbkI7Ozs7O09BQ0w7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRCxZQUFNLE1BQVM7Ozs7O09BQ2Ysd0JBQUMsUUFBRCxZQUFNLE1BQVM7Ozs7O09BQ2Ysd0JBQUMsUUFBRCxZQUFNLE9BQVU7Ozs7O09BQ2hCLHdCQUFDLFFBQUQsWUFBTSxNQUFTOzs7OztPQUNmLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7OztPQUNoQix3QkFBQyxRQUFELFlBQU0sUUFBVzs7Ozs7T0FDakIsd0JBQUMsUUFBRCxZQUFNLE1BQVM7Ozs7O01BQ1o7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLFlBQVksS0FBSyxNQUFNLFFBQVE7T0FDOUIsTUFBTSxhQUFhLHVCQUF1QixLQUFLO09BRS9DLE9BQ0Usd0JBQUMsVUFBRDtRQUVFLFVBQVUsQ0FBQyxLQUFLO1FBQ2hCLGVBQWUsc0JBQXNCLEtBQUssSUFBSTtRQUM5QyxXQUFXLDBIQUNULENBQUMsS0FBSyxZQUNGLDZDQUNBLGtCQUFrQixLQUFLLEtBQUssRUFDakMsR0FDQyxLQUFLLFVBQ0QscUVBQ0EsR0FDTCxHQUNDLGNBQWMsS0FBSyxZQUNmLGtFQUNBO2tCQWZSLENBa0JFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEtBQUs7UUFDRjs7OztrQkFDTCxLQUFLLFVBQVUsS0FDZCx3QkFBQyxRQUFELEVBQU0sV0FBVSx1Q0FBd0M7Ozs7Z0JBRXBEO1VBdkJELEdBQUcsS0FBSyxLQUFLLEdBQUc7Ozs7Y0F1QmY7TUFFWixDQUFDO0tBQ0U7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELFlBQU0sVUFBYTs7Ozs7T0FDbkIsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvREFBcUQ7Ozs7O1NBQ3JFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLDJEQUE0RDs7Ozs7U0FDNUUsd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQXdDOzs7OztTQUN4RCx3QkFBQyxRQUFELEVBQU0sV0FBVSx1Q0FBd0M7Ozs7O1NBQ3hELHdCQUFDLFFBQUQsRUFBTSxXQUFVLG9DQUFxQzs7Ozs7UUFDbEQ7Ozs7OztPQUNMLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7Ozs7TUFDcEI7Ozs7OztLQUdKLHNCQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFPLGtCQUFrQixrQkFBa0IsRUFBUTs7OztpQkFDbEQsUUFBUSxzQkFDUCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBdUQ7T0FFakU7Ozs7a0JBRU4sd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlCO09BQW1COzs7O2VBRW5EOzs7Ozs7S0FDRjs7Ozs7SUFFSjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQWQsQ0FDRSx3QkFBQyxPQUFEO01BQU8sTUFBTTtNQUFJLFdBQVU7S0FBa0I7Ozs7ZUFDN0Msd0JBQUMsUUFBRCxZQUFNLGlDQUFvQzs7OzthQUN4Qzs7Ozs7Y0FFSix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLGFBQWEsS0FBSyxVQUFVO01BQzNCLE1BQU0sU0FBUyxxQkFBcUIsT0FBTyxPQUFPO01BQ2xELE1BQU0sY0FBYyxlQUFlLE1BQU0sS0FBSztNQUU5QyxPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFVO2lCQUZaLENBSUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQ0UsV0FBVyx1RUFBdUUsWUFBWSxHQUFHLEdBQUcsWUFBWSxPQUFPLEdBQUcsWUFBWTttQkFFdEksd0JBQUMsV0FBRDtVQUFXLE1BQU0sTUFBTTtVQUFNLE1BQU07U0FBSzs7Ozs7UUFDckM7Ozs7a0JBQ0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFDWCxNQUFNO1NBQ0w7Ozs7bUJBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBOEQ7V0FDaEQsT0FBTztXQUFpQjtVQUNuQzs7Ozs7aUJBQ0E7Ozs7O2dCQUNGOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQU8sTUFBTTtXQUFJLFdBQVU7VUFBaUM7Ozs7b0JBQzVELHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O2tCQUNoQjs7Ozs7bUJBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQXNDLE9BQU8sZUFBYyxNQUFVOzs7OztpQkFDbEU7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQVEsTUFBTTtXQUFJLFdBQVU7VUFBb0I7Ozs7b0JBQ2hELHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztrQkFDcEI7Ozs7O21CQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUFzQyxPQUFPLGVBQWMsTUFBVTs7Ozs7aUJBQ2xFOzs7OztnQkFDRjs7Ozs7ZUFDRjtTQXRDRSxNQUFNOzs7O2FBc0NSO0tBRVQsQ0FBQztJQUNFOzs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcm9ncmVzc1RhYi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIEZsYW1lLCBcbiAgVHJvcGh5LCBcbiAgVHJlbmRpbmdVcCwgXG4gIENhbGVuZGFyIGFzIENhbGVuZGFySWNvbiwgXG4gIENoZXZyb25MZWZ0LCBcbiAgQ2hldnJvblJpZ2h0LFxuICBDaGVja0NpcmNsZTIsXG4gIEF3YXJkLFxuICBaYXAsXG4gIENsb2NrLFxuICBTcGFya2xlc1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgSGFiaXQsIEhhYml0SGlzdG9yeSB9IGZyb20gJy4uL3R5cGVzL2hhYml0JztcbmltcG9ydCB7IEhhYml0SWNvbiwgZ2V0Q29sb3JTY2hlbWUgfSBmcm9tICcuL0hhYml0SWNvbic7XG5pbXBvcnQgeyBcbiAgY2FsY3VsYXRlT3ZlcmFsbE1ldHJpY3MsIFxuICBnZXRXZWVrbHlBY3Rpdml0eSwgXG4gIGdldE1vbnRoSGVhdG1hcCwgXG4gIGNhbGN1bGF0ZUhhYml0U3RyZWFrIFxufSBmcm9tICcuLi9zZXJ2aWNlcy9zdHJlYWtTZXJ2aWNlJztcbmltcG9ydCB7IGZvcm1hdERhdGVUb0hpbmRpLCBnZXRUb2RheURhdGVTdHJpbmcgfSBmcm9tICcuLi9zZXJ2aWNlcy9zdG9yYWdlU2VydmljZSc7XG5cbmludGVyZmFjZSBQcm9ncmVzc1RhYlByb3BzIHtcbiAgaGFiaXRzOiBIYWJpdFtdO1xuICBoaXN0b3J5OiBIYWJpdEhpc3Rvcnk7XG59XG5cbmV4cG9ydCBjb25zdCBQcm9ncmVzc1RhYjogUmVhY3QuRkM8UHJvZ3Jlc3NUYWJQcm9wcz4gPSAoeyBoYWJpdHMsIGhpc3RvcnkgfSkgPT4ge1xuICBjb25zdCB0b2RheSA9IG5ldyBEYXRlKCk7XG4gIGNvbnN0IFtzZWxlY3RlZFllYXIsIHNldFNlbGVjdGVkWWVhcl0gPSB1c2VTdGF0ZTxudW1iZXI+KHRvZGF5LmdldEZ1bGxZZWFyKCkpO1xuICBjb25zdCBbc2VsZWN0ZWRNb250aCwgc2V0U2VsZWN0ZWRNb250aF0gPSB1c2VTdGF0ZTxudW1iZXI+KHRvZGF5LmdldE1vbnRoKCkpOyAvLyAwLWluZGV4ZWRcbiAgY29uc3QgW3NlbGVjdGVkSGVhdG1hcERheSwgc2V0U2VsZWN0ZWRIZWF0bWFwRGF5XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KGdldFRvZGF5RGF0ZVN0cmluZygpKTtcblxuICBjb25zdCBhY3RpdmVIYWJpdHMgPSBoYWJpdHMuZmlsdGVyKChoKSA9PiAhaC5pc1BhdXNlZCk7XG4gIGNvbnN0IG1ldHJpY3MgPSBjYWxjdWxhdGVPdmVyYWxsTWV0cmljcyhoYWJpdHMsIGhpc3RvcnkpO1xuICBjb25zdCB3ZWVrbHlBY3Rpdml0eSA9IGdldFdlZWtseUFjdGl2aXR5KGhhYml0cywgaGlzdG9yeSk7XG4gIGNvbnN0IGhlYXRtYXBEYXlzID0gZ2V0TW9udGhIZWF0bWFwKHNlbGVjdGVkWWVhciwgc2VsZWN0ZWRNb250aCwgaGFiaXRzLCBoaXN0b3J5KTtcblxuICBjb25zdCBoaW5kaU1vbnRocyA9IFtcbiAgICAn4KSc4KSo4KS14KSw4KWAJywgJ+Ckq+CkvOCksOCkteCksOClgCcsICfgpK7gpL7gpLDgpY3gpJonLCAn4KSF4KSq4KWN4KSw4KWI4KSyJywgJ+CkruCkiCcsICfgpJzgpYLgpKgnLFxuICAgICfgpJzgpYHgpLLgpL7gpIgnLCAn4KSF4KSX4KS44KWN4KSkJywgJ+CkuOCkv+CkpOCkguCkrOCksCcsICfgpIXgpJXgpY3gpJ/gpYLgpKzgpLAnLCAn4KSo4KS14KSC4KSs4KSwJywgJ+CkpuCkv+CkuOCkguCkrOCksCdcbiAgXTtcblxuICBjb25zdCBjaGFuZ2VNb250aCA9IChkZWx0YTogbnVtYmVyKSA9PiB7XG4gICAgbGV0IG5leHRNb250aCA9IHNlbGVjdGVkTW9udGggKyBkZWx0YTtcbiAgICBsZXQgbmV4dFllYXIgPSBzZWxlY3RlZFllYXI7XG4gICAgaWYgKG5leHRNb250aCA8IDApIHtcbiAgICAgIG5leHRNb250aCA9IDExO1xuICAgICAgbmV4dFllYXItLTtcbiAgICB9IGVsc2UgaWYgKG5leHRNb250aCA+IDExKSB7XG4gICAgICBuZXh0TW9udGggPSAwO1xuICAgICAgbmV4dFllYXIrKztcbiAgICB9XG4gICAgc2V0U2VsZWN0ZWRNb250aChuZXh0TW9udGgpO1xuICAgIHNldFNlbGVjdGVkWWVhcihuZXh0WWVhcik7XG4gIH07XG5cbiAgY29uc3QgZ2V0SW50ZW5zaXR5Q2xhc3MgPSAobGV2ZWw6IG51bWJlcikgPT4ge1xuICAgIHN3aXRjaCAobGV2ZWwpIHtcbiAgICAgIGNhc2UgNDpcbiAgICAgICAgcmV0dXJuICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByaW5nLTEgcmluZy1lbWVyYWxkLTUwMCc7XG4gICAgICBjYXNlIDM6XG4gICAgICAgIHJldHVybiAnYmctZW1lcmFsZC01MDAvODAgdGV4dC13aGl0ZSBmb250LW1lZGl1bSc7XG4gICAgICBjYXNlIDI6XG4gICAgICAgIHJldHVybiAnYmctZW1lcmFsZC00MDAvNjAgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCBmb250LW1lZGl1bSc7XG4gICAgICBjYXNlIDE6XG4gICAgICAgIHJldHVybiAnYmctZW1lcmFsZC0yMDAgZGFyazpiZy1lbWVyYWxkLTk1MC83MCB0ZXh0LXN0b25lLTgwMCBkYXJrOnRleHQtc3RvbmUtMzAwJztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiAnYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwLzYwIHRleHQtc3RvbmUtNDAwIGRhcms6dGV4dC1zdG9uZS01MDAnO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicGItMjQgcHQtNCBweC00IG1heC13LW1kIG14LWF1dG8gc3BhY2UteS01XCI+XG4gICAgICB7LyogUGFnZSBUaXRsZSAqL31cbiAgICAgIDxkaXY+XG4gICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMFwiPlxuICAgICAgICAgIOCkquCljeCksOCkl+CkpOCkvyDgpJTgpLAg4KS44KWN4KSf4KWN4KSw4KWA4KSVIOCksOCkv+CkquCli+CksOCljeCkn1xuICAgICAgICA8L2gyPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICDgpIXgpKrgpKjgpYAg4KSo4KS/4KSw4KSC4KSk4KSw4KSk4KS+IOCklOCksCDgpIbgpKbgpKTgpYvgpIIg4KSV4KS+IOCkuOCkruCkl+CljeCksCDgpLXgpL/gpLbgpY3gpLLgpYfgpLfgpKNcbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUb3AgNCBNZXRyaWMgSGlnaGxpZ2h0cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICB7LyogTWV0cmljIDE6IFRvZGF5ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTN4bCBiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC84MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgc2hhZG93LXhzIHNwYWNlLXktMVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwXCI+4KSG4KScIOCkleClgCDgpKbgpLA8L3NwYW4+XG4gICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIHNpemU9ezE4fSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwXCI+XG4gICAgICAgICAgICB7bWV0cmljcy50b2RheVBlcmNlbnRhZ2V9JVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICAgIHttZXRyaWNzLnRvZGF5Q29tcGxldGVkQ291bnR9IC8ge21ldHJpY3MudG9kYXlUb3RhbENvdW50fSDgpKrgpYLgpLDgpY3gpKNcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXRyaWMgMjogV2Vla2x5IFJhdGUgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtM3hsIGJnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwLzgwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBzaGFkb3cteHMgc3BhY2UteS0xXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1ibHVlLTYwMCBkYXJrOnRleHQtYmx1ZS00MDBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj7gpLjgpL7gpKrgpY3gpKTgpL7gpLngpL/gpJUg4KSm4KSwPC9zcGFuPlxuICAgICAgICAgICAgPFRyZW5kaW5nVXAgc2l6ZT17MTh9IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgIHttZXRyaWNzLndlZWtseVJhdGV9JVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICAgIOCkquCkv+Ckm+CksuClhyA3IOCkpuCkv+CkqOCli+CkgiDgpK7gpYfgpIJcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXRyaWMgMzogTW9udGhseSBSYXRlICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTN4bCBiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC84MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgc2hhZG93LXhzIHNwYWNlLXktMVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtcHVycGxlLTYwMCBkYXJrOnRleHQtcHVycGxlLTQwMFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPuCkruCkvuCkuOCkv+CklSDgpKbgpLA8L3NwYW4+XG4gICAgICAgICAgICA8Q2FsZW5kYXJJY29uIHNpemU9ezE4fSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwXCI+XG4gICAgICAgICAgICB7bWV0cmljcy5tb250aGx5UmF0ZX0lXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAg4KSq4KS/4KSb4KSy4KWHIDMwIOCkpuCkv+CkqOCli+CkgiDgpK7gpYfgpIJcbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBNZXRyaWMgNDogQmVzdCBTdHJlYWsgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtM3hsIGJnLXdoaXRlIGRhcms6Ymctc3RvbmUtOTAwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwLzgwIGRhcms6Ym9yZGVyLXN0b25lLTgwMCBzaGFkb3cteHMgc3BhY2UteS0xXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1hbWJlci01MDBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj7gpLjgpLDgpY3gpLXgpLbgpY3gpLDgpYfgpLfgpY3gpKAg4KS44KWN4KSf4KWN4KSw4KWA4KSVPC9zcGFuPlxuICAgICAgICAgICAgPEZsYW1lIHNpemU9ezE4fSBjbGFzc05hbWU9XCJmaWxsLWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDBcIj5cbiAgICAgICAgICAgIHttZXRyaWNzLmJlc3RPdmVyYWxsU3RyZWFrfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zdG9uZS01MDBcIj7gpKbgpL/gpKg8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAg4KSV4KWB4KSyIOCkquClguCksOCljeCkozoge21ldHJpY3MudG90YWxDb21wbGV0aW9uc0FsbFRpbWV9XG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogNy1EYXkgQWN0aXZpdHkgQ2hhcnQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNSByb3VuZGVkLTN4bCBiZy13aGl0ZSBkYXJrOmJnLXN0b25lLTkwMCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC84MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgc2hhZG93LXhzIHNwYWNlLXktM1wiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICA3LeCkpuCkv+CkteCkuOClgOCkryDgpJfgpKTgpL/gpLXgpL/gpKfgpL8g4KSa4KS+4KSw4KWN4KSfXG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAgICDgpKbgpYjgpKjgpL/gpJUg4KSq4KWC4KSw4KWN4KSj4KSk4KS+IOCkquCljeCksOCkpOCkv+CktuCkpFxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC81MCBweC0yIHB5LTAuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAvNTAgZGFyazpib3JkZXItZW1lcmFsZC04MDAvNTBcIj5cbiAgICAgICAgICAgIOCklOCkuOCkpCB7bWV0cmljcy53ZWVrbHlSYXRlfSVcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBCYXJzIENvbnRhaW5lciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy03IGdhcC0yIHB0LTQgcGItMSBpdGVtcy1lbmQgaC0zNiBib3JkZXItYiBib3JkZXItc3RvbmUtMTAwIGRhcms6Ym9yZGVyLXN0b25lLTgwMFwiPlxuICAgICAgICAgIHt3ZWVrbHlBY3Rpdml0eS5tYXAoKGRheVN0YXQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGJhckhlaWdodCA9IE1hdGgubWF4KDgsIGRheVN0YXQucGVyY2VudGFnZSk7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXtkYXlTdGF0LmRhdGV9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGgtZnVsbCBqdXN0aWZ5LWVuZCBncm91cFwiPlxuICAgICAgICAgICAgICAgIHsvKiBUb29sdGlwIG9uIGhvdmVyL3RvdWNoICovfVxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTYwMCBkYXJrOnRleHQtc3RvbmUtMzAwIG9wYWNpdHktODAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAge2RheVN0YXQucGVyY2VudGFnZX0lXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgey8qIFZlcnRpY2FsIEJhciAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1bMjhweF0gYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGgtMjQgZmxleCBpdGVtcy1lbmRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNTAwICR7XG4gICAgICAgICAgICAgICAgICAgICAgZGF5U3RhdC5pc1RvZGF5XG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by10IGZyb20tZW1lcmFsZC03MDAgdG8tZW1lcmFsZC01MDAgcmluZy0yIHJpbmctZW1lcmFsZC00MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6IGRheVN0YXQucGVyY2VudGFnZSA9PT0gMTAwXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZGF5U3RhdC5wZXJjZW50YWdlID4gMFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvNzAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zdG9uZS0yMDAgZGFyazpiZy1zdG9uZS03MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IGAke2JhckhlaWdodH0lYCB9fVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBEYXkgTGFiZWwgKi99XG4gICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHRleHQtWzExcHhdIG10LTIgZm9udC1ib2xkICR7XG4gICAgICAgICAgICAgICAgICAgIGRheVN0YXQuaXNUb2RheVxuICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7ZGF5U3RhdC5kYXlOYW1lfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LXN0b25lLTUwMCBkYXJrOnRleHQtc3RvbmUtNDAwIHB0LTFcIj5cbiAgICAgICAgICA8c3Bhbj4wJTwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICDil48g4KSG4KScIOCkleCkviDgpKbgpL/gpKgg4KS54KS+4KSH4KSy4KS+4KSH4KSf4KWH4KShIOCkueCliFxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj4xMDAlPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogQ29uc2lzdGVuY3kgSW5zaWdodCBDYXJkICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgcm91bmRlZC0zeGwgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1lbWVyYWxkLTUwIHRvLXRlYWwtNTAgZGFyazpmcm9tLWVtZXJhbGQtOTUwLzQwIGRhcms6dG8tdGVhbC05NTAvNDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMC84MCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMC82MCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgcm91bmRlZC0yeGwgYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBzaHJpbmstMCBzaGFkb3cteHNcIj5cbiAgICAgICAgICA8WmFwIHNpemU9ezIwfSAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+XG4gICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtOTAwIGRhcms6dGV4dC1lbWVyYWxkLTIwMCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICDgpLjgpL7gpKrgpY3gpKTgpL7gpLngpL/gpJUg4KSo4KS/4KSw4KSC4KSk4KSw4KSk4KS+IOCkuOCkruClgOCkleCljeCkt+CkvlxuICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTgwMC85MCBkYXJrOnRleHQtZW1lcmFsZC0zMDAvOTAgbXQtMSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgIHttZXRyaWNzLndlZWtseVJhdGUgPj0gODBcbiAgICAgICAgICAgICAgPyBg4KSJ4KSk4KWN4KSV4KWD4KS34KWN4KSfIOCkqOCkv+CksOCkguCkpOCksOCkpOCkviEg4KSG4KSq4KSo4KWHIOCkquCkv+Ckm+CksuClhyDgpLjgpKrgpY3gpKTgpL7gpLkgJHttZXRyaWNzLndlZWtseVJhdGV9JSDgpLLgpJXgpY3gpLfgpY3gpK8g4KSq4KWC4KSw4KWHIOCkleCkv+CkjyDgpLngpYjgpILgpaQg4KSG4KSqIOCkheCkquCkqOClhyDgpLLgpJXgpY3gpLfgpY3gpK8g4KSV4KWHIOCkrOClh+CkueCkpiDgpKrgpJXgpY3gpJXgpYcg4KS54KWI4KSCIWBcbiAgICAgICAgICAgICAgOiBtZXRyaWNzLndlZWtseVJhdGUgPj0gNTBcbiAgICAgICAgICAgICAgPyBg4KSF4KSa4KWN4KSb4KWAIOCkquCljeCksOCkl+CkpOCkvyEg4KSG4KSq4KSo4KWHIOCkquCkv+Ckm+CksuClhyDgpLjgpKrgpY3gpKTgpL7gpLkgJHttZXRyaWNzLndlZWtseVJhdGV9JSDgpJXgpL7gpLDgpY3gpK8g4KSq4KWC4KSw4KS+IOCkleCkv+Ckr+CkvuClpCDgpJXgpYHgpJsg4KSU4KSwIOCkqOCkv+Ckr+CkruCkv+CkpOCkpOCkviDgpLjgpYcg4KSG4KSqIOCktuClgOCksOCljeCktyDgpLjgpY3gpKTgpLAg4KSq4KSwIOCkquCkueClgeCkguCkmuClh+CkguCkl+Clh+ClpGBcbiAgICAgICAgICAgICAgOiAn4KSP4KSVIOCkqOCkiCDgpLbgpYHgpLDgpYHgpIbgpKQg4KSV4KSw4KWH4KSCISDgpLDgpYvgpJzgpLzgpL7gpKjgpL4g4KSV4KSuIOCkuOClhyDgpJXgpK4gMSDgpK/gpL4gMiDgpIbgpKbgpKTgpYvgpIIg4KSV4KWLIOCkquClguCksOCkviDgpJXgpLDgpKjgpYcg4KSV4KS+IOCksuCkleCljeCkt+CljeCkryDgpLDgpJbgpYfgpIIg4KSU4KSwIOCkheCkquCkqOClgCDgpLjgpY3gpJ/gpY3gpLDgpYDgpJUg4KSs4KSo4KS+4KSP4KSC4KWkJ31cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNb250aGx5IEhlYXRtYXAgLyBDYWxlbmRhciBWaWV3ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0zeGwgYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAvODAgZGFyazpib3JkZXItc3RvbmUtODAwIHNoYWRvdy14cyBzcGFjZS15LTNcIj5cbiAgICAgICAgey8qIENhbGVuZGFyIEhlYWRlciB3aXRoIE1vbnRoIE5hdmlnYXRpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zdG9uZS05MDAgZGFyazp0ZXh0LXN0b25lLTEwMCB0ZXh0LXNtIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPENhbGVuZGFySWNvbiBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTYwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPuCkleCliOCksuClh+CkguCkoeCksCDgpLngpYDgpJ/gpK7gpYjgpKo8L3NwYW4+XG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAgICB7aGluZGlNb250aHNbc2VsZWN0ZWRNb250aF19IHtzZWxlY3RlZFllYXJ9XG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJnLXN0b25lLTEwMCBkYXJrOmJnLXN0b25lLTgwMCBwLTAuNSByb3VuZGVkLXhsXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNoYW5nZU1vbnRoKC0xKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQtbGcgdGV4dC1zdG9uZS02MDAgZGFyazp0ZXh0LXN0b25lLTMwMCBob3ZlcjpiZy13aGl0ZSBkYXJrOmhvdmVyOmJnLXN0b25lLTcwMCB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgdGl0bGU9XCLgpKrgpL/gpJvgpLLgpL4g4KSu4KS+4KS5XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IHNpemU9ezE2fSAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFllYXIodG9kYXkuZ2V0RnVsbFllYXIoKSk7XG4gICAgICAgICAgICAgICAgc2V0U2VsZWN0ZWRNb250aCh0b2RheS5nZXRNb250aCgpKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgdGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc3RvbmUtNzAwIGRhcms6dGV4dC1zdG9uZS0zMDBcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDgpJrgpL7gpLLgpYIg4KSu4KS+4KS5XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY2hhbmdlTW9udGgoMSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSByb3VuZGVkLWxnIHRleHQtc3RvbmUtNjAwIGRhcms6dGV4dC1zdG9uZS0zMDAgaG92ZXI6Ymctd2hpdGUgZGFyazpob3ZlcjpiZy1zdG9uZS03MDAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgIHRpdGxlPVwi4KSF4KSX4KSy4KS+IOCkruCkvuCkuVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgc2l6ZT17MTZ9IC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERheS1vZi13ZWVrIGhlYWRlciByb3cgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNyBnYXAtMS41IHRleHQtY2VudGVyIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB0ZXh0LXN0b25lLTQwMCBkYXJrOnRleHQtc3RvbmUtNTAwIHB5LTFcIj5cbiAgICAgICAgICA8c3Bhbj7gpLDgpLXgpL88L3NwYW4+XG4gICAgICAgICAgPHNwYW4+4KS44KWL4KSuPC9zcGFuPlxuICAgICAgICAgIDxzcGFuPuCkruCkguCkl+Cksjwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj7gpKzgpYHgpKc8L3NwYW4+XG4gICAgICAgICAgPHNwYW4+4KSX4KWB4KSw4KWBPC9zcGFuPlxuICAgICAgICAgIDxzcGFuPuCktuClgeCkleCljeCksDwvc3Bhbj5cbiAgICAgICAgICA8c3Bhbj7gpLbgpKjgpL88L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBIZWF0bWFwIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNyBnYXAtMS41XCI+XG4gICAgICAgICAge2hlYXRtYXBEYXlzLm1hcCgoaXRlbSwgaWR4KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gc2VsZWN0ZWRIZWF0bWFwRGF5ID09PSBpdGVtLmRhdGU7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e2Ake2l0ZW0uZGF0ZX0tJHtpZHh9YH1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWl0ZW0uaXNJbk1vbnRofVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkSGVhdG1hcERheShpdGVtLmRhdGUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGFzcGVjdC1zcXVhcmUgcm91bmRlZC14bCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByZWxhdGl2ZSB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0xNTAgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICFpdGVtLmlzSW5Nb250aFxuICAgICAgICAgICAgICAgICAgICA/ICdvcGFjaXR5LTIwIGN1cnNvci1kZWZhdWx0IGJnLXRyYW5zcGFyZW50J1xuICAgICAgICAgICAgICAgICAgICA6IGdldEludGVuc2l0eUNsYXNzKGl0ZW0ubGV2ZWwpXG4gICAgICAgICAgICAgICAgfSAke1xuICAgICAgICAgICAgICAgICAgaXRlbS5pc1RvZGF5XG4gICAgICAgICAgICAgICAgICAgID8gJ3JpbmctMiByaW5nLWVtZXJhbGQtNTAwIHJpbmctb2Zmc2V0LTEgZGFyazpyaW5nLW9mZnNldC1zdG9uZS05MDAnXG4gICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICB9ICR7XG4gICAgICAgICAgICAgICAgICBpc1NlbGVjdGVkICYmIGl0ZW0uaXNJbk1vbnRoXG4gICAgICAgICAgICAgICAgICAgID8gJ3NjYWxlLTEwNSBzaGFkb3ctbWQgcmluZy0yIHJpbmctc3RvbmUtOTAwIGRhcms6cmluZy1zdG9uZS0xMDAnXG4gICAgICAgICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGxlYWRpbmctbm9uZVwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uZGF5TnVtYmVyfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICB7aXRlbS5sZXZlbCA9PT0gNCAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTEgaC0xIHJvdW5kZWQtZnVsbCBiZy13aGl0ZSBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEhlYXRtYXAgTGVnZW5kICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwdC0yIGJvcmRlci10IGJvcmRlci1zdG9uZS0xMDAgZGFyazpib3JkZXItc3RvbmUtODAwIHRleHQtWzEwcHhdIHRleHQtc3RvbmUtNTAwIGRhcms6dGV4dC1zdG9uZS00MDBcIj5cbiAgICAgICAgICA8c3Bhbj7gpJXgpK4gKDAlKTwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHJvdW5kZWQtbWQgYmctc3RvbmUtMTAwIGRhcms6Ymctc3RvbmUtODAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZC1tZCBiZy1lbWVyYWxkLTIwMCBkYXJrOmJnLWVtZXJhbGQtOTUwLzcwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMyBoLTMgcm91bmRlZC1tZCBiZy1lbWVyYWxkLTQwMC82MFwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHJvdW5kZWQtbWQgYmctZW1lcmFsZC01MDAvODBcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0zIGgtMyByb3VuZGVkLW1kIGJnLWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8c3Bhbj7gpIXgpKfgpL/gpJUgKDEwMCUpPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU2VsZWN0ZWQgSGVhdG1hcCBEYXkgRGV0YWlscyBDYXJkICovfVxuICAgICAgICB7c2VsZWN0ZWRIZWF0bWFwRGF5ICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTIgcC0zIHJvdW5kZWQtMnhsIGJnLXN0b25lLTUwIGRhcms6Ymctc3RvbmUtODAwLzUwIGJvcmRlciBib3JkZXItc3RvbmUtMjAwIGRhcms6Ym9yZGVyLXN0b25lLTcwMC82MCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXN0b25lLTgwMCBkYXJrOnRleHQtc3RvbmUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8c3Bhbj57Zm9ybWF0RGF0ZVRvSGluZGkoc2VsZWN0ZWRIZWF0bWFwRGF5KX08L3NwYW4+XG4gICAgICAgICAgICAgIHtoaXN0b3J5W3NlbGVjdGVkSGVhdG1hcERheV0gPyAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTcwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAg4KSw4KS/4KSV4KWJ4KSw4KWN4KShIOCkruCljOCknOClguCkplxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXN0b25lLTQwMFwiPuCkleCli+CkiCDgpKHgpYfgpJ/gpL4g4KSo4KS54KWA4KSCPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEhhYml0LWJ5LUhhYml0IFN0cmVha3MgQnJlYWtkb3duICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgcm91bmRlZC0zeGwgYmctd2hpdGUgZGFyazpiZy1zdG9uZS05MDAgYm9yZGVyIGJvcmRlci1zdG9uZS0yMDAvODAgZGFyazpib3JkZXItc3RvbmUtODAwIHNoYWRvdy14cyBzcGFjZS15LTNcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXN0b25lLTkwMCBkYXJrOnRleHQtc3RvbmUtMTAwIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgIDxBd2FyZCBzaXplPXsxNn0gY2xhc3NOYW1lPVwidGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPuCkquCljeCksOCkpOCljeCkr+Clh+CklSDgpIbgpKbgpKQg4KSV4KWAIOCkuOCljeCkn+CljeCksOClgOCklSDgpLjgpY3gpKXgpL/gpKTgpL88L3NwYW4+XG4gICAgICAgIDwvaDM+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIuNVwiPlxuICAgICAgICAgIHthY3RpdmVIYWJpdHMubWFwKChoYWJpdCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3RyZWFrID0gY2FsY3VsYXRlSGFiaXRTdHJlYWsoaGFiaXQsIGhpc3RvcnkpO1xuICAgICAgICAgICAgY29uc3QgY29sb3JTY2hlbWUgPSBnZXRDb2xvclNjaGVtZShoYWJpdC5jb2xvcik7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e2hhYml0LmlkfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLTJ4bCBiZy1zdG9uZS01MCBkYXJrOmJnLXN0b25lLTgwMC82MCBib3JkZXIgYm9yZGVyLXN0b25lLTIwMC83MCBkYXJrOmJvcmRlci1zdG9uZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctOSBoLTkgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMCBib3JkZXIgJHtjb2xvclNjaGVtZS5iZ30gJHtjb2xvclNjaGVtZS5ib3JkZXJ9ICR7Y29sb3JTY2hlbWUudGV4dH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8SGFiaXRJY29uIG5hbWU9e2hhYml0Lmljb259IHNpemU9ezE4fSAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi13LTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc3RvbmUtOTAwIGRhcms6dGV4dC1zdG9uZS0xMDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aGFiaXQubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oNT5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zdG9uZS01MDAgZGFyazp0ZXh0LXN0b25lLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIOCkleClgeCksiDgpKrgpYLgpLDgpY3gpKM6IHtzdHJlYWsudG90YWxDb21wbGV0aW9uc30g4KSs4KS+4KSwXG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgey8qIEN1cnJlbnQgU3RyZWFrICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkLXhsIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTcwMCBkYXJrOnRleHQtYW1iZXItNDAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1zZW1pYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPEZsYW1lIHNpemU9ezEyfSBjbGFzc05hbWU9XCJmaWxsLWFtYmVyLTUwMCB0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+4KS14KSw4KWN4KSk4KSu4KS+4KSoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJsYWNrXCI+e3N0cmVhay5jdXJyZW50U3RyZWFrfSDgpKbgpL/gpKg8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIExvbmdlc3QgU3RyZWFrICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMjAgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8VHJvcGh5IHNpemU9ezExfSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7gpLjgpLDgpY3gpLXgpLbgpY3gpLDgpYfgpLfgpY3gpKA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYmxhY2tcIj57c3RyZWFrLmxvbmdlc3RTdHJlYWt9IOCkpuCkv+CkqDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19