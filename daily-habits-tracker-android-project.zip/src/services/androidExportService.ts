const JSZip = __vite__cjsImport0_jszip;import __vite__cjsImport0_jszip from "/node_modules/.vite/deps/jszip.js?v=768266e3";
/**
* Returns real status of pre-compiled APK in the current cloud sandbox environment.
* In accordance with strict integrity guidelines: We NEVER fake or simulate APK files.
*/
export function getApkBuildInfo() {
	return {
		isAvailable: false,
		limitationExplanationHindi: "वर्तमान क्लाउड वेब सैंडबॉक्स वातावरण में सीधे APK संकलित करने के लिए आवश्यक Android SDK और Gradle उपलब्ध नहीं हैं। इसलिए यहाँ कोई नकली या डमी APK डाउनलोड लिंक नहीं दिया गया है। आप नीचे दिए गए बटन से संपूर्ण प्रोजेक्ट स्रोत फ़ाइलें (ZIP) डाउनलोड करके Android Studio या मुफ्त GitHub Actions के माध्यम से 2 मिनट में असली APK बना सकते हैं।"
	};
}
// Helper to fetch file content from dev server
async function fetchSourceFile(path) {
	try {
		const res = await fetch(path);
		if (res.ok) {
			return await res.text();
		}
	} catch (e) {
		console.warn(`Could not fetch ${path}`, e);
	}
	return null;
}
/**
* Generates and downloads a complete, ready-to-build Android & Capacitor project ZIP package.
*/
export async function downloadAndroidProjectZip() {
	const zip = new JSZip();
	// 1. AndroidManifest.xml
	const androidManifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.dailyhabits.tracker">

    <!-- Permissions required for Habits app -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="मेरी अच्छी आदतें"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme">

        <activity
            android:name=".MainActivity"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode|navigation"
            android:exported="true"
            android:label="मेरी अच्छी आदतें"
            android:launchMode="singleTask"
            android:theme="@style/AppTheme.NoActionBarLaunch">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>
    </application>
</manifest>`;
	// 2. capacitor.config.ts
	const capacitorConfigTs = `import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.dailyhabits.tracker',
  appName: 'Daily Habits – मेरी अच्छी आदतें',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    androidScheme: 'https',
  },
};

export default config;
`;
	// 3. capacitor.config.json
	const capacitorConfigJson = {
		appId: "com.dailyhabits.tracker",
		appName: "Daily Habits – मेरी अच्छी आदतें",
		webDir: "dist",
		bundledWebRuntime: false,
		server: { androidScheme: "https" }
	};
	// 4. MainActivity.java
	const mainActivityJava = `package com.dailyhabits.tracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
`;
	// 5. strings.xml
	const stringsXml = `<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">मेरी अच्छी आदतें</string>
    <string name="title_activity_main">मेरी अच्छी आदतें</string>
    <string name="package_name">com.dailyhabits.tracker</string>
    <string name="custom_url_scheme">com.dailyhabits.tracker</string>
</resources>
`;
	// 6. styles.xml
	const stylesXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.Light.NoActionBar">
        <item name="colorPrimary">#047857</item>
        <item name="colorPrimaryDark">#064e3b</item>
        <item name="colorAccent">#10b981</item>
    </style>
    <style name="AppTheme.NoActionBarLaunch" parent="AppTheme">
        <item name="android:background">#ffffff</item>
    </style>
</resources>
`;
	// 7. app build.gradle
	const appBuildGradle = `apply plugin: 'com.android.application'

android {
    namespace "com.dailyhabits.tracker"
    compileSdk rootProject.ext.compileSdkVersion

    defaultConfig {
        applicationId "com.dailyhabits.tracker"
        minSdkVersion rootProject.ext.minSdkVersion
        targetSdkVersion rootProject.ext.targetSdkVersion
        versionCode 1
        versionName "1.0.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation fileTree(dir: 'libs', include: ['*.jar'])
    implementation "androidx.appcompat:appcompat:\$androidxAppCompatVersion"
    implementation "androidx.coordinatorlayout:coordinatorlayout:\$androidxCoordinatorLayoutVersion"
    implementation "androidx.core:core-splashscreen:\$coreSplashScreenVersion"
    implementation project(':capacitor-android')
    implementation project(':capacitor-cordova-android-plugins')
}
`;
	// 8. variables.gradle
	const variablesGradle = `ext {
    minSdkVersion = 24
    compileSdkVersion = 34
    targetSdkVersion = 34
    androidxActivityVersion = '1.8.2'
    androidxAppCompatVersion = '1.6.1'
    androidxCoordinatorLayoutVersion = '1.2.0'
    androidxCoreVersion = '1.12.0'
    coreSplashScreenVersion = '1.0.1'
    cordovaAndroidVersion = '10.1.1'
}
`;
	// 9. gradle.properties
	const gradleProperties = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
`;
	// 10. GitHub Actions workflow
	const githubWorkflow = `name: Android APK ऑटोमैटिक बिल्ड (Build Debug APK)

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build-android-apk:
    name: Build Android APK
    runs-on: ubuntu-latest

    steps:
      - name: 1. कोड चेकआउट करें (Checkout Repository)
        uses: actions/checkout@v4

      - name: 2. जावा सेटअप करें (Setup Java JDK 17)
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: 3. एंड्रॉइड एसडीके सेटअप करें (Setup Android SDK)
        uses: android-actions/setup-android@v3

      - name: 4. Node.js 20 सेटअप करें (Setup Node.js)
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: 5. डिपेंडेंसी इनस्टॉल करें (Install Dependencies)
        run: npm ci

      - name: 6. वेब ऐप बिल्ड करें (Vite Build)
        run: npm run build

      - name: 7. कैपेसिटर एंड्रॉइड सिंक करें (Capacitor Sync)
        run: |
          if [ ! -d "android" ]; then
            npx cap add android
          fi
          npx cap sync android

      - name: 8. एंड्रॉइड डिबग APK संकलित करें (Assemble Debug APK)
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon --stacktrace

      - name: 9. तैयार APK डाउनलोड के लिए अपलोड करें (Upload Artifact)
        uses: actions/upload-artifact@v4
        with:
          name: DailyHabits-Hindi-Debug-APK
          path: android/app/build/outputs/apk/debug/app-debug.apk
          retention-days: 30
`;
	// Add configuration and root files to zip
	zip.file("capacitor.config.ts", capacitorConfigTs);
	zip.file("capacitor.config.json", JSON.stringify(capacitorConfigJson, null, 2));
	zip.file(".github/workflows/build-apk.yml", githubWorkflow);
	// Fetch or fallback README.md and package.json
	const readmeContent = await fetchSourceFile("/README.md");
	if (readmeContent) {
		zip.file("README.md", readmeContent);
	}
	const packageJsonContent = await fetchSourceFile("/package.json");
	if (packageJsonContent) {
		zip.file("package.json", packageJsonContent);
	}
	const tsconfigContent = await fetchSourceFile("/tsconfig.json");
	if (tsconfigContent) {
		zip.file("tsconfig.json", tsconfigContent);
	}
	const viteConfigContent = await fetchSourceFile("/vite.config.ts");
	if (viteConfigContent) {
		zip.file("vite.config.ts", viteConfigContent);
	}
	const indexHtmlContent = await fetchSourceFile("/index.html");
	if (indexHtmlContent) {
		zip.file("index.html", indexHtmlContent);
	}
	// Add Android configuration tree
	const androidFolder = zip.folder("android");
	if (androidFolder) {
		androidFolder.file("variables.gradle", variablesGradle);
		androidFolder.file("gradle.properties", gradleProperties);
		const appFolder = androidFolder.folder("app");
		if (appFolder) {
			appFolder.file("build.gradle", appBuildGradle);
			const srcMain = appFolder.folder("src/main");
			if (srcMain) {
				srcMain.file("AndroidManifest.xml", androidManifest);
				const javaFolder = srcMain.folder("java/com/dailyhabits/tracker");
				if (javaFolder) {
					javaFolder.file("MainActivity.java", mainActivityJava);
				}
				const resValues = srcMain.folder("res/values");
				if (resValues) {
					resValues.file("strings.xml", stringsXml);
					resValues.file("styles.xml", stylesXml);
				}
			}
		}
	}
	// Fetch and pack all source code files from src/
	const srcFiles = [
		"src/main.tsx",
		"src/App.tsx",
		"src/index.css",
		"src/types/habit.ts",
		"src/services/storageService.ts",
		"src/services/streakService.ts",
		"src/services/notificationService.ts",
		"src/services/androidExportService.ts",
		"src/components/Header.tsx",
		"src/components/BottomNav.tsx",
		"src/components/TodayTab.tsx",
		"src/components/HabitsTab.tsx",
		"src/components/ProgressTab.tsx",
		"src/components/SettingsTab.tsx",
		"src/components/HabitFormModal.tsx",
		"src/components/ConfirmModal.tsx",
		"src/components/ReminderToast.tsx",
		"src/components/HabitIcon.tsx",
		"src/components/AndroidApkModal.tsx"
	];
	await Promise.all(srcFiles.map(async (filePath) => {
		const content = await fetchSourceFile("/" + filePath);
		if (content) {
			zip.file(filePath, content);
		}
	}));
	// Generate ZIP blob and trigger client download
	const blob = await zip.generateAsync({ type: "blob" });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "daily-habits-tracker-android-project.zip";
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	URL.revokeObjectURL(url);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7OztBQWNsQixPQUFPLFNBQVMsa0JBQWdDO0NBQzlDLE9BQU87RUFDTCxhQUFhO0VBQ2IsNEJBQ0U7Q0FDSjtBQUNGOztBQUdBLGVBQWUsZ0JBQWdCLE1BQXNDO0NBQ25FLElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLElBQUk7RUFDNUIsSUFBSSxJQUFJLElBQUk7R0FDVixPQUFPLE1BQU0sSUFBSSxLQUFLO0VBQ3hCO0NBQ0YsU0FBUyxHQUFHO0VBQ1YsUUFBUSxLQUFLLG1CQUFtQixRQUFRLENBQUM7Q0FDM0M7Q0FDQSxPQUFPO0FBQ1Q7Ozs7QUFLQSxPQUFPLGVBQWUsNEJBQTJDO0NBQy9ELE1BQU0sTUFBTSxJQUFJLE1BQU07O0NBR3RCLE1BQU0sa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBK0N4QixNQUFNLG9CQUFvQjs7Ozs7Ozs7Ozs7Ozs7O0NBZ0IxQixNQUFNLHNCQUFzQjtFQUMxQixPQUFPO0VBQ1AsU0FBUztFQUNULFFBQVE7RUFDUixtQkFBbUI7RUFDbkIsUUFBUSxFQUNOLGVBQWUsUUFDakI7Q0FDRjs7Q0FHQSxNQUFNLG1CQUFtQjs7Ozs7OztDQVF6QixNQUFNLGFBQWE7Ozs7Ozs7OztDQVVuQixNQUFNLFlBQVk7Ozs7Ozs7Ozs7Ozs7Q0FjbEIsTUFBTSxpQkFBaUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FzQ3ZCLE1BQU0sa0JBQWtCOzs7Ozs7Ozs7Ozs7O0NBY3hCLE1BQU0sbUJBQW1COzs7OztDQU16QixNQUFNLGlCQUFpQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBNkR2QixJQUFJLEtBQUssdUJBQXVCLGlCQUFpQjtDQUNqRCxJQUFJLEtBQUsseUJBQXlCLEtBQUssVUFBVSxxQkFBcUIsTUFBTSxDQUFDLENBQUM7Q0FDOUUsSUFBSSxLQUFLLG1DQUFtQyxjQUFjOztDQUcxRCxNQUFNLGdCQUFnQixNQUFNLGdCQUFnQixZQUFZO0NBQ3hELElBQUksZUFBZTtFQUNqQixJQUFJLEtBQUssYUFBYSxhQUFhO0NBQ3JDO0NBRUEsTUFBTSxxQkFBcUIsTUFBTSxnQkFBZ0IsZUFBZTtDQUNoRSxJQUFJLG9CQUFvQjtFQUN0QixJQUFJLEtBQUssZ0JBQWdCLGtCQUFrQjtDQUM3QztDQUVBLE1BQU0sa0JBQWtCLE1BQU0sZ0JBQWdCLGdCQUFnQjtDQUM5RCxJQUFJLGlCQUFpQjtFQUNuQixJQUFJLEtBQUssaUJBQWlCLGVBQWU7Q0FDM0M7Q0FFQSxNQUFNLG9CQUFvQixNQUFNLGdCQUFnQixpQkFBaUI7Q0FDakUsSUFBSSxtQkFBbUI7RUFDckIsSUFBSSxLQUFLLGtCQUFrQixpQkFBaUI7Q0FDOUM7Q0FFQSxNQUFNLG1CQUFtQixNQUFNLGdCQUFnQixhQUFhO0NBQzVELElBQUksa0JBQWtCO0VBQ3BCLElBQUksS0FBSyxjQUFjLGdCQUFnQjtDQUN6Qzs7Q0FHQSxNQUFNLGdCQUFnQixJQUFJLE9BQU8sU0FBUztDQUMxQyxJQUFJLGVBQWU7RUFDakIsY0FBYyxLQUFLLG9CQUFvQixlQUFlO0VBQ3RELGNBQWMsS0FBSyxxQkFBcUIsZ0JBQWdCO0VBRXhELE1BQU0sWUFBWSxjQUFjLE9BQU8sS0FBSztFQUM1QyxJQUFJLFdBQVc7R0FDYixVQUFVLEtBQUssZ0JBQWdCLGNBQWM7R0FDN0MsTUFBTSxVQUFVLFVBQVUsT0FBTyxVQUFVO0dBQzNDLElBQUksU0FBUztJQUNYLFFBQVEsS0FBSyx1QkFBdUIsZUFBZTtJQUVuRCxNQUFNLGFBQWEsUUFBUSxPQUFPLDhCQUE4QjtJQUNoRSxJQUFJLFlBQVk7S0FDZCxXQUFXLEtBQUsscUJBQXFCLGdCQUFnQjtJQUN2RDtJQUVBLE1BQU0sWUFBWSxRQUFRLE9BQU8sWUFBWTtJQUM3QyxJQUFJLFdBQVc7S0FDYixVQUFVLEtBQUssZUFBZSxVQUFVO0tBQ3hDLFVBQVUsS0FBSyxjQUFjLFNBQVM7SUFDeEM7R0FDRjtFQUNGO0NBQ0Y7O0NBR0EsTUFBTSxXQUFXO0VBQ2Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUVBLE1BQU0sUUFBUSxJQUNaLFNBQVMsSUFBSSxPQUFPLGFBQWE7RUFDL0IsTUFBTSxVQUFVLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUTtFQUNwRCxJQUFJLFNBQVM7R0FDWCxJQUFJLEtBQUssVUFBVSxPQUFPO0VBQzVCO0NBQ0YsQ0FBQyxDQUNIOztDQUdBLE1BQU0sT0FBTyxNQUFNLElBQUksY0FBYyxFQUFFLE1BQU0sT0FBTyxDQUFDO0NBQ3JELE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0NBQ3BDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztDQUNwQyxFQUFFLE9BQU87Q0FDVCxFQUFFLFdBQVc7Q0FDYixTQUFTLEtBQUssWUFBWSxDQUFDO0NBQzNCLEVBQUUsTUFBTTtDQUNSLFNBQVMsS0FBSyxZQUFZLENBQUM7Q0FDM0IsSUFBSSxnQkFBZ0IsR0FBRztBQUN6QiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJhbmRyb2lkRXhwb3J0U2VydmljZS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSlNaaXAgZnJvbSAnanN6aXAnO1xuXG5leHBvcnQgaW50ZXJmYWNlIEFwa0J1aWxkSW5mbyB7XG4gIGlzQXZhaWxhYmxlOiBib29sZWFuO1xuICBmaWxlTmFtZT86IHN0cmluZztcbiAgZmlsZVNpemU/OiBzdHJpbmc7XG4gIGRvd25sb2FkVXJsPzogc3RyaW5nO1xuICBsaW1pdGF0aW9uRXhwbGFuYXRpb25IaW5kaTogc3RyaW5nO1xufVxuXG4vKipcbiAqIFJldHVybnMgcmVhbCBzdGF0dXMgb2YgcHJlLWNvbXBpbGVkIEFQSyBpbiB0aGUgY3VycmVudCBjbG91ZCBzYW5kYm94IGVudmlyb25tZW50LlxuICogSW4gYWNjb3JkYW5jZSB3aXRoIHN0cmljdCBpbnRlZ3JpdHkgZ3VpZGVsaW5lczogV2UgTkVWRVIgZmFrZSBvciBzaW11bGF0ZSBBUEsgZmlsZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRBcGtCdWlsZEluZm8oKTogQXBrQnVpbGRJbmZvIHtcbiAgcmV0dXJuIHtcbiAgICBpc0F2YWlsYWJsZTogZmFsc2UsXG4gICAgbGltaXRhdGlvbkV4cGxhbmF0aW9uSGluZGk6XG4gICAgICAn4KS14KSw4KWN4KSk4KSu4KS+4KSoIOCkleCljeCksuCkvuCkieCkoSDgpLXgpYfgpKwg4KS44KWI4KSC4KSh4KSs4KWJ4KSV4KWN4KS4IOCkteCkvuCkpOCkvuCkteCksOCkoyDgpK7gpYfgpIIg4KS44KWA4KSn4KWHIEFQSyDgpLjgpILgpJXgpLLgpL/gpKQg4KSV4KSw4KSo4KWHIOCkleClhyDgpLLgpL/gpI8g4KSG4KS14KS24KWN4KSv4KSVIEFuZHJvaWQgU0RLIOCklOCksCBHcmFkbGUg4KSJ4KSq4KSy4KSs4KWN4KSnIOCkqOCkueClgOCkgiDgpLngpYjgpILgpaQg4KSH4KS44KSy4KS/4KSPIOCkr+CkueCkvuCkgSDgpJXgpYvgpIgg4KSo4KSV4KSy4KWAIOCkr+CkviDgpKHgpK7gpYAgQVBLIOCkoeCkvuCkieCkqOCksuCli+CkoSDgpLLgpL/gpILgpJUg4KSo4KS54KWA4KSCIOCkpuCkv+Ckr+CkviDgpJfgpK/gpL4g4KS54KWI4KWkIOCkhuCkqiDgpKjgpYDgpJrgpYcg4KSm4KS/4KSPIOCkl+CkjyDgpKzgpJ/gpKgg4KS44KWHIOCkuOCkguCkquClguCksOCljeCkoyDgpKrgpY3gpLDgpYvgpJzgpYfgpJXgpY3gpJ8g4KS44KWN4KSw4KWL4KSkIOCkq+CkvOCkvuCkh+CksuClh+CkgiAoWklQKSDgpKHgpL7gpIngpKjgpLLgpYvgpKEg4KSV4KSw4KSV4KWHIEFuZHJvaWQgU3R1ZGlvIOCkr+CkviDgpK7gpYHgpKvgpY3gpKQgR2l0SHViIEFjdGlvbnMg4KSV4KWHIOCkruCkvuCkp+CljeCkr+CkriDgpLjgpYcgMiDgpK7gpL/gpKjgpJ8g4KSu4KWH4KSCIOCkheCkuOCksuClgCBBUEsg4KSs4KSo4KS+IOCkuOCkleCkpOClhyDgpLngpYjgpILgpaQnLFxuICB9O1xufVxuXG4vLyBIZWxwZXIgdG8gZmV0Y2ggZmlsZSBjb250ZW50IGZyb20gZGV2IHNlcnZlclxuYXN5bmMgZnVuY3Rpb24gZmV0Y2hTb3VyY2VGaWxlKHBhdGg6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICB0cnkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHBhdGgpO1xuICAgIGlmIChyZXMub2spIHtcbiAgICAgIHJldHVybiBhd2FpdCByZXMudGV4dCgpO1xuICAgIH1cbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUud2FybihgQ291bGQgbm90IGZldGNoICR7cGF0aH1gLCBlKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuLyoqXG4gKiBHZW5lcmF0ZXMgYW5kIGRvd25sb2FkcyBhIGNvbXBsZXRlLCByZWFkeS10by1idWlsZCBBbmRyb2lkICYgQ2FwYWNpdG9yIHByb2plY3QgWklQIHBhY2thZ2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkb3dubG9hZEFuZHJvaWRQcm9qZWN0WmlwKCk6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcblxuICAvLyAxLiBBbmRyb2lkTWFuaWZlc3QueG1sXG4gIGNvbnN0IGFuZHJvaWRNYW5pZmVzdCA9IGA8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJ1dGYtOFwiPz5cbjxtYW5pZmVzdCB4bWxuczphbmRyb2lkPVwiaHR0cDovL3NjaGVtYXMuYW5kcm9pZC5jb20vYXBrL3Jlcy9hbmRyb2lkXCJcbiAgICBwYWNrYWdlPVwiY29tLmRhaWx5aGFiaXRzLnRyYWNrZXJcIj5cblxuICAgIDwhLS0gUGVybWlzc2lvbnMgcmVxdWlyZWQgZm9yIEhhYml0cyBhcHAgLS0+XG4gICAgPHVzZXMtcGVybWlzc2lvbiBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLnBlcm1pc3Npb24uSU5URVJORVRcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLkFDQ0VTU19ORVRXT1JLX1NUQVRFXCIgLz5cbiAgICA8dXNlcy1wZXJtaXNzaW9uIGFuZHJvaWQ6bmFtZT1cImFuZHJvaWQucGVybWlzc2lvbi5QT1NUX05PVElGSUNBVElPTlNcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLlZJQlJBVEVcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLlJFQ0VJVkVfQk9PVF9DT01QTEVURURcIiAvPlxuICAgIDx1c2VzLXBlcm1pc3Npb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5wZXJtaXNzaW9uLlNDSEVEVUxFX0VYQUNUX0FMQVJNXCIgLz5cblxuICAgIDxhcHBsaWNhdGlvblxuICAgICAgICBhbmRyb2lkOmFsbG93QmFja3VwPVwidHJ1ZVwiXG4gICAgICAgIGFuZHJvaWQ6aWNvbj1cIkBtaXBtYXAvaWNfbGF1bmNoZXJcIlxuICAgICAgICBhbmRyb2lkOmxhYmVsPVwi4KSu4KWH4KSw4KWAIOCkheCkmuCljeCkm+ClgCDgpIbgpKbgpKTgpYfgpIJcIlxuICAgICAgICBhbmRyb2lkOnJvdW5kSWNvbj1cIkBtaXBtYXAvaWNfbGF1bmNoZXJfcm91bmRcIlxuICAgICAgICBhbmRyb2lkOnN1cHBvcnRzUnRsPVwidHJ1ZVwiXG4gICAgICAgIGFuZHJvaWQ6dGhlbWU9XCJAc3R5bGUvQXBwVGhlbWVcIj5cblxuICAgICAgICA8YWN0aXZpdHlcbiAgICAgICAgICAgIGFuZHJvaWQ6bmFtZT1cIi5NYWluQWN0aXZpdHlcIlxuICAgICAgICAgICAgYW5kcm9pZDpjb25maWdDaGFuZ2VzPVwib3JpZW50YXRpb258a2V5Ym9hcmRIaWRkZW58a2V5Ym9hcmR8c2NyZWVuU2l6ZXxsb2NhbGV8c21hbGxlc3RTY3JlZW5TaXplfHNjcmVlbkxheW91dHx1aU1vZGV8bmF2aWdhdGlvblwiXG4gICAgICAgICAgICBhbmRyb2lkOmV4cG9ydGVkPVwidHJ1ZVwiXG4gICAgICAgICAgICBhbmRyb2lkOmxhYmVsPVwi4KSu4KWH4KSw4KWAIOCkheCkmuCljeCkm+ClgCDgpIbgpKbgpKTgpYfgpIJcIlxuICAgICAgICAgICAgYW5kcm9pZDpsYXVuY2hNb2RlPVwic2luZ2xlVGFza1wiXG4gICAgICAgICAgICBhbmRyb2lkOnRoZW1lPVwiQHN0eWxlL0FwcFRoZW1lLk5vQWN0aW9uQmFyTGF1bmNoXCI+XG5cbiAgICAgICAgICAgIDxpbnRlbnQtZmlsdGVyPlxuICAgICAgICAgICAgICAgIDxhY3Rpb24gYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5pbnRlbnQuYWN0aW9uLk1BSU5cIiAvPlxuICAgICAgICAgICAgICAgIDxjYXRlZ29yeSBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkLmludGVudC5jYXRlZ29yeS5MQVVOQ0hFUlwiIC8+XG4gICAgICAgICAgICA8L2ludGVudC1maWx0ZXI+XG4gICAgICAgIDwvYWN0aXZpdHk+XG5cbiAgICAgICAgPHByb3ZpZGVyXG4gICAgICAgICAgICBhbmRyb2lkOm5hbWU9XCJhbmRyb2lkeC5jb3JlLmNvbnRlbnQuRmlsZVByb3ZpZGVyXCJcbiAgICAgICAgICAgIGFuZHJvaWQ6YXV0aG9yaXRpZXM9XCJcXCR7YXBwbGljYXRpb25JZH0uZmlsZXByb3ZpZGVyXCJcbiAgICAgICAgICAgIGFuZHJvaWQ6ZXhwb3J0ZWQ9XCJmYWxzZVwiXG4gICAgICAgICAgICBhbmRyb2lkOmdyYW50VXJpUGVybWlzc2lvbnM9XCJ0cnVlXCI+XG4gICAgICAgICAgICA8bWV0YS1kYXRhXG4gICAgICAgICAgICAgICAgYW5kcm9pZDpuYW1lPVwiYW5kcm9pZC5zdXBwb3J0LkZJTEVfUFJPVklERVJfUEFUSFNcIlxuICAgICAgICAgICAgICAgIGFuZHJvaWQ6cmVzb3VyY2U9XCJAeG1sL2ZpbGVfcGF0aHNcIiAvPlxuICAgICAgICA8L3Byb3ZpZGVyPlxuICAgIDwvYXBwbGljYXRpb24+XG48L21hbmlmZXN0PmA7XG5cbiAgLy8gMi4gY2FwYWNpdG9yLmNvbmZpZy50c1xuICBjb25zdCBjYXBhY2l0b3JDb25maWdUcyA9IGBpbXBvcnQgdHlwZSB7IENhcGFjaXRvckNvbmZpZyB9IGZyb20gJ0BjYXBhY2l0b3IvY2xpJztcblxuY29uc3QgY29uZmlnOiBDYXBhY2l0b3JDb25maWcgPSB7XG4gIGFwcElkOiAnY29tLmRhaWx5aGFiaXRzLnRyYWNrZXInLFxuICBhcHBOYW1lOiAnRGFpbHkgSGFiaXRzIOKAkyDgpK7gpYfgpLDgpYAg4KSF4KSa4KWN4KSb4KWAIOCkhuCkpuCkpOClh+CkgicsXG4gIHdlYkRpcjogJ2Rpc3QnLFxuICBidW5kbGVkV2ViUnVudGltZTogZmFsc2UsXG4gIHNlcnZlcjoge1xuICAgIGFuZHJvaWRTY2hlbWU6ICdodHRwcycsXG4gIH0sXG59O1xuXG5leHBvcnQgZGVmYXVsdCBjb25maWc7XG5gO1xuXG4gIC8vIDMuIGNhcGFjaXRvci5jb25maWcuanNvblxuICBjb25zdCBjYXBhY2l0b3JDb25maWdKc29uID0ge1xuICAgIGFwcElkOiAnY29tLmRhaWx5aGFiaXRzLnRyYWNrZXInLFxuICAgIGFwcE5hbWU6ICdEYWlseSBIYWJpdHMg4oCTIOCkruClh+CksOClgCDgpIXgpJrgpY3gpJvgpYAg4KSG4KSm4KSk4KWH4KSCJyxcbiAgICB3ZWJEaXI6ICdkaXN0JyxcbiAgICBidW5kbGVkV2ViUnVudGltZTogZmFsc2UsXG4gICAgc2VydmVyOiB7XG4gICAgICBhbmRyb2lkU2NoZW1lOiAnaHR0cHMnLFxuICAgIH0sXG4gIH07XG5cbiAgLy8gNC4gTWFpbkFjdGl2aXR5LmphdmFcbiAgY29uc3QgbWFpbkFjdGl2aXR5SmF2YSA9IGBwYWNrYWdlIGNvbS5kYWlseWhhYml0cy50cmFja2VyO1xuXG5pbXBvcnQgY29tLmdldGNhcGFjaXRvci5CcmlkZ2VBY3Rpdml0eTtcblxucHVibGljIGNsYXNzIE1haW5BY3Rpdml0eSBleHRlbmRzIEJyaWRnZUFjdGl2aXR5IHt9XG5gO1xuXG4gIC8vIDUuIHN0cmluZ3MueG1sXG4gIGNvbnN0IHN0cmluZ3NYbWwgPSBgPD94bWwgdmVyc2lvbj0nMS4wJyBlbmNvZGluZz0ndXRmLTgnPz5cbjxyZXNvdXJjZXM+XG4gICAgPHN0cmluZyBuYW1lPVwiYXBwX25hbWVcIj7gpK7gpYfgpLDgpYAg4KSF4KSa4KWN4KSb4KWAIOCkhuCkpuCkpOClh+Ckgjwvc3RyaW5nPlxuICAgIDxzdHJpbmcgbmFtZT1cInRpdGxlX2FjdGl2aXR5X21haW5cIj7gpK7gpYfgpLDgpYAg4KSF4KSa4KWN4KSb4KWAIOCkhuCkpuCkpOClh+Ckgjwvc3RyaW5nPlxuICAgIDxzdHJpbmcgbmFtZT1cInBhY2thZ2VfbmFtZVwiPmNvbS5kYWlseWhhYml0cy50cmFja2VyPC9zdHJpbmc+XG4gICAgPHN0cmluZyBuYW1lPVwiY3VzdG9tX3VybF9zY2hlbWVcIj5jb20uZGFpbHloYWJpdHMudHJhY2tlcjwvc3RyaW5nPlxuPC9yZXNvdXJjZXM+XG5gO1xuXG4gIC8vIDYuIHN0eWxlcy54bWxcbiAgY29uc3Qgc3R5bGVzWG1sID0gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cInV0Zi04XCI/PlxuPHJlc291cmNlcz5cbiAgICA8c3R5bGUgbmFtZT1cIkFwcFRoZW1lXCIgcGFyZW50PVwiVGhlbWUuQXBwQ29tcGF0LkxpZ2h0Lk5vQWN0aW9uQmFyXCI+XG4gICAgICAgIDxpdGVtIG5hbWU9XCJjb2xvclByaW1hcnlcIj4jMDQ3ODU3PC9pdGVtPlxuICAgICAgICA8aXRlbSBuYW1lPVwiY29sb3JQcmltYXJ5RGFya1wiPiMwNjRlM2I8L2l0ZW0+XG4gICAgICAgIDxpdGVtIG5hbWU9XCJjb2xvckFjY2VudFwiPiMxMGI5ODE8L2l0ZW0+XG4gICAgPC9zdHlsZT5cbiAgICA8c3R5bGUgbmFtZT1cIkFwcFRoZW1lLk5vQWN0aW9uQmFyTGF1bmNoXCIgcGFyZW50PVwiQXBwVGhlbWVcIj5cbiAgICAgICAgPGl0ZW0gbmFtZT1cImFuZHJvaWQ6YmFja2dyb3VuZFwiPiNmZmZmZmY8L2l0ZW0+XG4gICAgPC9zdHlsZT5cbjwvcmVzb3VyY2VzPlxuYDtcblxuICAvLyA3LiBhcHAgYnVpbGQuZ3JhZGxlXG4gIGNvbnN0IGFwcEJ1aWxkR3JhZGxlID0gYGFwcGx5IHBsdWdpbjogJ2NvbS5hbmRyb2lkLmFwcGxpY2F0aW9uJ1xuXG5hbmRyb2lkIHtcbiAgICBuYW1lc3BhY2UgXCJjb20uZGFpbHloYWJpdHMudHJhY2tlclwiXG4gICAgY29tcGlsZVNkayByb290UHJvamVjdC5leHQuY29tcGlsZVNka1ZlcnNpb25cblxuICAgIGRlZmF1bHRDb25maWcge1xuICAgICAgICBhcHBsaWNhdGlvbklkIFwiY29tLmRhaWx5aGFiaXRzLnRyYWNrZXJcIlxuICAgICAgICBtaW5TZGtWZXJzaW9uIHJvb3RQcm9qZWN0LmV4dC5taW5TZGtWZXJzaW9uXG4gICAgICAgIHRhcmdldFNka1ZlcnNpb24gcm9vdFByb2plY3QuZXh0LnRhcmdldFNka1ZlcnNpb25cbiAgICAgICAgdmVyc2lvbkNvZGUgMVxuICAgICAgICB2ZXJzaW9uTmFtZSBcIjEuMC4wXCJcbiAgICAgICAgdGVzdEluc3RydW1lbnRhdGlvblJ1bm5lciBcImFuZHJvaWR4LnRlc3QucnVubmVyLkFuZHJvaWRKVW5pdFJ1bm5lclwiXG4gICAgfVxuXG4gICAgYnVpbGRUeXBlcyB7XG4gICAgICAgIHJlbGVhc2Uge1xuICAgICAgICAgICAgbWluaWZ5RW5hYmxlZCBmYWxzZVxuICAgICAgICAgICAgcHJvZ3VhcmRGaWxlcyBnZXREZWZhdWx0UHJvZ3VhcmRGaWxlKCdwcm9ndWFyZC1hbmRyb2lkLW9wdGltaXplLnR4dCcpLCAncHJvZ3VhcmQtcnVsZXMucHJvJ1xuICAgICAgICB9XG4gICAgfVxuICAgIGNvbXBpbGVPcHRpb25zIHtcbiAgICAgICAgc291cmNlQ29tcGF0aWJpbGl0eSBKYXZhVmVyc2lvbi5WRVJTSU9OXzE3XG4gICAgICAgIHRhcmdldENvbXBhdGliaWxpdHkgSmF2YVZlcnNpb24uVkVSU0lPTl8xN1xuICAgIH1cbn1cblxuZGVwZW5kZW5jaWVzIHtcbiAgICBpbXBsZW1lbnRhdGlvbiBmaWxlVHJlZShkaXI6ICdsaWJzJywgaW5jbHVkZTogWycqLmphciddKVxuICAgIGltcGxlbWVudGF0aW9uIFwiYW5kcm9pZHguYXBwY29tcGF0OmFwcGNvbXBhdDpcXCRhbmRyb2lkeEFwcENvbXBhdFZlcnNpb25cIlxuICAgIGltcGxlbWVudGF0aW9uIFwiYW5kcm9pZHguY29vcmRpbmF0b3JsYXlvdXQ6Y29vcmRpbmF0b3JsYXlvdXQ6XFwkYW5kcm9pZHhDb29yZGluYXRvckxheW91dFZlcnNpb25cIlxuICAgIGltcGxlbWVudGF0aW9uIFwiYW5kcm9pZHguY29yZTpjb3JlLXNwbGFzaHNjcmVlbjpcXCRjb3JlU3BsYXNoU2NyZWVuVmVyc2lvblwiXG4gICAgaW1wbGVtZW50YXRpb24gcHJvamVjdCgnOmNhcGFjaXRvci1hbmRyb2lkJylcbiAgICBpbXBsZW1lbnRhdGlvbiBwcm9qZWN0KCc6Y2FwYWNpdG9yLWNvcmRvdmEtYW5kcm9pZC1wbHVnaW5zJylcbn1cbmA7XG5cbiAgLy8gOC4gdmFyaWFibGVzLmdyYWRsZVxuICBjb25zdCB2YXJpYWJsZXNHcmFkbGUgPSBgZXh0IHtcbiAgICBtaW5TZGtWZXJzaW9uID0gMjRcbiAgICBjb21waWxlU2RrVmVyc2lvbiA9IDM0XG4gICAgdGFyZ2V0U2RrVmVyc2lvbiA9IDM0XG4gICAgYW5kcm9pZHhBY3Rpdml0eVZlcnNpb24gPSAnMS44LjInXG4gICAgYW5kcm9pZHhBcHBDb21wYXRWZXJzaW9uID0gJzEuNi4xJ1xuICAgIGFuZHJvaWR4Q29vcmRpbmF0b3JMYXlvdXRWZXJzaW9uID0gJzEuMi4wJ1xuICAgIGFuZHJvaWR4Q29yZVZlcnNpb24gPSAnMS4xMi4wJ1xuICAgIGNvcmVTcGxhc2hTY3JlZW5WZXJzaW9uID0gJzEuMC4xJ1xuICAgIGNvcmRvdmFBbmRyb2lkVmVyc2lvbiA9ICcxMC4xLjEnXG59XG5gO1xuXG4gIC8vIDkuIGdyYWRsZS5wcm9wZXJ0aWVzXG4gIGNvbnN0IGdyYWRsZVByb3BlcnRpZXMgPSBgb3JnLmdyYWRsZS5qdm1hcmdzPS1YbXgyMDQ4bSAtRGZpbGUuZW5jb2Rpbmc9VVRGLThcbmFuZHJvaWQudXNlQW5kcm9pZFg9dHJ1ZVxuYW5kcm9pZC5lbmFibGVKZXRpZmllcj10cnVlXG5gO1xuXG4gIC8vIDEwLiBHaXRIdWIgQWN0aW9ucyB3b3JrZmxvd1xuICBjb25zdCBnaXRodWJXb3JrZmxvdyA9IGBuYW1lOiBBbmRyb2lkIEFQSyDgpJHgpJ/gpYvgpK7gpYjgpJ/gpL/gpJUg4KSs4KS/4KSy4KWN4KShIChCdWlsZCBEZWJ1ZyBBUEspXG5cbm9uOlxuICBwdXNoOlxuICAgIGJyYW5jaGVzOiBbIG1haW4sIG1hc3RlciBdXG4gIHB1bGxfcmVxdWVzdDpcbiAgICBicmFuY2hlczogWyBtYWluLCBtYXN0ZXIgXVxuICB3b3JrZmxvd19kaXNwYXRjaDpcblxuam9iczpcbiAgYnVpbGQtYW5kcm9pZC1hcGs6XG4gICAgbmFtZTogQnVpbGQgQW5kcm9pZCBBUEtcbiAgICBydW5zLW9uOiB1YnVudHUtbGF0ZXN0XG5cbiAgICBzdGVwczpcbiAgICAgIC0gbmFtZTogMS4g4KSV4KWL4KShIOCkmuClh+CkleCkhuCkieCknyDgpJXgpLDgpYfgpIIgKENoZWNrb3V0IFJlcG9zaXRvcnkpXG4gICAgICAgIHVzZXM6IGFjdGlvbnMvY2hlY2tvdXRAdjRcblxuICAgICAgLSBuYW1lOiAyLiDgpJzgpL7gpLXgpL4g4KS44KWH4KSf4KSF4KSqIOCkleCksOClh+CkgiAoU2V0dXAgSmF2YSBKREsgMTcpXG4gICAgICAgIHVzZXM6IGFjdGlvbnMvc2V0dXAtamF2YUB2NFxuICAgICAgICB3aXRoOlxuICAgICAgICAgIGRpc3RyaWJ1dGlvbjogJ3RlbXVyaW4nXG4gICAgICAgICAgamF2YS12ZXJzaW9uOiAnMTcnXG5cbiAgICAgIC0gbmFtZTogMy4g4KSP4KSC4KSh4KWN4KSw4KWJ4KSH4KShIOCkj+CkuOCkoeClgOCkleClhyDgpLjgpYfgpJ/gpIXgpKog4KSV4KSw4KWH4KSCIChTZXR1cCBBbmRyb2lkIFNESylcbiAgICAgICAgdXNlczogYW5kcm9pZC1hY3Rpb25zL3NldHVwLWFuZHJvaWRAdjNcblxuICAgICAgLSBuYW1lOiA0LiBOb2RlLmpzIDIwIOCkuOClh+Ckn+CkheCkqiDgpJXgpLDgpYfgpIIgKFNldHVwIE5vZGUuanMpXG4gICAgICAgIHVzZXM6IGFjdGlvbnMvc2V0dXAtbm9kZUB2NFxuICAgICAgICB3aXRoOlxuICAgICAgICAgIG5vZGUtdmVyc2lvbjogMjBcbiAgICAgICAgICBjYWNoZTogJ25wbSdcblxuICAgICAgLSBuYW1lOiA1LiDgpKHgpL/gpKrgpYfgpILgpKHgpYfgpILgpLjgpYAg4KSH4KSo4KS44KWN4KSf4KWJ4KSyIOCkleCksOClh+CkgiAoSW5zdGFsbCBEZXBlbmRlbmNpZXMpXG4gICAgICAgIHJ1bjogbnBtIGNpXG5cbiAgICAgIC0gbmFtZTogNi4g4KS14KWH4KSsIOCkkOCkqiDgpKzgpL/gpLLgpY3gpKEg4KSV4KSw4KWH4KSCIChWaXRlIEJ1aWxkKVxuICAgICAgICBydW46IG5wbSBydW4gYnVpbGRcblxuICAgICAgLSBuYW1lOiA3LiDgpJXgpYjgpKrgpYfgpLjgpL/gpJ/gpLAg4KSP4KSC4KSh4KWN4KSw4KWJ4KSH4KShIOCkuOCkv+CkguCklSDgpJXgpLDgpYfgpIIgKENhcGFjaXRvciBTeW5jKVxuICAgICAgICBydW46IHxcbiAgICAgICAgICBpZiBbICEgLWQgXCJhbmRyb2lkXCIgXTsgdGhlblxuICAgICAgICAgICAgbnB4IGNhcCBhZGQgYW5kcm9pZFxuICAgICAgICAgIGZpXG4gICAgICAgICAgbnB4IGNhcCBzeW5jIGFuZHJvaWRcblxuICAgICAgLSBuYW1lOiA4LiDgpI/gpILgpKHgpY3gpLDgpYngpIfgpKEg4KSh4KS/4KSs4KSXIEFQSyDgpLjgpILgpJXgpLLgpL/gpKQg4KSV4KSw4KWH4KSCIChBc3NlbWJsZSBEZWJ1ZyBBUEspXG4gICAgICAgIHJ1bjogfFxuICAgICAgICAgIGNkIGFuZHJvaWRcbiAgICAgICAgICBjaG1vZCAreCBncmFkbGV3XG4gICAgICAgICAgLi9ncmFkbGV3IGFzc2VtYmxlRGVidWcgLS1uby1kYWVtb24gLS1zdGFja3RyYWNlXG5cbiAgICAgIC0gbmFtZTogOS4g4KSk4KWI4KSv4KS+4KSwIEFQSyDgpKHgpL7gpIngpKjgpLLgpYvgpKEg4KSV4KWHIOCksuCkv+CkjyDgpIXgpKrgpLLgpYvgpKEg4KSV4KSw4KWH4KSCIChVcGxvYWQgQXJ0aWZhY3QpXG4gICAgICAgIHVzZXM6IGFjdGlvbnMvdXBsb2FkLWFydGlmYWN0QHY0XG4gICAgICAgIHdpdGg6XG4gICAgICAgICAgbmFtZTogRGFpbHlIYWJpdHMtSGluZGktRGVidWctQVBLXG4gICAgICAgICAgcGF0aDogYW5kcm9pZC9hcHAvYnVpbGQvb3V0cHV0cy9hcGsvZGVidWcvYXBwLWRlYnVnLmFwa1xuICAgICAgICAgIHJldGVudGlvbi1kYXlzOiAzMFxuYDtcblxuICAvLyBBZGQgY29uZmlndXJhdGlvbiBhbmQgcm9vdCBmaWxlcyB0byB6aXBcbiAgemlwLmZpbGUoJ2NhcGFjaXRvci5jb25maWcudHMnLCBjYXBhY2l0b3JDb25maWdUcyk7XG4gIHppcC5maWxlKCdjYXBhY2l0b3IuY29uZmlnLmpzb24nLCBKU09OLnN0cmluZ2lmeShjYXBhY2l0b3JDb25maWdKc29uLCBudWxsLCAyKSk7XG4gIHppcC5maWxlKCcuZ2l0aHViL3dvcmtmbG93cy9idWlsZC1hcGsueW1sJywgZ2l0aHViV29ya2Zsb3cpO1xuXG4gIC8vIEZldGNoIG9yIGZhbGxiYWNrIFJFQURNRS5tZCBhbmQgcGFja2FnZS5qc29uXG4gIGNvbnN0IHJlYWRtZUNvbnRlbnQgPSBhd2FpdCBmZXRjaFNvdXJjZUZpbGUoJy9SRUFETUUubWQnKTtcbiAgaWYgKHJlYWRtZUNvbnRlbnQpIHtcbiAgICB6aXAuZmlsZSgnUkVBRE1FLm1kJywgcmVhZG1lQ29udGVudCk7XG4gIH1cblxuICBjb25zdCBwYWNrYWdlSnNvbkNvbnRlbnQgPSBhd2FpdCBmZXRjaFNvdXJjZUZpbGUoJy9wYWNrYWdlLmpzb24nKTtcbiAgaWYgKHBhY2thZ2VKc29uQ29udGVudCkge1xuICAgIHppcC5maWxlKCdwYWNrYWdlLmpzb24nLCBwYWNrYWdlSnNvbkNvbnRlbnQpO1xuICB9XG5cbiAgY29uc3QgdHNjb25maWdDb250ZW50ID0gYXdhaXQgZmV0Y2hTb3VyY2VGaWxlKCcvdHNjb25maWcuanNvbicpO1xuICBpZiAodHNjb25maWdDb250ZW50KSB7XG4gICAgemlwLmZpbGUoJ3RzY29uZmlnLmpzb24nLCB0c2NvbmZpZ0NvbnRlbnQpO1xuICB9XG5cbiAgY29uc3Qgdml0ZUNvbmZpZ0NvbnRlbnQgPSBhd2FpdCBmZXRjaFNvdXJjZUZpbGUoJy92aXRlLmNvbmZpZy50cycpO1xuICBpZiAodml0ZUNvbmZpZ0NvbnRlbnQpIHtcbiAgICB6aXAuZmlsZSgndml0ZS5jb25maWcudHMnLCB2aXRlQ29uZmlnQ29udGVudCk7XG4gIH1cblxuICBjb25zdCBpbmRleEh0bWxDb250ZW50ID0gYXdhaXQgZmV0Y2hTb3VyY2VGaWxlKCcvaW5kZXguaHRtbCcpO1xuICBpZiAoaW5kZXhIdG1sQ29udGVudCkge1xuICAgIHppcC5maWxlKCdpbmRleC5odG1sJywgaW5kZXhIdG1sQ29udGVudCk7XG4gIH1cblxuICAvLyBBZGQgQW5kcm9pZCBjb25maWd1cmF0aW9uIHRyZWVcbiAgY29uc3QgYW5kcm9pZEZvbGRlciA9IHppcC5mb2xkZXIoJ2FuZHJvaWQnKTtcbiAgaWYgKGFuZHJvaWRGb2xkZXIpIHtcbiAgICBhbmRyb2lkRm9sZGVyLmZpbGUoJ3ZhcmlhYmxlcy5ncmFkbGUnLCB2YXJpYWJsZXNHcmFkbGUpO1xuICAgIGFuZHJvaWRGb2xkZXIuZmlsZSgnZ3JhZGxlLnByb3BlcnRpZXMnLCBncmFkbGVQcm9wZXJ0aWVzKTtcblxuICAgIGNvbnN0IGFwcEZvbGRlciA9IGFuZHJvaWRGb2xkZXIuZm9sZGVyKCdhcHAnKTtcbiAgICBpZiAoYXBwRm9sZGVyKSB7XG4gICAgICBhcHBGb2xkZXIuZmlsZSgnYnVpbGQuZ3JhZGxlJywgYXBwQnVpbGRHcmFkbGUpO1xuICAgICAgY29uc3Qgc3JjTWFpbiA9IGFwcEZvbGRlci5mb2xkZXIoJ3NyYy9tYWluJyk7XG4gICAgICBpZiAoc3JjTWFpbikge1xuICAgICAgICBzcmNNYWluLmZpbGUoJ0FuZHJvaWRNYW5pZmVzdC54bWwnLCBhbmRyb2lkTWFuaWZlc3QpO1xuXG4gICAgICAgIGNvbnN0IGphdmFGb2xkZXIgPSBzcmNNYWluLmZvbGRlcignamF2YS9jb20vZGFpbHloYWJpdHMvdHJhY2tlcicpO1xuICAgICAgICBpZiAoamF2YUZvbGRlcikge1xuICAgICAgICAgIGphdmFGb2xkZXIuZmlsZSgnTWFpbkFjdGl2aXR5LmphdmEnLCBtYWluQWN0aXZpdHlKYXZhKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHJlc1ZhbHVlcyA9IHNyY01haW4uZm9sZGVyKCdyZXMvdmFsdWVzJyk7XG4gICAgICAgIGlmIChyZXNWYWx1ZXMpIHtcbiAgICAgICAgICByZXNWYWx1ZXMuZmlsZSgnc3RyaW5ncy54bWwnLCBzdHJpbmdzWG1sKTtcbiAgICAgICAgICByZXNWYWx1ZXMuZmlsZSgnc3R5bGVzLnhtbCcsIHN0eWxlc1htbCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBGZXRjaCBhbmQgcGFjayBhbGwgc291cmNlIGNvZGUgZmlsZXMgZnJvbSBzcmMvXG4gIGNvbnN0IHNyY0ZpbGVzID0gW1xuICAgICdzcmMvbWFpbi50c3gnLFxuICAgICdzcmMvQXBwLnRzeCcsXG4gICAgJ3NyYy9pbmRleC5jc3MnLFxuICAgICdzcmMvdHlwZXMvaGFiaXQudHMnLFxuICAgICdzcmMvc2VydmljZXMvc3RvcmFnZVNlcnZpY2UudHMnLFxuICAgICdzcmMvc2VydmljZXMvc3RyZWFrU2VydmljZS50cycsXG4gICAgJ3NyYy9zZXJ2aWNlcy9ub3RpZmljYXRpb25TZXJ2aWNlLnRzJyxcbiAgICAnc3JjL3NlcnZpY2VzL2FuZHJvaWRFeHBvcnRTZXJ2aWNlLnRzJyxcbiAgICAnc3JjL2NvbXBvbmVudHMvSGVhZGVyLnRzeCcsXG4gICAgJ3NyYy9jb21wb25lbnRzL0JvdHRvbU5hdi50c3gnLFxuICAgICdzcmMvY29tcG9uZW50cy9Ub2RheVRhYi50c3gnLFxuICAgICdzcmMvY29tcG9uZW50cy9IYWJpdHNUYWIudHN4JyxcbiAgICAnc3JjL2NvbXBvbmVudHMvUHJvZ3Jlc3NUYWIudHN4JyxcbiAgICAnc3JjL2NvbXBvbmVudHMvU2V0dGluZ3NUYWIudHN4JyxcbiAgICAnc3JjL2NvbXBvbmVudHMvSGFiaXRGb3JtTW9kYWwudHN4JyxcbiAgICAnc3JjL2NvbXBvbmVudHMvQ29uZmlybU1vZGFsLnRzeCcsXG4gICAgJ3NyYy9jb21wb25lbnRzL1JlbWluZGVyVG9hc3QudHN4JyxcbiAgICAnc3JjL2NvbXBvbmVudHMvSGFiaXRJY29uLnRzeCcsXG4gICAgJ3NyYy9jb21wb25lbnRzL0FuZHJvaWRBcGtNb2RhbC50c3gnLFxuICBdO1xuXG4gIGF3YWl0IFByb21pc2UuYWxsKFxuICAgIHNyY0ZpbGVzLm1hcChhc3luYyAoZmlsZVBhdGgpID0+IHtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCBmZXRjaFNvdXJjZUZpbGUoJy8nICsgZmlsZVBhdGgpO1xuICAgICAgaWYgKGNvbnRlbnQpIHtcbiAgICAgICAgemlwLmZpbGUoZmlsZVBhdGgsIGNvbnRlbnQpO1xuICAgICAgfVxuICAgIH0pXG4gICk7XG5cbiAgLy8gR2VuZXJhdGUgWklQIGJsb2IgYW5kIHRyaWdnZXIgY2xpZW50IGRvd25sb2FkXG4gIGNvbnN0IGJsb2IgPSBhd2FpdCB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdibG9iJyB9KTtcbiAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgYS5ocmVmID0gdXJsO1xuICBhLmRvd25sb2FkID0gJ2RhaWx5LWhhYml0cy10cmFja2VyLWFuZHJvaWQtcHJvamVjdC56aXAnO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICBhLmNsaWNrKCk7XG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbn1cbiJdfQ==