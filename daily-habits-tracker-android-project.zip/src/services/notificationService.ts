export function checkNotificationStatus() {
	if (typeof window === "undefined" || !("Notification" in window)) {
		return {
			isSupported: false,
			permission: "unsupported",
			explanationHindi: "इस ब्राउज़र या इन-ऐप वेबव्यू में वेब नोटिफिकेशन समर्थित नहीं है।"
		};
	}
	const permission = Notification.permission;
	let explanationHindi = "";
	if (permission === "granted") {
		explanationHindi = "नोटिफिकेशन सक्रिय है। कृपया ध्यान दें: ब्राउज़र नोटिफिकेशन केवल तभी काम करते हैं जब ऐप खुला या बैकग्राउंड टैब में सक्रिय हो। स्क्रीन लॉक होने पर ब्राउज़र प्रतिबंध लागू हो सकते हैं।";
	} else if (permission === "denied") {
		explanationHindi = "नोटिफिकेशन की अनुमति अस्वीकृत है। यदि आप रिमाइंडर चाहते हैं, तो कृपया अपने ब्राउज़र की साइट सेटिंग्स में जाकर नोटिफिकेशन चालू करें।";
	} else {
		explanationHindi = "रिमाइंडर पाने के लिए आपको ब्राउज़र से नोटिफिकेशन की अनुमति देनी होगी।";
	}
	return {
		isSupported: true,
		permission,
		explanationHindi
	};
}
export async function requestNotificationPermission() {
	if (typeof window === "undefined" || !("Notification" in window)) {
		return "unsupported";
	}
	try {
		const perm = await Notification.requestPermission();
		return perm;
	} catch (err) {
		console.error("Failed to request notification permission:", err);
		return "default";
	}
}
export function sendTestNotification() {
	if (typeof window === "undefined" || !("Notification" in window)) {
		return false;
	}
	if (Notification.permission !== "granted") {
		return false;
	}
	try {
		new Notification("मेरी अच्छी आदतें ⏰", {
			body: "यह एक परीक्षण रिमाइंडर है! आपकी आदतें आपको सफलता की ओर ले जाती हैं।",
			icon: "/favicon.ico"
		});
		return true;
	} catch (e) {
		console.error("Error firing notification:", e);
		return false;
	}
}
// Track reminders fired today so we don't spam
const notifiedToday = new Set();
export function checkScheduledReminders(habits, onTrigger) {
	if (typeof window === "undefined") return;
	const now = new Date();
	const currentHours = String(now.getHours()).padStart(2, "0");
	const currentMinutes = String(now.getMinutes()).padStart(2, "0");
	const currentTimeStr = `${currentHours}:${currentMinutes}`;
	const todayKey = now.toISOString().split("T")[0];
	habits.forEach((habit) => {
		if (habit.isPaused) return;
		if (!habit.reminderTime) return;
		const reminderKey = `${todayKey}_${habit.id}_${habit.reminderTime}`;
		if (habit.reminderTime === currentTimeStr && !notifiedToday.has(reminderKey)) {
			notifiedToday.add(reminderKey);
			// Trigger callback for in-app alert/toast
			if (onTrigger) {
				onTrigger(habit);
			}
			// If browser notifications allowed, trigger system notification
			if ("Notification" in window && Notification.permission === "granted") {
				try {
					new Notification(`रिमाइंडर: ${habit.name}`, {
						body: `समय हो गया है! अपनी आदत "${habit.name}" को पूरा करें।`,
						icon: "/favicon.ico"
					});
				} catch (err) {
					console.warn("Could not fire notification", err);
				}
			}
		}
	});
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBUUEsT0FBTyxTQUFTLDBCQUE4QztDQUM1RCxJQUFJLE9BQU8sV0FBVyxlQUFlLEVBQUUsa0JBQWtCLFNBQVM7RUFDaEUsT0FBTztHQUNMLGFBQWE7R0FDYixZQUFZO0dBQ1osa0JBQWtCO0VBQ3BCO0NBQ0Y7Q0FFQSxNQUFNLGFBQWEsYUFBYTtDQUNoQyxJQUFJLG1CQUFtQjtDQUV2QixJQUFJLGVBQWUsV0FBVztFQUM1QixtQkFBbUI7Q0FDckIsT0FBTyxJQUFJLGVBQWUsVUFBVTtFQUNsQyxtQkFBbUI7Q0FDckIsT0FBTztFQUNMLG1CQUFtQjtDQUNyQjtDQUVBLE9BQU87RUFDTCxhQUFhO0VBQ2I7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxPQUFPLGVBQWUsZ0NBQWlGO0NBQ3JHLElBQUksT0FBTyxXQUFXLGVBQWUsRUFBRSxrQkFBa0IsU0FBUztFQUNoRSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJO0VBQ0YsTUFBTSxPQUFPLE1BQU0sYUFBYSxrQkFBa0I7RUFDbEQsT0FBTztDQUNULFNBQVMsS0FBSztFQUNaLFFBQVEsTUFBTSw4Q0FBOEMsR0FBRztFQUMvRCxPQUFPO0NBQ1Q7QUFDRjtBQUVBLE9BQU8sU0FBUyx1QkFBZ0M7Q0FDOUMsSUFBSSxPQUFPLFdBQVcsZUFBZSxFQUFFLGtCQUFrQixTQUFTO0VBQ2hFLE9BQU87Q0FDVDtDQUNBLElBQUksYUFBYSxlQUFlLFdBQVc7RUFDekMsT0FBTztDQUNUO0NBQ0EsSUFBSTtFQUNGLElBQUksYUFBYSxzQkFBc0I7R0FDckMsTUFBTTtHQUNOLE1BQU07RUFDUixDQUFDO0VBQ0QsT0FBTztDQUNULFNBQVMsR0FBRztFQUNWLFFBQVEsTUFBTSw4QkFBOEIsQ0FBQztFQUM3QyxPQUFPO0NBQ1Q7QUFDRjs7QUFHQSxNQUFNLGdCQUFnQixJQUFJLElBQVk7QUFFdEMsT0FBTyxTQUFTLHdCQUF3QixRQUFpQixXQUEwQztDQUNqRyxJQUFJLE9BQU8sV0FBVyxhQUFhO0NBRW5DLE1BQU0sTUFBTSxJQUFJLEtBQUs7Q0FDckIsTUFBTSxlQUFlLE9BQU8sSUFBSSxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQzNELE1BQU0saUJBQWlCLE9BQU8sSUFBSSxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQy9ELE1BQU0saUJBQWlCLEdBQUcsYUFBYSxHQUFHO0NBQzFDLE1BQU0sV0FBVyxJQUFJLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Q0FFOUMsT0FBTyxTQUFTLFVBQVU7RUFDeEIsSUFBSSxNQUFNLFVBQVU7RUFDcEIsSUFBSSxDQUFDLE1BQU0sY0FBYztFQUV6QixNQUFNLGNBQWMsR0FBRyxTQUFTLEdBQUcsTUFBTSxHQUFHLEdBQUcsTUFBTTtFQUVyRCxJQUFJLE1BQU0saUJBQWlCLGtCQUFrQixDQUFDLGNBQWMsSUFBSSxXQUFXLEdBQUc7R0FDNUUsY0FBYyxJQUFJLFdBQVc7O0dBRzdCLElBQUksV0FBVztJQUNiLFVBQVUsS0FBSztHQUNqQjs7R0FHQSxJQUFJLGtCQUFrQixVQUFVLGFBQWEsZUFBZSxXQUFXO0lBQ3JFLElBQUk7S0FDRixJQUFJLGFBQWEsYUFBYSxNQUFNLFFBQVE7TUFDMUMsTUFBTSw0QkFBNEIsTUFBTSxLQUFLO01BQzdDLE1BQU07S0FDUixDQUFDO0lBQ0gsU0FBUyxLQUFLO0tBQ1osUUFBUSxLQUFLLCtCQUErQixHQUFHO0lBQ2pEO0dBQ0Y7RUFDRjtDQUNGLENBQUM7QUFDSCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJub3RpZmljYXRpb25TZXJ2aWNlLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEhhYml0IH0gZnJvbSAnLi4vdHlwZXMvaGFiaXQnO1xuXG5leHBvcnQgaW50ZXJmYWNlIE5vdGlmaWNhdGlvblN0YXR1cyB7XG4gIGlzU3VwcG9ydGVkOiBib29sZWFuO1xuICBwZXJtaXNzaW9uOiBOb3RpZmljYXRpb25QZXJtaXNzaW9uIHwgJ3Vuc3VwcG9ydGVkJztcbiAgZXhwbGFuYXRpb25IaW5kaTogc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tOb3RpZmljYXRpb25TdGF0dXMoKTogTm90aWZpY2F0aW9uU3RhdHVzIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnIHx8ICEoJ05vdGlmaWNhdGlvbicgaW4gd2luZG93KSkge1xuICAgIHJldHVybiB7XG4gICAgICBpc1N1cHBvcnRlZDogZmFsc2UsXG4gICAgICBwZXJtaXNzaW9uOiAndW5zdXBwb3J0ZWQnLFxuICAgICAgZXhwbGFuYXRpb25IaW5kaTogJ+Ckh+CkuCDgpKzgpY3gpLDgpL7gpIngpJzgpLzgpLAg4KSv4KS+IOCkh+CkqC3gpJDgpKog4KS14KWH4KSs4KS14KWN4KSv4KWCIOCkruClh+CkgiDgpLXgpYfgpKwg4KSo4KWL4KSf4KS/4KSr4KS/4KSV4KWH4KS24KSoIOCkuOCkruCksOCljeCkpeCkv+CkpCDgpKjgpLngpYDgpIIg4KS54KWI4KWkJyxcbiAgICB9O1xuICB9XG5cbiAgY29uc3QgcGVybWlzc2lvbiA9IE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uO1xuICBsZXQgZXhwbGFuYXRpb25IaW5kaSA9ICcnO1xuXG4gIGlmIChwZXJtaXNzaW9uID09PSAnZ3JhbnRlZCcpIHtcbiAgICBleHBsYW5hdGlvbkhpbmRpID0gJ+CkqOCli+Ckn+Ckv+Ckq+Ckv+CkleClh+CktuCkqCDgpLjgpJXgpY3gpLDgpL/gpK8g4KS54KWI4KWkIOCkleClg+CkquCkr+CkviDgpKfgpY3gpK/gpL7gpKgg4KSm4KWH4KSCOiDgpKzgpY3gpLDgpL7gpIngpJzgpLzgpLAg4KSo4KWL4KSf4KS/4KSr4KS/4KSV4KWH4KS24KSoIOCkleClh+CkteCksiDgpKTgpK3gpYAg4KSV4KS+4KSuIOCkleCksOCkpOClhyDgpLngpYjgpIIg4KSc4KSsIOCkkOCkqiDgpJbgpYHgpLLgpL4g4KSv4KS+IOCkrOCliOCkleCkl+CljeCksOCkvuCkieCkguCkoSDgpJ/gpYjgpKwg4KSu4KWH4KSCIOCkuOCkleCljeCksOCkv+CkryDgpLngpYvgpaQg4KS44KWN4KSV4KWN4KSw4KWA4KSoIOCksuClieCklSDgpLngpYvgpKjgpYcg4KSq4KSwIOCkrOCljeCksOCkvuCkieCknOCkvOCksCDgpKrgpY3gpLDgpKTgpL/gpKzgpILgpKcg4KSy4KS+4KSX4KWCIOCkueCliyDgpLjgpJXgpKTgpYcg4KS54KWI4KSC4KWkJztcbiAgfSBlbHNlIGlmIChwZXJtaXNzaW9uID09PSAnZGVuaWVkJykge1xuICAgIGV4cGxhbmF0aW9uSGluZGkgPSAn4KSo4KWL4KSf4KS/4KSr4KS/4KSV4KWH4KS24KSoIOCkleClgCDgpIXgpKjgpYHgpK7gpKTgpL8g4KSF4KS44KWN4KS14KWA4KSV4KWD4KSkIOCkueCliOClpCDgpK/gpKbgpL8g4KSG4KSqIOCksOCkv+CkruCkvuCkh+CkguCkoeCksCDgpJrgpL7gpLngpKTgpYcg4KS54KWI4KSCLCDgpKTgpYsg4KSV4KWD4KSq4KSv4KS+IOCkheCkquCkqOClhyDgpKzgpY3gpLDgpL7gpIngpJzgpLzgpLAg4KSV4KWAIOCkuOCkvuCkh+CknyDgpLjgpYfgpJ/gpL/gpILgpJfgpY3gpLgg4KSu4KWH4KSCIOCknOCkvuCkleCksCDgpKjgpYvgpJ/gpL/gpKvgpL/gpJXgpYfgpLbgpKgg4KSa4KS+4KSy4KWCIOCkleCksOClh+CkguClpCc7XG4gIH0gZWxzZSB7XG4gICAgZXhwbGFuYXRpb25IaW5kaSA9ICfgpLDgpL/gpK7gpL7gpIfgpILgpKHgpLAg4KSq4KS+4KSo4KWHIOCkleClhyDgpLLgpL/gpI8g4KSG4KSq4KSV4KWLIOCkrOCljeCksOCkvuCkieCknOCkvOCksCDgpLjgpYcg4KSo4KWL4KSf4KS/4KSr4KS/4KSV4KWH4KS24KSoIOCkleClgCDgpIXgpKjgpYHgpK7gpKTgpL8g4KSm4KWH4KSo4KWAIOCkueCli+Ckl+ClgOClpCc7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGlzU3VwcG9ydGVkOiB0cnVlLFxuICAgIHBlcm1pc3Npb24sXG4gICAgZXhwbGFuYXRpb25IaW5kaSxcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlcXVlc3ROb3RpZmljYXRpb25QZXJtaXNzaW9uKCk6IFByb21pc2U8Tm90aWZpY2F0aW9uUGVybWlzc2lvbiB8ICd1bnN1cHBvcnRlZCc+IHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnIHx8ICEoJ05vdGlmaWNhdGlvbicgaW4gd2luZG93KSkge1xuICAgIHJldHVybiAndW5zdXBwb3J0ZWQnO1xuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgcGVybSA9IGF3YWl0IE5vdGlmaWNhdGlvbi5yZXF1ZXN0UGVybWlzc2lvbigpO1xuICAgIHJldHVybiBwZXJtO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gcmVxdWVzdCBub3RpZmljYXRpb24gcGVybWlzc2lvbjonLCBlcnIpO1xuICAgIHJldHVybiAnZGVmYXVsdCc7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRUZXN0Tm90aWZpY2F0aW9uKCk6IGJvb2xlYW4ge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcgfHwgISgnTm90aWZpY2F0aW9uJyBpbiB3aW5kb3cpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChOb3RpZmljYXRpb24ucGVybWlzc2lvbiAhPT0gJ2dyYW50ZWQnKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHRyeSB7XG4gICAgbmV3IE5vdGlmaWNhdGlvbign4KSu4KWH4KSw4KWAIOCkheCkmuCljeCkm+ClgCDgpIbgpKbgpKTgpYfgpIIg4o+wJywge1xuICAgICAgYm9keTogJ+Ckr+CkuSDgpI/gpJUg4KSq4KSw4KWA4KSV4KWN4KS34KSjIOCksOCkv+CkruCkvuCkh+CkguCkoeCksCDgpLngpYghIOCkhuCkquCkleClgCDgpIbgpKbgpKTgpYfgpIIg4KSG4KSq4KSV4KWLIOCkuOCkq+CksuCkpOCkviDgpJXgpYAg4KST4KSwIOCksuClhyDgpJzgpL7gpKTgpYAg4KS54KWI4KSC4KWkJyxcbiAgICAgIGljb246ICcvZmF2aWNvbi5pY28nLFxuICAgIH0pO1xuICAgIHJldHVybiB0cnVlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgZmlyaW5nIG5vdGlmaWNhdGlvbjonLCBlKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLy8gVHJhY2sgcmVtaW5kZXJzIGZpcmVkIHRvZGF5IHNvIHdlIGRvbid0IHNwYW1cbmNvbnN0IG5vdGlmaWVkVG9kYXkgPSBuZXcgU2V0PHN0cmluZz4oKTtcblxuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrU2NoZWR1bGVkUmVtaW5kZXJzKGhhYml0czogSGFiaXRbXSwgb25UcmlnZ2VyPzogKGhhYml0OiBIYWJpdCkgPT4gdm9pZCk6IHZvaWQge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHJldHVybjtcblxuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpO1xuICBjb25zdCBjdXJyZW50SG91cnMgPSBTdHJpbmcobm93LmdldEhvdXJzKCkpLnBhZFN0YXJ0KDIsICcwJyk7XG4gIGNvbnN0IGN1cnJlbnRNaW51dGVzID0gU3RyaW5nKG5vdy5nZXRNaW51dGVzKCkpLnBhZFN0YXJ0KDIsICcwJyk7XG4gIGNvbnN0IGN1cnJlbnRUaW1lU3RyID0gYCR7Y3VycmVudEhvdXJzfToke2N1cnJlbnRNaW51dGVzfWA7XG4gIGNvbnN0IHRvZGF5S2V5ID0gbm93LnRvSVNPU3RyaW5nKCkuc3BsaXQoJ1QnKVswXTtcblxuICBoYWJpdHMuZm9yRWFjaCgoaGFiaXQpID0+IHtcbiAgICBpZiAoaGFiaXQuaXNQYXVzZWQpIHJldHVybjtcbiAgICBpZiAoIWhhYml0LnJlbWluZGVyVGltZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgcmVtaW5kZXJLZXkgPSBgJHt0b2RheUtleX1fJHtoYWJpdC5pZH1fJHtoYWJpdC5yZW1pbmRlclRpbWV9YDtcblxuICAgIGlmIChoYWJpdC5yZW1pbmRlclRpbWUgPT09IGN1cnJlbnRUaW1lU3RyICYmICFub3RpZmllZFRvZGF5LmhhcyhyZW1pbmRlcktleSkpIHtcbiAgICAgIG5vdGlmaWVkVG9kYXkuYWRkKHJlbWluZGVyS2V5KTtcblxuICAgICAgLy8gVHJpZ2dlciBjYWxsYmFjayBmb3IgaW4tYXBwIGFsZXJ0L3RvYXN0XG4gICAgICBpZiAob25UcmlnZ2VyKSB7XG4gICAgICAgIG9uVHJpZ2dlcihoYWJpdCk7XG4gICAgICB9XG5cbiAgICAgIC8vIElmIGJyb3dzZXIgbm90aWZpY2F0aW9ucyBhbGxvd2VkLCB0cmlnZ2VyIHN5c3RlbSBub3RpZmljYXRpb25cbiAgICAgIGlmICgnTm90aWZpY2F0aW9uJyBpbiB3aW5kb3cgJiYgTm90aWZpY2F0aW9uLnBlcm1pc3Npb24gPT09ICdncmFudGVkJykge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIG5ldyBOb3RpZmljYXRpb24oYOCksOCkv+CkruCkvuCkh+CkguCkoeCksDogJHtoYWJpdC5uYW1lfWAsIHtcbiAgICAgICAgICAgIGJvZHk6IGDgpLjgpK7gpK8g4KS54KWLIOCkl+Ckr+CkviDgpLngpYghIOCkheCkquCkqOClgCDgpIbgpKbgpKQgXCIke2hhYml0Lm5hbWV9XCIg4KSV4KWLIOCkquClguCksOCkviDgpJXgpLDgpYfgpILgpaRgLFxuICAgICAgICAgICAgaWNvbjogJy9mYXZpY29uLmljbycsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIGNvbnNvbGUud2FybignQ291bGQgbm90IGZpcmUgbm90aWZpY2F0aW9uJywgZXJyKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSk7XG59XG4iXX0=