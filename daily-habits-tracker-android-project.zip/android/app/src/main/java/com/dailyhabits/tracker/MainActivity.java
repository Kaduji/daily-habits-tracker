package com.dailyhabits.tracker;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
